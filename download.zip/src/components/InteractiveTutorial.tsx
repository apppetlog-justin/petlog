
"use client"

import React, { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Sparkles, ArrowRight, X, ChevronRight, Check } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

interface Step {
  target: string // selector or 'center'
  title: string
  content: string
  position: 'top' | 'bottom' | 'center' // position of the modal card on screen
}

const STEPS: Step[] = [
  {
    target: 'center',
    title: 'Bienvenue sur PetLog !',
    content: "L'application moderne pour gérer la vie de vos compagnons. Laissez-nous vous guider à travers les fonctionnalités essentielles.",
    position: 'center'
  },
  {
    target: '[data-tut="pet-bubble"]',
    title: 'Votre Compagnon',
    content: "Cette bulle centrale est le cœur de l'app. Cliquez dessus pour changer d'animal ou ouvrir son dossier complet (documents, poids, ID).",
    position: 'top'
  },
  {
    target: '[data-tut="daily-note"]',
    title: 'Note du Jour',
    content: "Capturez ici l'état d'esprit de votre animal chaque matin : humeur, appétit, énergie. C'est votre carnet de bord quotidien.",
    position: 'bottom'
  },
  {
    target: '[data-tut="routine"]',
    title: 'Routine Interactive',
    content: "En fonction de l'âge et de la race, nous calculons ses besoins. Remplissez ces barres chaque jour pour un bien-être optimal.",
    position: 'bottom'
  },
  {
    target: '[data-tut="nav-left"]',
    title: 'Sorties & Santé',
    content: "Enregistrez vos balades avec suivi GPS ou notez les repas et les petits incidents de santé ici.",
    position: 'top'
  },
  {
    target: '[data-tut="nav-right"]',
    title: 'Physique & Dressage',
    content: "Suivez l'évolution physique (poids, taille) ou enregistrez les progrès lors des séances de dressage et de jeux.",
    position: 'top'
  },
  {
    target: '[data-tut="header-journal"]',
    title: 'Le Journal (Loupe)',
    content: "Retrouvez tout l'historique ici. Utilisez la barre de recherche pour retrouver un événement précis en un clin d'œil.",
    position: 'bottom'
  },
  {
    target: '[data-tut="header-vet"]',
    title: 'Espace Vétérinaire',
    content: "Un accès rapide pour noter les vaccins, les diagnostics et programmer vos futurs rappels médicaux.",
    position: 'bottom'
  },
  {
    target: '[data-tut="header-menu"]',
    title: 'IA & Rapports',
    content: "Le menu cache nos outils les plus puissants : l'Assistant IA pour des conseils sur mesure et la génération de rapports PDF.",
    position: 'bottom'
  }
]

export function InteractiveTutorial({ onFinish }: { onFinish: () => void }) {
  const [currentStep, setCurrentStep] = useState(0)
  const [spotlight, setSpotlight] = useState({ x: 0, y: 0, w: 0, h: 0, r: 0 })
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 500)
    return () => clearTimeout(timer)
  }, [])

  useEffect(() => {
    const updateSpotlight = () => {
      const step = STEPS[currentStep]
      if (step.target === 'center') {
        setSpotlight({ x: 0, y: 0, w: 0, h: 0, r: 0 })
        return
      }

      const el = document.querySelector(step.target)
      if (el) {
        const rect = el.getBoundingClientRect()
        setSpotlight({
          x: rect.left,
          y: rect.top,
          w: rect.width,
          h: rect.height,
          r: step.target.includes('bubble') || step.target.includes('header') ? 999 : 16
        })
        el.scrollIntoView({ behavior: 'smooth', block: 'center' })
      }
    }

    updateSpotlight()
    window.addEventListener('resize', updateSpotlight)
    return () => window.removeEventListener('resize', updateSpotlight)
  }, [currentStep])

  const nextStep = () => {
    if (currentStep < STEPS.length - 1) {
      setCurrentStep(prev => prev + 1)
    } else {
      onFinish()
    }
  }

  const step = STEPS[currentStep]

  return (
    <AnimatePresence>
      {isVisible && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center overflow-hidden pointer-events-none">
          {/* Overlay with Spotlight */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/80 pointer-events-auto"
            style={{
              clipPath: spotlight.w > 0 
                ? `polygon(0% 0%, 0% 100%, ${spotlight.x - 8}px 100%, ${spotlight.x - 8}px ${spotlight.y - 8}px, ${spotlight.x + spotlight.w + 8}px ${spotlight.y - 8}px, ${spotlight.x + spotlight.w + 8}px ${spotlight.y + spotlight.h + 8}px, ${spotlight.x - 8}px ${spotlight.y + spotlight.h + 8}px, ${spotlight.x - 8}px 100%, 100% 100%, 100% 0%)`
                : 'none'
            }}
          />

          {/* Content Card */}
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className={cn(
              "absolute z-[110] w-[calc(100%-2rem)] max-w-sm glass-card border-primary/20 p-6 shadow-2xl pointer-events-auto rounded-3xl",
              step.position === 'center' && "relative",
              step.position === 'top' && "top-20", 
              step.position === 'bottom' && "bottom-24"
            )}
          >
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="p-3 bg-primary/20 rounded-2xl">
                <Sparkles className="h-8 w-8 text-primary animate-pulse" />
              </div>
              <div className="space-y-2">
                <h3 className="text-xl font-black uppercase tracking-tighter text-primary">{step.title}</h3>
                <p className="text-sm font-medium text-muted-foreground leading-relaxed">
                  {step.content}
                </p>
              </div>

              <div className="w-full pt-4 space-y-3">
                <Button onClick={nextStep} className="w-full bg-primary h-12 font-black uppercase tracking-widest text-[10px] rounded-xl gap-2">
                  {currentStep === STEPS.length - 1 ? (
                    <>C'est parti ! <Check className="h-4 w-4" /></>
                  ) : (
                    <>Étape suivante <ChevronRight className="h-4 w-4" /></>
                  )}
                </Button>
                
                <div className="flex justify-center gap-1.5 pt-2">
                  {STEPS.map((_, i) => (
                    <div key={i} className={cn("h-1 rounded-full transition-all", currentStep === i ? "w-6 bg-primary" : "w-1.5 bg-white/10")} />
                  ))}
                </div>
              </div>
            </div>

            <button 
              onClick={onFinish}
              className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-white/5 transition-colors text-muted-foreground"
            >
              <X className="h-4 w-4" />
            </button>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  )
}
