
"use client"

import React from 'react'
import Link from 'next/link'
import { Dog, LogOut, Menu, Search, User, StickyNote, FileText, Settings, Sparkles, Hospital, BrainCircuit } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu'
import { useUser, useAuth } from '@/firebase'
import { signOut } from 'firebase/auth'
import { useRouter } from 'next/navigation'

export function Header() {
  const { user, isUserLoading } = useUser()
  const auth = useAuth()
  const router = useRouter()

  const forceUnlock = () => {
    setTimeout(() => {
      document.body.style.pointerEvents = 'auto';
      document.body.style.overflow = 'auto';
      if (document.documentElement) {
        document.documentElement.style.pointerEvents = 'auto';
        document.documentElement.style.overflow = 'auto';
      }
    }, 300);
  };

  const handleSignOut = () => {
    signOut(auth).then(() => {
      forceUnlock();
      router.push('/login')
    })
  }

  const handleOpenJournal = () => {
    window.dispatchEvent(new CustomEvent('open-journal'));
    forceUnlock();
  }

  const handleOpenDailyNote = () => {
    window.dispatchEvent(new CustomEvent('open-daily-note'));
    forceUnlock();
  }

  return (
    <header className="fixed top-0 left-0 right-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 shadow-sm h-16">
      <div className="container flex h-full items-center justify-between px-4 mx-auto">
        <Link href="/" className="flex items-center space-x-2 shrink-0">
          <Dog className="h-6 w-6 text-primary" />
          <span className="text-2xl font-bold tracking-tight">
            Pet<span className="text-accent">Log</span>
          </span>
        </Link>

        <div className="flex items-center gap-2">
          {!isUserLoading && user && (
            <div className="flex items-center gap-2">
              <button 
                data-tut="header-journal"
                onClick={handleOpenJournal}
                className="p-2 rounded-md border border-primary/20 bg-primary/5 hover:bg-primary/10 text-primary transition-colors"
                title="Journal"
              >
                <Search className="h-5 w-5" />
              </button>

              <Link 
                data-tut="header-vet"
                href="/vet"
                className="p-2 rounded-md border border-red-500/20 bg-red-500/5 hover:bg-red-500/10 text-red-500 transition-colors"
                title="Vétérinaire"
              >
                <Hospital className="h-5 w-5" />
              </Link>

              <DropdownMenu onOpenChange={(open) => { if(!open) forceUnlock(); }}>
                <DropdownMenuTrigger asChild>
                  <Button data-tut="header-menu" variant="outline" size="icon" className="rounded-md border-primary/20 bg-secondary/50">
                    <Menu className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-64 glass-card p-2 border-white/10 shadow-2xl">
                  <div className="px-2 py-3 flex items-center gap-3 border-b border-white/5 mb-2">
                    <div className="h-8 w-8 rounded-full bg-primary/20 flex items-center justify-center">
                      <User className="h-4 w-4 text-primary" />
                    </div>
                    <div className="flex flex-col min-w-0">
                      <span className="text-sm font-bold text-foreground truncate">{user.displayName || 'Utilisateur'}</span>
                      <span className="text-[10px] text-muted-foreground truncate">{user.email}</span>
                    </div>
                  </div>
                  
                  <div className="space-y-1">
                    <DropdownMenuItem asChild className="cursor-pointer gap-3 focus:bg-primary/10" onClick={forceUnlock}>
                      <Link href="/life-guide" className="flex items-center gap-3 w-full">
                        <Sparkles className="h-4 w-4 text-accent" />
                        <span className="font-bold">Guide de Vie</span>
                      </Link>
                    </DropdownMenuItem>

                    <DropdownMenuItem asChild className="cursor-pointer gap-3 focus:bg-primary/10" onClick={forceUnlock}>
                      <Link href="/ai-assistant" className="flex items-center gap-3 w-full">
                        <BrainCircuit className="h-4 w-4 text-primary" />
                        <span className="font-bold">Assistant IA</span>
                      </Link>
                    </DropdownMenuItem>

                    <DropdownMenuItem onClick={handleOpenDailyNote} className="cursor-pointer gap-3 focus:bg-accent/10">
                      <StickyNote className="h-4 w-4 text-accent" />
                      <span className="font-medium">Note Quotidienne</span>
                    </DropdownMenuItem>

                    <DropdownMenuItem asChild className="cursor-pointer focus:bg-primary/10" onClick={forceUnlock}>
                      <Link href="/reports" className="flex items-center gap-3 w-full">
                        <FileText className="h-4 w-4 text-primary" />
                        <span className="font-medium">Générer un Rapport</span>
                      </Link>
                    </DropdownMenuItem>

                    <DropdownMenuItem asChild className="cursor-pointer gap-3 focus:bg-accent/10" onClick={forceUnlock}>
                      <Link href="/settings" className="flex items-center gap-3 w-full">
                        <Settings className="h-4 w-4 text-accent" />
                        <span className="font-medium">Paramètres</span>
                      </Link>
                    </DropdownMenuItem>
                  </div>

                  <DropdownMenuSeparator className="my-2 bg-white/5" />
                  
                  <DropdownMenuItem onClick={handleSignOut} className="text-destructive font-bold cursor-pointer gap-3 focus:bg-destructive/10">
                    <LogOut className="h-4 w-4" /> Déconnexion
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          )}

          {!user && !isUserLoading && (
            <div className="flex gap-2">
              <Button variant="outline" size="sm" asChild onClick={forceUnlock}>
                <Link href="/login">Connexion</Link>
              </Button>
              <Button size="sm" asChild className="bg-primary" onClick={forceUnlock}>
                <Link href="/signup">S'inscrire</Link>
              </Button>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}
