
"use client"

import React, { useState, useEffect, useMemo, useRef } from 'react'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { 
  Footprints, 
  HeartPulse, 
  Stethoscope, 
  BicepsFlexed, 
  Dog,
  Calendar,
  Edit2,
  Clock,
  Droplets,
  AlertTriangle,
  Moon,
  X,
  Maximize2,
  Utensils,
  ChevronLeft,
  ChevronRight,
  Plus,
  LayoutList,
  StickyNote,
  Save,
  Loader2,
  FileText,
  Pill,
  GlassWater,
  Brain,
  Hospital,
  Bell,
  Search
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { useUser, useCollection, useMemoFirebase, useFirestore, useDoc } from '@/firebase'
import { collection, query, where, doc, orderBy, setDoc, limit } from 'firebase/firestore'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Badge } from '@/components/ui/badge'
import { useToast } from '@/hooks/use-toast'
import Image from 'next/image'
import { Card, CardContent } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'

type ActivityCategory = 'all' | 'meals' | 'walks' | 'excretions' | 'vomitIncidents' | 'sleepRecords' | 'trainingSessions' | 'generalInspections' | 'vetVisits';
type ViewMode = 'day' | 'all';

const formatDateLong = (dateStr: string) => {
  if (!dateStr) return '';
  const [year, month, day] = dateStr.split('-').map(Number);
  const d = new Date(year, month - 1, day);
  return d.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
};

export function BottomNav() {
  const pathname = usePathname()
  const router = useRouter()
  const { user } = useUser()
  const db = useFirestore()
  const { toast } = useToast()
  
  const [isPetSelectorOpen, setIsPetSelectorOpen] = useState(false)
  const [isJournalOpen, setIsJournalOpen] = useState(false)
  const [isNoteDialogOpen, setIsNoteDialogOpen] = useState(false)
  const [viewDayDetails, setViewDayDetails] = useState<any>(null)
  const [fullScreenImage, setFullScreenImage] = useState<string | null>(null)
  
  const [selectedPetId, setSelectedPetId] = useState<string|null>(null)
  const [searchDate, setSearchDate] = useState(new Date().toISOString().split('T')[0])
  const [category, setCategory] = useState<ActivityCategory>('all')
  const [viewMode, setViewMode] = useState<ViewMode>('day')
  const [searchQuery, setSearchQuery] = useState('')

  const [noteDraft, setNoteDraft] = useState('')
  const [isSavingNote, setIsSavingNote] = useState(false)

  const petsRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return collection(db, 'users', user.uid, 'pets')
  }, [db, user])
  const { data: pets } = useCollection(petsRef)

  useEffect(() => {
    const saved = typeof window !== 'undefined' ? localStorage.getItem('globalSelectedPetId') : null;
    if (saved) setSelectedPetId(saved);
  }, []);

  const updateGlobalPetSelection = (petId: string) => {
    setSelectedPetId(petId);
    localStorage.setItem('globalSelectedPetId', petId);
    window.dispatchEvent(new CustomEvent('pet-changed', { detail: { petId } }));
  }

  const currentPet = pets?.find(p => p.id === selectedPetId) || (pets?.[0] || null)

  const dailyNoteRef = useMemoFirebase(() => {
    if (!db || !user || !currentPet?.id || !searchDate) return null
    return doc(db, 'users', user.uid, 'pets', currentPet.id, 'dailyNotes', searchDate)
  }, [db, user, currentPet?.id, searchDate])
  const { data: dailyNote } = useDoc(dailyNoteRef)

  useEffect(() => {
    if (dailyNote) setNoteDraft(dailyNote.content || '')
    else setNoteDraft('')
  }, [dailyNote, searchDate])

  const forceUnlock = () => {
    setTimeout(() => {
      const hasOpenModal = document.querySelectorAll('[data-state="open"]').length > 0;
      if (!hasOpenModal) {
        document.body.style.pointerEvents = 'auto';
        document.body.style.overflow = 'auto';
        if (document.documentElement) {
          document.documentElement.style.pointerEvents = 'auto';
          document.documentElement.style.overflow = 'auto';
        }
      }
    }, 300);
  };

  useEffect(() => {
    const handleOpenJournal = () => setIsJournalOpen(true);
    const handleOpenDailyNote = () => {
      setSearchDate(new Date().toISOString().split('T')[0]);
      setIsNoteDialogOpen(true);
    };
    const handlePetChanged = (e: any) => {
      if (e.detail.petId !== selectedPetId) {
        setSelectedPetId(e.detail.petId);
        localStorage.setItem('globalSelectedPetId', e.detail.petId);
      }
    };
    
    window.addEventListener('open-journal', handleOpenJournal);
    window.addEventListener('open-daily-note', handleOpenDailyNote);
    window.addEventListener('pet-changed', handlePetChanged);
    
    return () => {
      window.removeEventListener('open-journal', handleOpenJournal);
      window.removeEventListener('open-daily-note', handleOpenDailyNote);
      window.removeEventListener('pet-changed', handlePetChanged);
    }
  }, [selectedPetId]);

  const range = useMemo(() => {
    if (!searchDate) return { start: '', end: '' };
    return { 
      start: `${searchDate}T00:00:00.000Z`, 
      end: `${searchDate}T23:59:59.999Z` 
    };
  }, [searchDate]);

  const getFilteredQuery = (collName: string, dateField: string) => {
    if (!db || !user || !currentPet?.id) return null
    if (category !== 'all' && category !== collName) return null;
    
    const baseRef = collection(db, 'users', user.uid, 'pets', currentPet.id, collName);
    
    if (viewMode === 'all') {
      return query(baseRef, orderBy(dateField, 'desc'), limit(100));
    }

    return query(
      baseRef,
      where(dateField, '>=', range.start),
      where(dateField, '<=', range.end),
      orderBy(dateField, 'desc')
    )
  }

  const walkDayRef = useMemoFirebase(() => getFilteredQuery('walks', 'walkDate'), [db, user, currentPet?.id, searchDate, category, viewMode]);
  const mealDayRef = useMemoFirebase(() => getFilteredQuery('meals', 'mealDate'), [db, user, currentPet?.id, searchDate, category, viewMode]);
  const excretionDayRef = useMemoFirebase(() => getFilteredQuery('excretions', 'excretionDate'), [db, user, currentPet?.id, searchDate, category, viewMode]);
  const vomitDayRef = useMemoFirebase(() => getFilteredQuery('vomitIncidents', 'incidentDate'), [db, user, currentPet?.id, searchDate, category, viewMode]);
  const sleepDayRef = useMemoFirebase(() => getFilteredQuery('sleepRecords', 'sleepDate'), [db, user, currentPet?.id, searchDate, category, viewMode]);
  const trainingDayRef = useMemoFirebase(() => getFilteredQuery('trainingSessions', 'sessionDate'), [db, user, currentPet?.id, searchDate, category, viewMode]);
  const physicalDayRef = useMemoFirebase(() => getFilteredQuery('generalInspections', 'inspectionDate'), [db, user, currentPet?.id, searchDate, category, viewMode]);
  const vetDayRef = useMemoFirebase(() => getFilteredQuery('vetVisits', 'visitDate'), [db, user, currentPet?.id, searchDate, category, viewMode]);

  const { data: dayWalks } = useCollection(walkDayRef)
  const { data: dayMeals } = useCollection(mealDayRef)
  const { data: dayExcretions } = useCollection(excretionDayRef)
  const { data: dayVomits } = useCollection(vomitDayRef)
  const { data: daySleep } = useCollection(sleepDayRef)
  const { data: dayTraining } = useCollection(trainingDayRef)
  const { data: dayPhysical } = useCollection(physicalDayRef)
  const { data: dayVet } = useCollection(vetDayRef)

  const combinedTimeline = useMemo(() => {
    const events: any[] = []
    if (dayWalks) dayWalks.forEach(e => events.push({ ...e, category: 'walks', timelineLabel: 'Balade', collectionName: 'walks', date: e.walkDate, icon: Footprints, color: 'text-primary', page: '/walks', tab: 'walks' }))
    if (dayMeals) dayMeals.forEach(e => events.push({ ...e, category: 'meals', timelineLabel: 'Repas', collectionName: 'meals', date: e.mealDate, icon: Utensils, color: 'text-primary', page: '/health', tab: 'repas' }))
    if (dayExcretions) dayExcretions.forEach(e => events.push({ ...e, category: 'excretions', timelineLabel: 'Selle/Urine', collectionName: 'excretions', date: e.excretionDate, icon: Droplets, color: 'text-orange-500', page: '/health', tab: 'excretions' }))
    if (dayVomits) dayVomits.forEach(e => events.push({ ...e, category: 'vomits', timelineLabel: 'Vomi', collectionName: 'vomitIncidents', date: e.incidentDate, icon: AlertTriangle, color: 'text-destructive', page: '/health', tab: 'vomis' }))
    if (daySleep) daySleep.forEach(e => events.push({ ...e, category: 'sleep', timelineLabel: 'Sommeil & Comp.', collectionName: 'sleepRecords', date: e.sleepDate, icon: Moon, color: 'text-blue-400', page: '/health', tab: 'sommeil' }))
    if (dayTraining) dayTraining.forEach(e => events.push({ ...e, category: 'training', timelineLabel: 'Dressage', collectionName: 'trainingSessions', date: e.sessionDate, icon: BicepsFlexed, color: 'text-orange-600', page: '/training', tab: 'training' }))
    if (dayPhysical) dayPhysical.forEach(e => events.push({ ...e, category: 'physical', timelineLabel: 'Physique', collectionName: 'generalInspections', date: e.inspectionDate, icon: Stethoscope, color: 'text-blue-500', page: '/physical', tab: 'inspection' }))
    if (dayVet) dayVet.forEach(e => events.push({ ...e, category: 'vetVisits', timelineLabel: 'Vétérinaire', collectionName: 'vetVisits', date: e.visitDate, icon: Hospital, color: 'text-red-500', page: '/vet', tab: '' }))

    return events.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
  }, [dayWalks, dayMeals, dayExcretions, dayVomits, daySleep, dayTraining, dayPhysical, dayVet])

  const filteredTimeline = useMemo(() => {
    if (!searchQuery.trim()) return combinedTimeline;
    
    const q = searchQuery.toLowerCase();
    return combinedTimeline.filter(event => {
      const fields = [
        event.notes,
        event.description,
        event.mealType,
        event.brand,
        event.trickName,
        event.visitType,
        event.behavior,
        event.timelineLabel,
        event.customMealType,
        event.customCheck,
        event.medication
      ].filter(Boolean);
      
      return fields.some(field => String(field).toLowerCase().includes(q));
    });
  }, [combinedTimeline, searchQuery]);

  const adjustDate = (amount: number) => {
    const [y, m, d] = searchDate.split('-').map(Number);
    const date = new Date(y, m - 1, d);
    date.setDate(date.getDate() + amount);
    setSearchDate(date.toISOString().split('T')[0]);
  }

  const handleEditNavigation = (event: any) => {
    setViewDayDetails(null);
    setIsJournalOpen(false);
    const returnUrl = encodeURIComponent(pathname);
    router.push(`${event.page}?petId=${currentPet?.id}&tab=${event.tab}&logId=${event.id}&returnTo=${returnUrl}`);
  }

  const handleSaveDailyNote = async () => {
    if (!db || !user || !currentPet?.id || !searchDate) return
    setIsSavingNote(true)
    try {
      await setDoc(doc(db, 'users', user.uid, 'pets', currentPet.id, 'dailyNotes', searchDate), {
        id: searchDate,
        petId: currentPet.id,
        ownerUserId: user.uid,
        content: noteDraft,
        updatedAt: new Date().toISOString()
      }, { merge: true })
      setIsNoteDialogOpen(false)
      toast({ title: "Note mise à jour" })
    } catch (e) {
      toast({ variant: 'destructive', title: "Erreur lors de la sauvegarde" })
    } finally {
      setIsSavingNote(false)
    }
  }

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-background/90 backdrop-blur-lg border-t pb-safe print:hidden">
      <div className="max-w-md mx-auto h-16 flex items-center justify-between px-2">
        <div className="flex flex-1 items-center justify-around" data-tut="nav-left">
          <Link href={`/walks?petId=${currentPet?.id || ''}`} className={cn("flex flex-col items-center gap-1", pathname === '/walks' ? "text-primary" : "text-muted-foreground")}>
            <Footprints className="h-5 w-5" /><span className="text-[9px] font-black uppercase">Balades</span>
          </Link>
          <Link href={`/health?petId=${currentPet?.id || ''}`} className={cn("flex flex-col items-center gap-1", pathname === '/health' ? "text-primary" : "text-muted-foreground")}>
            <HeartPulse className="h-5 w-5" /><span className="text-[9px] font-black uppercase">Santé</span>
          </Link>
        </div>

        <div className="relative -top-5 px-4" data-tut="pet-bubble">
          <Button onClick={() => setIsPetSelectorOpen(true)} className="h-14 w-14 rounded-full p-0 shadow-xl bg-primary border-4 border-background overflow-hidden">
            <Avatar className="h-full w-full">
              <AvatarImage src={currentPet?.profileImageUrl} className="object-cover" />
              <AvatarFallback className="bg-primary text-white"><Dog className="h-6 w-6" /></AvatarFallback>
            </Avatar>
          </Button>
        </div>

        <div className="flex flex-1 items-center justify-around" data-tut="nav-right">
          <Link href={`/physical?petId=${currentPet?.id || ''}`} className={cn("flex flex-col items-center gap-1", pathname === '/physical' ? "text-primary" : "text-muted-foreground")}>
            <Stethoscope className="h-5 w-5" /><span className="text-[9px] font-black uppercase">Physique</span>
          </Link>
          <Link href={`/training?petId=${currentPet?.id || ''}`} className={cn("flex flex-col items-center gap-1", pathname === '/training' ? "text-primary" : "text-muted-foreground")}>
            <BicepsFlexed className="h-5 w-5" /><span className="text-[9px] font-black uppercase">Dressage</span>
          </Link>
        </div>
      </div>

      {/* Journal Dialog */}
      <Dialog open={isJournalOpen} onOpenChange={(open) => { setIsJournalOpen(open); if (!open) forceUnlock(); }}>
        <DialogContent className="sm:max-w-3xl glass-card border-none h-[95vh] sm:h-auto max-h-[95vh] flex flex-col p-0 overflow-hidden shadow-2xl">
          <DialogHeader className="p-4 bg-secondary/20 border-b border-white/5 shrink-0 space-y-4">
            <div className="flex items-center justify-between">
              <DialogTitle className="flex items-center gap-2 text-xl font-black uppercase tracking-tighter">
                <Calendar className="h-6 w-6 text-primary" />
                Journal de {currentPet?.name}
              </DialogTitle>
            </div>

            <div className="space-y-3">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input 
                  placeholder="Rechercher une note, un repas, un trick..." 
                  className="pl-10 bg-background/50 border-white/5 h-10 rounded-xl text-sm"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                {searchQuery && (
                  <button onClick={() => setSearchQuery('')} className="absolute right-3 top-3">
                    <X className="h-4 w-4 text-muted-foreground hover:text-foreground" />
                  </button>
                )}
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <p className="text-[10px] font-black uppercase text-muted-foreground ml-1">Catégorie</p>
                  <Select value={category} onValueChange={(val: any) => setCategory(val)}>
                    <SelectTrigger className="bg-background/50 h-10 rounded-xl border-white/5 text-[10px] uppercase font-black"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Tout Afficher</SelectItem>
                      <SelectItem value="meals">Repas</SelectItem>
                      <SelectItem value="walks">Balades</SelectItem>
                      <SelectItem value="excretions">Selle / Urine</SelectItem>
                      <SelectItem value="vomitIncidents">Vomis</SelectItem>
                      <SelectItem value="sleepRecords">Sommeil & Comp.</SelectItem>
                      <SelectItem value="trainingSessions">Dressage</SelectItem>
                      <SelectItem value="generalInspections">Physique</SelectItem>
                      <SelectItem value="vetVisits">Vétérinaire</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1">
                  <p className="text-[10px] font-black uppercase text-muted-foreground ml-1">Affichage</p>
                  <div className="flex bg-background/50 p-1 rounded-xl border border-white/5 h-10">
                    <Button variant={viewMode === 'day' ? "secondary" : "ghost"} size="sm" className="flex-1 h-full rounded-lg text-[9px] font-bold uppercase p-0" onClick={() => setViewMode('day')}>Par Jour</Button>
                    <Button variant={viewMode === 'all' ? "secondary" : "ghost"} size="sm" className="flex-1 h-full rounded-lg text-[9px] font-bold uppercase p-0" onClick={() => setViewMode('all')}>Tout</Button>
                  </div>
                </div>
              </div>
            </div>

            {viewMode === 'day' && (
              <div className="flex items-center justify-between bg-background/50 p-2 rounded-xl border border-white/5 h-14">
                <Button variant="ghost" size="icon" onClick={() => adjustDate(-1)} className="h-10 w-10 shrink-0"><ChevronLeft className="h-5 w-5" /></Button>
                <div className="flex-1 px-4 relative h-full flex items-center justify-center overflow-hidden">
                  <input 
                    type="date" 
                    value={searchDate ?? ''} 
                    onChange={(e) => setSearchDate(e.target.value)}
                    className="absolute inset-0 opacity-0 w-full cursor-pointer z-10"
                  />
                  <div className="flex flex-col items-center pointer-events-none">
                    <span className="text-[11px] font-black text-primary uppercase">{new Date(searchDate).toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' })}</span>
                    <p className="text-[8px] font-bold text-muted-foreground uppercase opacity-60">Cliquer pour changer</p>
                  </div>
                </div>
                <Button variant="ghost" size="icon" onClick={() => adjustDate(1)} className="h-10 w-10 shrink-0"><ChevronRight className="h-5 w-5" /></Button>
              </div>
            )}
          </DialogHeader>

          <div className="flex-1 overflow-y-auto no-scrollbar overscroll-contain p-4">
            <div className="space-y-6 pb-8">
              {viewMode === 'day' && !searchQuery && (
                <div className="mb-6 animate-in fade-in slide-in-from-top-2 duration-500">
                  <p className="text-[10px] font-black uppercase text-muted-foreground mb-2 ml-1 tracking-widest">Note du jour</p>
                  <Card 
                    className="glass-card border-none shadow-md bg-accent/5 hover:bg-accent/10 transition-all cursor-pointer group"
                    onClick={() => setIsNoteDialogOpen(true)}
                  >
                    <CardContent className="p-4 flex gap-4 items-start">
                      <div className="p-2.5 rounded-xl bg-accent/20 shrink-0">
                        <StickyNote className="h-5 w-5 text-accent" />
                      </div>
                      <div className="flex-1 min-w-0">
                        {dailyNote?.content ? (
                          <p className="text-sm font-medium italic text-foreground leading-relaxed line-clamp-3">
                            "{dailyNote.content}"
                          </p>
                        ) : (
                          <p className="text-xs font-bold text-muted-foreground/50 italic py-1">
                            Aucune note pour ce jour. Cliquer pour en ajouter une...
                          </p>
                        )}
                        <div className="mt-2 flex items-center gap-1 text-[8px] font-black text-accent uppercase opacity-0 group-hover:opacity-100 transition-opacity">
                          MODIFIER LA NOTE <ChevronRight className="h-2 w-2" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {filteredTimeline.length > 0 ? (
                <div className="relative pl-4 space-y-6">
                  <div className="absolute left-[19px] top-2 bottom-4 w-0.5 bg-white/5" />
                  <p className="text-[10px] font-black uppercase text-muted-foreground mb-4 ml-1 tracking-widest">
                    {searchQuery ? `Résultats (${filteredTimeline.length})` : 'Activités'}
                  </p>
                  {filteredTimeline.map((event, idx) => (
                    <div key={idx} className="flex gap-4 relative group active:scale-[0.98] transition-all cursor-pointer" onClick={() => setViewDayDetails(event)}>
                      <div className={cn("z-10 p-2.5 rounded-xl border bg-background/80 backdrop-blur-md shrink-0 h-fit", event.color)}>
                        {React.createElement(event.icon, { className: "h-5 w-5" })}
                      </div>
                      <div className="flex-1 min-w-0 bg-muted/5 border border-white/5 rounded-2xl p-3 shadow-md">
                        <div className="flex justify-between items-center mb-1">
                          <div className="flex flex-col">
                            {(viewMode === 'all' || searchQuery) && <span className="text-[8px] font-black text-primary uppercase">{new Date(event.date).toLocaleDateString('fr-FR')}</span>}
                            <span className="text-[10px] font-black text-muted-foreground uppercase">{new Date(event.date).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</span>
                          </div>
                          <Badge variant="outline" className="text-[8px] font-black uppercase h-4 px-1">{event.timelineLabel}</Badge>
                        </div>
                        <p className="text-xs font-bold truncate">
                          {event.mealType ? `${event.mealType} (${event.quantityGiven || '0'}${event.quantityGivenUnit || ''})` : event.behavior || event.notes || event.trickName || event.visitType || event.timelineLabel}
                        </p>
                        <div className="flex items-center gap-2 mt-2">
                          <span className="text-[9px] font-black text-primary uppercase flex items-center gap-1">CONSULTER <ChevronRight className="h-2.5 w-2.5" /></span>
                          {(event.mediaUrls?.length > 0) && <Badge variant="secondary" className="h-4 px-1 text-[8px] font-black bg-primary/10 text-primary">PHOTOS</Badge>}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-20 opacity-30 text-center">
                  {searchQuery ? <Search className="h-12 w-12 mb-4" /> : <LayoutList className="h-12 w-12 mb-4" />}
                  <p className="font-black uppercase text-xs">{searchQuery ? "Aucun résultat pour cette recherche" : "Aucun événement trouvé"}</p>
                </div>
              )}
            </div>
          </div>
          <DialogFooter className="p-4 bg-muted/10 border-t border-white/5 shrink-0">
            <Button variant="outline" className="w-full h-12 font-black uppercase tracking-widest text-[10px] rounded-xl" onClick={() => setIsJournalOpen(false)}>Fermer le Journal</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Note Edit Dialog */}
      <Dialog open={isNoteDialogOpen} onOpenChange={(open) => { setIsNoteDialogOpen(open); if (!open) forceUnlock(); }}>
        <DialogContent className="sm:max-w-md glass-card border-none shadow-2xl p-6">
          <DialogHeader>
            <DialogTitle className="text-xl font-black uppercase tracking-tighter flex items-center gap-2">
              <StickyNote className="h-6 w-6 text-accent" />
              Note du {new Date(searchDate).toLocaleDateString('fr-FR')}
            </DialogTitle>
            <DialogDescription className="text-[10px] uppercase font-bold text-muted-foreground">
              Décrivez l'état général, l'appétit ou l'humeur de votre compagnon.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Textarea 
              value={noteDraft} 
              onChange={(e) => setNoteDraft(e.target.value)}
              placeholder="Aujourd'hui, il semblait très énergique et a bien mangé..."
              className="min-h-[150px] bg-secondary/20 border-white/5 p-4 rounded-xl"
            />
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setIsNoteDialogOpen(false)} className="rounded-xl">Annuler</Button>
            <Button onClick={handleSaveDailyNote} disabled={isSavingNote} className="bg-accent text-accent-foreground font-black uppercase rounded-xl gap-2">
              {isSavingNote ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              Enregistrer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Detail Dialog */}
      <Dialog open={!!viewDayDetails} onOpenChange={(open) => { if (!open) { setViewDayDetails(null); forceUnlock(); } }}>
        <DialogContent className="sm:max-w-md glass-card border-none h-[90vh] sm:h-auto max-h-[90vh] flex flex-col p-0 overflow-hidden shadow-2xl z-[150]">
          <DialogHeader className="p-6 bg-secondary/20 shrink-0">
            <div className="flex items-center gap-4">
              <div className={cn("p-4 rounded-2xl border bg-muted/50", viewDayDetails && (viewDayDetails as any).color)}>
                {viewDayDetails && React.createElement((viewDayDetails as any).icon, { className: "h-8 w-8" })}
              </div>
              <div className="space-y-1">
                <DialogTitle className="text-2xl font-bold tracking-tight">{(viewDayDetails as any)?.timelineLabel}</DialogTitle>
                <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
                  <Clock className="h-3.5 w-3.5" />
                  {viewDayDetails && new Date((viewDayDetails as any).date).toLocaleString('fr-FR')}
                </div>
              </div>
            </div>
          </DialogHeader>
          
          <div className="flex-1 overflow-y-auto overscroll-contain no-scrollbar">
            <div className="p-6 space-y-8 pb-12">
              <div className="grid grid-cols-2 gap-4">
                {viewDayDetails?.collectionName === 'meals' && (
                  <>
                    <DetailCard label="Type" value={viewDayDetails.mealType} />
                    <DetailCard label="Marque" value={viewDayDetails.brand || '-'} />
                    <DetailCard 
                      label="Consommation" 
                      value={`${viewDayDetails.quantityEatenValue || '0'}${viewDayDetails.quantityGivenUnit || ''} / ${viewDayDetails.quantityGivenValue || '0'}${viewDayDetails.quantityGivenUnit || ''}`} 
                      full 
                    />
                    <DetailCard label="Appétit (%)" value={viewDayDetails.quantityEaten || '--'} full color="text-primary" />
                    <DetailCard icon={Pill} label="Médicaments" value={viewDayDetails.medication || 'Aucun'} full color="text-primary" />
                    <DetailCard icon={GlassWater} label="Eau bue" value={viewDayDetails.waterIntake || 'Moyen'} full color="text-primary" />
                  </>
                )}
                {viewDayDetails?.collectionName === 'vetVisits' && (
                  <>
                    <DetailCard label="Acte" value={viewDayDetails.visitType} full color="text-red-500" />
                    {viewDayDetails.hasFollowUp && (
                      <div className="col-span-2 p-4 rounded-2xl bg-accent/10 border border-accent/20 flex items-center gap-4">
                        <Bell className="h-6 w-6 text-accent" />
                        <div>
                          <p className="text-[10px] font-black uppercase text-accent">{viewDayDetails.nextAppointmentLabel}</p>
                          <p className="text-lg font-bold">{new Date(viewDayDetails.nextAppointmentDate).toLocaleDateString('fr-FR')}</p>
                        </div>
                      </div>
                    )}
                  </>
                )}
                {viewDayDetails?.collectionName === 'excretions' && (
                  <>
                    <DetailCard label="Événement" value={viewDayDetails.type === 'both' ? 'Selle + Urine' : viewDayDetails.type === 'urine' ? 'Urine' : 'Selle'} full />
                    {(viewDayDetails.type === 'urine' || viewDayDetails.type === 'both') && <DetailCard label="Qté Urine" value={viewDayDetails.urineQty} color="text-blue-400" />}
                    {(viewDayDetails.type === 'stool' || viewDayDetails.type === 'both') && (
                      <>
                        <DetailCard label="Couleur Selles" value={viewDayDetails.stoolColor} color="text-orange-500" />
                        <DetailCard label="Texture" value={viewDayDetails.stoolTexture} color="text-orange-500" />
                      </>
                    )}
                    {(viewDayDetails.hasBloodUrine || viewDayDetails.hasBloodStool) && (
                      <div className="col-span-2 p-3 bg-destructive/10 border border-destructive/20 rounded-xl flex items-center gap-3">
                        <AlertTriangle className="h-5 w-5 text-destructive" />
                        <p className="text-xs font-black text-destructive uppercase">Présence de sang détectée</p>
                      </div>
                    )}
                  </>
                )}
                {viewDayDetails?.collectionName === 'walks' && (
                  <>
                    <DetailCard label="Durée" value={`${viewDayDetails.durationMinutes} min`} />
                    <DetailCard label="Distance" value={`${viewDayDetails.distanceKm} km`} />
                    <DetailCard label="Allure" value={`${viewDayDetails.pace || '--'} / km`} color="text-orange-400" />
                    <DetailCard label="Vitesse Moy." value={`${viewDayDetails.averageSpeed || '--'} km/h`} color="text-blue-400" />
                    <DetailCard label="Dénivelé +" value={`${viewDayDetails.elevationGain || '0'} m`} color="text-green-500" />
                    <DetailCard label="Altitude" value={`${viewDayDetails.altitude || '--'} m`} color="text-green-400" />
                    <DetailCard label="Météo" value={`${viewDayDetails.weatherTemp || '--'}°C`} />
                  </>
                )}
                {viewDayDetails?.collectionName === 'trainingSessions' && (
                  <>
                    <DetailCard label="Trick / Exercice" value={viewDayDetails.trickName} full />
                    <DetailCard label="Durée" value={`${viewDayDetails.duration} min`} />
                    <DetailCard label="Statut" value={viewDayDetails.status} />
                  </>
                )}
                {viewDayDetails?.collectionName === 'generalInspections' && (
                  <>
                    <DetailCard label="Type d'activité" value={viewDayDetails.type} full />
                    {viewDayDetails.weightValue && (
                      <DetailCard label="Poids" value={`${viewDayDetails.weightValue} ${viewDayDetails.weightUnit || 'kg'}`} color="text-blue-400" />
                    )}
                    {viewDayDetails.heightValue && (
                      <DetailCard label="Taille" value={`${viewDayDetails.heightValue} ${viewDayDetails.heightUnit || 'cm'}`} color="text-green-400" />
                    )}
                    <div className="col-span-2 space-y-2">
                      <p className="text-[10px] font-black text-muted-foreground uppercase ml-1">Points vérifiés</p>
                      <div className="flex flex-wrap gap-2">
                        {viewDayDetails.checks?.length > 0 ? viewDayDetails.checks.map((c: string) => (
                          <Badge key={c} variant="secondary" className="capitalize bg-blue-500/10 text-blue-400 border-blue-500/20">
                            {c === 'autre' ? `Autre (${viewDayDetails.customCheck || '?'})` : c}
                          </Badge>
                        )) : <p className="text-xs text-muted-foreground italic">Aucun point spécifique</p>}
                      </div>
                    </div>
                  </>
                )}
                {viewDayDetails?.collectionName === 'sleepRecords' && (
                  <>
                    <DetailCard icon={Brain} label="Comportement" value={viewDayDetails.behavior || 'Normal'} full color="text-accent" />
                    <DetailCard label="Type" value={viewDayDetails.type || 'Repos'} />
                    <DetailCard label="Qualité" value={viewDayDetails.quality} />
                    <DetailCard label="Début" value={new Date(viewDayDetails.sleepDate).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })} />
                    <DetailCard label="Réveil" value={new Date(viewDayDetails.sleepEnd).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })} />
                    <DetailCard label="Durée Totale" value={viewDayDetails.duration || '--'} full color="text-primary" />
                  </>
                )}
                {viewDayDetails?.collectionName === 'vomitIncidents' && (
                  <>
                    <DetailCard label="Couleur" value={viewDayDetails.color} color="text-destructive" />
                    <DetailCard label="Quantité" value={viewDayDetails.quantity} color="text-destructive" />
                    {viewDayDetails.hasBlood && (
                      <div className="col-span-2 p-3 bg-destructive/10 border border-destructive/20 rounded-xl flex items-center gap-3">
                        <AlertTriangle className="h-5 w-5 text-destructive" />
                        <p className="text-xs font-black text-destructive uppercase">Présence de sang</p>
                      </div>
                    )}
                  </>
                )}
              </div>

              {(viewDayDetails?.notes || viewDayDetails?.description) && (
                <div className="space-y-2">
                  <p className="text-[10px] font-black text-muted-foreground uppercase ml-1 tracking-widest">Notes & Observations</p>
                  <p className="text-sm italic p-5 bg-muted/20 rounded-2xl leading-relaxed border border-white/5">
                    "{viewDayDetails.notes || viewDayDetails.description}"
                  </p>
                </div>
              )}

              {viewDayDetails?.mediaUrls?.length > 0 && (
                <div className="space-y-4">
                  <p className="text-[10px] font-black text-muted-foreground uppercase ml-1 tracking-widest">Photos ({viewDayDetails.mediaUrls.length})</p>
                  <div className="grid grid-cols-2 gap-3">
                    {viewDayDetails.mediaUrls.map((url: string, i: number) => (
                      <div 
                        key={i} 
                        className="relative aspect-square rounded-2xl overflow-hidden shadow-lg border border-white/10 active:scale-95 transition-transform cursor-pointer" 
                        onClick={(e) => {
                          e.stopPropagation();
                          setFullScreenImage(url);
                        }}
                      >
                        <Image src={url} alt="Photo" fill className="object-cover" />
                        <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                          <Maximize2 className="h-8 w-8 text-white" />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
          <DialogFooter className="p-6 border-t border-white/5 bg-secondary/10 shrink-0 gap-2 flex-row">
            {viewDayDetails?.collectionName !== 'vetVisits' && (
              <Button variant="outline" onClick={() => handleEditNavigation(viewDayDetails)} className="flex-1 h-12 font-black uppercase text-[10px] rounded-xl gap-2">
                <Edit2 className="h-4 w-4" /> Modifier
              </Button>
            )}
            <Button variant="secondary" onClick={() => setViewDayDetails(null)} className="flex-1 h-12 font-black uppercase text-[10px] rounded-xl">Fermer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Full Screen Image Viewer */}
      <Dialog open={!!fullScreenImage} onOpenChange={(open) => { if (!open) { setFullScreenImage(null); forceUnlock(); } }}>
        <DialogContent className="max-w-[100vw] h-full p-0 bg-black/95 border-none flex items-center justify-center z-[300] hide-close">
          <DialogHeader className="sr-only">
            <DialogTitle>Visualisation d'image</DialogTitle>
            <DialogDescription>Agrandissement de la photo sélectionnée en plein écran.</DialogDescription>
          </DialogHeader>
          <div className="relative w-full h-full flex items-center justify-center">
             {fullScreenImage && (
               <Image 
                 src={fullScreenImage} 
                 alt="Photo plein écran" 
                 fill 
                 className="object-contain" 
                 priority 
                 sizes="100vw" 
               />
             )}
             <Button 
               variant="ghost" 
               size="icon" 
               className="absolute top-6 right-6 h-12 w-12 rounded-full bg-black/50 text-white hover:bg-black/70 z-[310]"
               onClick={() => setFullScreenImage(null)}
             >
               <X className="h-8 w-8" />
             </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Pet Selector */}
      <Dialog open={isPetSelectorOpen} onOpenChange={(open) => { setIsPetSelectorOpen(open); if (!open) forceUnlock(); }}>
        <DialogContent className="sm:max-w-md glass-card border-none shadow-2xl p-0 overflow-hidden">
          <DialogHeader className="p-6 pb-2">
            <DialogTitle className="text-xl font-black uppercase tracking-tighter text-center">Mes Compagnons</DialogTitle>
          </DialogHeader>
          
          <div className="px-6 pb-6 space-y-6">
            {currentPet && (
              <Button 
                variant="secondary" 
                className="w-full h-14 bg-primary/10 hover:bg-primary/20 border border-primary/20 rounded-2xl gap-3"
                onClick={() => {
                  router.push(`/pets/${currentPet.id}`);
                  setIsPetSelectorOpen(false);
                  forceUnlock();
                }}
              >
                <FileText className="h-5 w-5 text-primary" />
                <span className="font-bold">Ouvrir le dossier de {currentPet.name}</span>
              </Button>
            )}

            <div className="grid grid-cols-2 gap-4">
              {pets?.map(pet => (
                <div key={pet.id} className="relative group">
                  <Button 
                    variant={currentPet?.id === pet.id ? "secondary" : "outline"} 
                    className={cn(
                      "w-full h-auto py-4 flex flex-col gap-2 rounded-2xl border-2 transition-all", 
                      currentPet?.id === pet.id ? "border-primary bg-primary/10" : "border-white/5"
                    )} 
                    onClick={() => { 
                      updateGlobalPetSelection(pet.id);
                      setIsPetSelectorOpen(false); 
                      forceUnlock(); 
                    }}
                  >
                    <Avatar className="h-12 w-12 border-2 border-background shadow-md">
                      <AvatarImage src={pet.profileImageUrl} className="object-cover" />
                      <AvatarFallback><Dog className="h-5 w-5" /></AvatarFallback>
                    </Avatar>
                    <span className="text-sm font-bold truncate w-full px-2">{pet.name}</span>
                  </Button>
                  
                  {/* Shortcut to other folders */}
                  {currentPet?.id !== pet.id && (
                    <button
                      className="absolute top-2 right-2 p-1.5 rounded-full bg-background/80 hover:bg-primary hover:text-white transition-colors border border-white/10 shadow-sm z-10"
                      onClick={(e) => {
                        e.stopPropagation();
                        router.push(`/pets/${pet.id}`);
                        setIsPetSelectorOpen(false);
                        forceUnlock();
                      }}
                    >
                      <FileText className="h-3 w-3" />
                    </button>
                  )}
                </div>
              ))}
              <Link href="/pets/new" onClick={() => { setIsPetSelectorOpen(false); forceUnlock(); }} className="h-auto py-4 flex flex-col items-center gap-2 rounded-2xl border-dashed border-2 opacity-60 border-white/20 hover:opacity-100 hover:border-primary/50 transition-all bg-muted/5">
                <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center"><Plus className="h-5 w-5" /></div>
                <span className="text-[10px] font-black uppercase">Ajouter</span>
              </Link>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </nav>
  )
}

function DetailCard({ icon: Icon, label, value, color = "text-primary", full = false }: { icon?: any, label: string, value: string, color?: string, full?: boolean }) {
  return (
    <div className={cn("p-4 rounded-2xl bg-secondary/30 border border-white/5 space-y-1", full ? "col-span-2" : "")}>
      <div className="flex items-center gap-2">
        {Icon && <Icon className={cn("h-3 w-3", color)} />}
        <p className={cn("text-[10px] font-black uppercase tracking-widest opacity-70", color)}>{label}</p>
      </div>
      <p className="text-lg font-bold truncate">{value}</p>
    </div>
  )
}
