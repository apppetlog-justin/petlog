
import React from 'react'
import { Card, CardContent } from '@/components/ui/card'
import { LucideIcon } from 'lucide-react'

interface StatCardProps {
  label: string
  value: string | number
  icon: LucideIcon
  description?: string
  trend?: {
    value: number
    positive: boolean
  }
}

export function StatCard({ label, value, icon: Icon, description, trend }: StatCardProps) {
  return (
    <Card className="glass-card overflow-hidden">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className="flex flex-col gap-1">
            <span className="text-sm font-medium text-muted-foreground">{label}</span>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold">{value}</span>
              {trend && (
                <span className={`text-xs ${trend.positive ? 'text-green-500' : 'text-red-500'}`}>
                  {trend.positive ? '+' : '-'}{trend.value}%
                </span>
              )}
            </div>
          </div>
          <div className="p-3 bg-primary/10 rounded-full">
            <Icon className="h-5 w-5 text-primary" />
          </div>
        </div>
        {description && (
          <p className="mt-4 text-xs text-muted-foreground italic">
            {description}
          </p>
        )}
      </CardContent>
    </Card>
  )
}
