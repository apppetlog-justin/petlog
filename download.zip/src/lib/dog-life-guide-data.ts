/**
 * @fileOverview Base de données exhaustive pour le guide de vie des chiens par race.
 * Inspirée des philosophies de Cesar Millan (Exercice, Discipline, Affection) 
 * et des conseils pratiques et positifs de Peps & Scott (Enrichissement, Flair, Signaux).
 * 
 * NOTE: Ce guide prend en compte que l'arrivée au foyer se fait généralement à 8 semaines.
 */

export type LifeStage = {
  id: string;
  title: string;
  startWeek?: number;
  endWeek?: number;
  startMonth?: number;
  endMonth?: number;
  startYear?: number;
  endYear?: number;
  mealsPerDay: number;
  sleepHours: number;
  exerciseIntensity: 'low' | 'moderate' | 'high' | 'very_high';
  walkDurationMinutes: number; 
  walksPerDay: number;
  trainingSessionsPerDay: number;
  enrichmentType: string;
  groomingFrequency: string;
  socializationFocus: string[];
  keyActions: string[];
  behavioralTips: string[];
  healthMilestones: string[];
  description: string;
};

export type BreedSpecs = {
  energyLevel: number; // 1-5
  trainability: number; // 1-5
  groomingNeed: 'low' | 'medium' | 'high';
  healthRisks: string[];
  seniorAge: number; 
};

export const BREED_SPECS: Record<string, BreedSpecs> = {
  "Golden Retriever": { energyLevel: 4, trainability: 5, groomingNeed: 'high', healthRisks: ["Dysplasie hanche/coude", "Obésité", "Cataracte", "Otites"], seniorAge: 8 },
  "Labrador": { energyLevel: 4, trainability: 5, groomingNeed: 'medium', healthRisks: ["Obésité (crucial)", "Articulations", "Torsion estomac"], seniorAge: 8 },
  "Berger Allemand": { energyLevel: 5, trainability: 5, groomingNeed: 'medium', healthRisks: ["Dysplasie sévère", "Myélopathie dégénérative", "Torsion estomac"], seniorAge: 7 },
  "Bouledogue Français": { energyLevel: 2, trainability: 3, groomingNeed: 'low', healthRisks: ["Syndrome Brachycéphale (respiration)", "Hernies discales", "Insolations"], seniorAge: 9 },
  "Beagle": { energyLevel: 4, trainability: 3, groomingNeed: 'low', healthRisks: ["Otites (oreilles tombantes)", "Obésité", "Épilepsie", "Hypothyroïdie"], seniorAge: 10 },
  "Poodle (Caniche)": { energyLevel: 3, trainability: 5, groomingNeed: 'high', healthRisks: ["Atrophie rétine", "Luxation rotule", "Maladie d'Addison"], seniorAge: 11 },
  "Rottweiler": { energyLevel: 4, trainability: 4, groomingNeed: 'low', healthRisks: ["Sténose aortique", "Dysplasie", "Entropion (paupières)"], seniorAge: 7 },
  "Yorkshire Terrier": { energyLevel: 3, trainability: 4, groomingNeed: 'high', healthRisks: ["Dents (tartre)", "Trachée fragile", "Hypoglycémie"], seniorAge: 12 },
  "Boxer": { energyLevel: 5, trainability: 4, groomingNeed: 'low', healthRisks: ["Cancers (mastocytomes)", "Cardiopathie", "Torsion estomac"], seniorAge: 8 },
  "Teckel": { energyLevel: 3, trainability: 3, groomingNeed: 'medium', healthRisks: ["Dos (Paralysie/Hernie)", "Obésité", "Maladie de Cushing"], seniorAge: 11 },
  "Chihuahua": { energyLevel: 3, trainability: 3, groomingNeed: 'low', healthRisks: ["Hydrocéphalie", "Collapsus trachée", "Cœur (valvules)"], seniorAge: 13 },
  "Border Collie": { energyLevel: 5, trainability: 5, groomingNeed: 'high', healthRisks: ["Anomalie de l'œil du Colley", "Hanches", "Sensibilité médicamenteuse (MDR1)"], seniorAge: 9 },
  "Malinois": { energyLevel: 5, trainability: 5, groomingNeed: 'low', healthRisks: ["Hanches", "Coudes", "Hyper-sensibilité sensorielle"], seniorAge: 9 },
  "Autre (Croisé)": { energyLevel: 3, trainability: 4, groomingNeed: 'medium', healthRisks: ["Variable selon morphologie"], seniorAge: 10 }
};

export const getLifeGuide = (breedName: string): LifeStage[] => {
  const specs = BREED_SPECS[breedName] || BREED_SPECS["Autre (Croisé)"];
  const getWalkMins = (base: number) => Math.round(base + (specs.energyLevel * 5));
  
  return [
    {
      id: 'neonatal',
      title: 'Éleveur : Néonatale (0-2 sem.)',
      startWeek: 0, endWeek: 2,
      mealsPerDay: 8, sleepHours: 22, walksPerDay: 0, walkDurationMinutes: 0, trainingSessionsPerDay: 0,
      enrichmentType: 'Tactile thermique',
      groomingFrequency: 'Léchage maternel',
      exerciseIntensity: 'low',
      socializationFocus: ["Manipulation ultra-douce", "Odeur du propriétaire", "Sons biologiques"],
      keyActions: ["Pesée quotidienne", "Surveillance température", "Contrôle réflexe succion"],
      behavioralTips: ["Ne pas séparer de la fratrie", "Silence absolu autour du nid", "Énergie calme obligatoire"],
      healthMilestones: ["Examen néonatal", "Vermifuge (J15)"],
      description: "Le chiot est sourd et aveugle. Tout passe par le nez et le toucher. La chaleur est vitale. Phase gérée par l'éleveur."
    },
    {
      id: 'transition',
      title: 'Éleveur : Éveil Sensoriel (2-4 sem.)',
      startWeek: 2, endWeek: 4,
      mealsPerDay: 6, sleepHours: 20, walksPerDay: 0, walkDurationMinutes: 0, trainingSessionsPerDay: 0,
      enrichmentType: 'Découverte visuelle',
      groomingFrequency: 'Hebdomadaire',
      exerciseIntensity: 'low',
      socializationFocus: ["Sons domestiques faibles", "Contact visuel humain", "Différentes textures au sol"],
      keyActions: ["Ouverture des yeux (J12)", "Audition (J21)", "Exploration hors du nid"],
      behavioralTips: ["Initier le contact visuel", "Pas de bruits brusques", "Respecter les cycles de sommeil"],
      healthMilestones: ["Premières dents de lait", "Vérification audition"],
      description: "Les sens s'éveillent. C'est le début de l'interaction consciente avec le monde chez l'éleveur."
    },
    {
      id: 'imprinting_1',
      title: 'Éleveur : Imprégnation I (4-8 sem.)',
      startWeek: 4, endWeek: 8,
      mealsPerDay: 4, sleepHours: 18, walksPerDay: 0, walkDurationMinutes: 0, trainingSessionsPerDay: 1,
      enrichmentType: 'Jeux de fratrie',
      groomingFrequency: 'Hebdomadaire',
      exerciseIntensity: 'low',
      socializationFocus: ["Inhibition de la morsure", "Jeux de fratrie", "Humains calmes divers"],
      keyActions: ["Sevrage progressif", "Mastication", "Apprentissage zone herbe"],
      behavioralTips: ["Stopper le jeu si morsure", "Limites sociales", "Découverte objets mobiles"],
      healthMilestones: ["Vermifuge (Mois 1)", "Primo-vaccination (Semaine 8)"],
      description: "Apprentissage crucial des codes canins. Le chiot termine sa période de sevrage avec sa fratrie."
    },
    {
      id: 'fear_period_1',
      title: 'MAISON : Arrivée & Peur (8-10 sem.)',
      startWeek: 8, endWeek: 10,
      mealsPerDay: 4, sleepHours: 18, walksPerDay: 3, walkDurationMinutes: 5, trainingSessionsPerDay: 2,
      enrichmentType: 'Exploration sécurisée',
      groomingFrequency: specs.groomingNeed === 'high' ? 'Quotidien' : 'Hebdomadaire',
      exerciseIntensity: 'low',
      socializationFocus: ["Maison sécurisante", "Bruits de rue lointains", "Solitude progressive"],
      keyActions: ["Rappel au nom", "Suivi naturel", "Propreté (toutes les 2h)"],
      behavioralTips: ["Période de peur : ne pas forcer", "Ignorer les peurs, récompenser le courage", "Routine fixe pour rassurer"],
      healthMilestones: ["Contrôle parasites externes", "Alimentation chiot haute qualité"],
      description: "Bienvenue à la maison ! Transition majeure. Le chiot est très sensible aux traumatismes durant ces 2 semaines."
    },
    {
      id: 'imprinting_2',
      title: 'Âge d\'Or (10-16 sem.)',
      startWeek: 10, endWeek: 16,
      mealsPerDay: 3, sleepHours: 16, walksPerDay: 3, walkDurationMinutes: 15, trainingSessionsPerDay: 4,
      enrichmentType: 'Travail de flair',
      groomingFrequency: 'Hebdomadaire',
      exerciseIntensity: 'moderate',
      socializationFocus: ["Chiens adultes régulateurs", "Marchés", "Enfants", "Longe (5m)"],
      keyActions: ["Positions de base", "Marche en longe", "Auto-contrôles (attendre le bol)"],
      behavioralTips: ["Le flair fatigue plus que la course", "Socialisation positive", "Respect des signaux d'apaisement"],
      healthMilestones: ["Rappel de vaccins", "Identification (Puce) vérifiée"],
      description: "Phase critique. Tout ce qui est vu positivement maintenant est acquis pour la vie. Sortez avec modération mais régularité."
    },
    {
      id: 'juvenile',
      title: 'Pré-Adolescence (4-6 mois)',
      startMonth: 4, endMonth: 6,
      mealsPerDay: 3, sleepHours: 14, walksPerDay: 3, walkDurationMinutes: 20, trainingSessionsPerDay: 3,
      enrichmentType: 'Mastication longue',
      groomingFrequency: 'Hebdomadaire',
      exerciseIntensity: 'moderate',
      socializationFocus: ["Transports", "Cafés", "Vélos", "Rappel avec distractions"],
      keyActions: ["Dents définitives", "Pas bouger (durée)", "Apprentissage du 'Tu laisses'"],
      behavioralTips: ["Mastication pour apaiser les dents", "Enrichissement olfactif", "Stabilité émotionnelle"],
      healthMilestones: ["Perte des dents de lait", "Contrôle poids (pic de croissance)"],
      description: "Test de l'autonomie. Le chien commence à s'éloigner de vous. Gardez la structure et la patience."
    },
    {
      id: 'adolescence',
      title: 'Adolescence (6-12 mois)',
      startMonth: 6, endMonth: 12,
      mealsPerDay: 2, sleepHours: 12, walksPerDay: 2, walkDurationMinutes: getWalkMins(25), trainingSessionsPerDay: 3,
      enrichmentType: 'Puzzles mentaux',
      groomingFrequency: 'Hebdomadaire',
      exerciseIntensity: 'high',
      socializationFocus: ["Gestion de la frustration", "Rencontres sélectives", "Calme en public"],
      keyActions: ["Marche au pied", "Dépense mentale intensive", "Rappel 100%"],
      behavioralTips: ["Drainer l'énergie hormonale", "Patience : surdité sélective possible", "Longe obligatoire si rappel faiblit"],
      healthMilestones: ["Discussion stérilisation", "Radiographies hanches (si risque)"],
      description: "Tempête hormonale. Le 'cerveau' débranche parfois. Reprenez les bases avec patience."
    },
    {
      id: 'maturation',
      title: 'Maturation (12-24 mois)',
      startMonth: 12, endMonth: 24,
      mealsPerDay: 2, sleepHours: 12, walksPerDay: 2, walkDurationMinutes: getWalkMins(35), trainingSessionsPerDay: 2,
      enrichmentType: 'Sports canins',
      groomingFrequency: 'Régulier',
      exerciseIntensity: 'high',
      socializationFocus: ["Consolidation des acquis", "Calme en présence de congénères"],
      keyActions: ["Endurance progressive", "Mantrailing / Agility", "Vie sociale stable"],
      behavioralTips: ["Affirmer le leadership calme", "Travail de concentration", "Routine de travail/repos"],
      healthMilestones: ["Bilan fin de croissance", "Transition nourriture adulte"],
      description: "Le caractère se fixe. Les dernières peurs d'adulte peuvent apparaître. Restez le roc."
    },
    {
      id: 'adult',
      title: 'Adulte (2 - ' + specs.seniorAge + ' ans)',
      startYear: 2, endYear: specs.seniorAge,
      mealsPerDay: 2, sleepHours: 12, walksPerDay: 2, walkDurationMinutes: getWalkMins(40), trainingSessionsPerDay: 2,
      enrichmentType: 'Missions / Travail',
      groomingFrequency: specs.groomingNeed === 'high' ? 'Bi-Hebdomadaire' : 'Hebdomadaire',
      exerciseIntensity: 'high',
      socializationFocus: ["Entretien des acquis", "Vie de famille stable"],
      keyActions: ["Check-up annuel", "Hygiène dentaire", "Maintien musculaire"],
      behavioralTips: ["Donnez-lui une mission", "Routine stimulante", "Affection = Récompense du calme"],
      healthMilestones: ["Détartrage possible", "Bilan sanguin de base"],
      description: "L'âge de l'équilibre. Le chien a besoin de clarté, d'activité et de repos structuré."
    },
    {
      id: 'senior',
      title: 'Sénior (' + specs.seniorAge + ' ans +)',
      startYear: specs.seniorAge, endYear: 25,
      mealsPerDay: 2, sleepHours: 16, walksPerDay: 3, walkDurationMinutes: 20, trainingSessionsPerDay: 1,
      enrichmentType: 'Flair doux / Léchage',
      groomingFrequency: 'Quotidien (Massage)',
      exerciseIntensity: 'low',
      socializationFocus: ["Sérénité", "Environnements familiers", "Jeunes chiens calmes"],
      keyActions: ["Bilan gériatrique complet", "Confort articulaire", "Aménagement maison"],
      behavioralTips: ["Le flair garde le cerveau jeune", "Adaptation physique", "Douceur extrême"],
      healthMilestones: ["Contrôle rénal/cardiaque", "Suppléments articulaires"],
      description: "Ralentissement global. Priorité absolue au confort et à la stimulation mentale douce."
    }
  ];
};
