export const firebaseConfig = {
  "projectId": "studio-1928063767-9fbdf",
  "appId": "1:621533997713:web:5295ffbf114025e3f86d30",
  "apiKey": "AIzaSyD2ThAXChmaIheRHillbbU_cunRClTcjM4",
  "authDomain": "studio-1928063767-9fbdf.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "621533997713"
};
