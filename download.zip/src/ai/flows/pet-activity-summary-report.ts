'use server';
/**
 * @fileOverview A Genkit flow for generating a concise summary report of a pet's recent health, activity, and training data.
 *
 * - petActivitySummaryReport - A function that handles the generation of the pet activity summary report.
 * - PetActivitySummaryReportInput - The input type for the petActivitySummaryReport function.
 * - PetActivitySummaryReportOutput - The return type for the petActivitySummaryReport function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const PetProfileSchema = z.object({
  name: z.string().describe("Pet's name."),
  birthdate: z.string().optional().describe("Pet's birthdate (YYYY-MM-DD)."),
  gender: z.string().optional().describe("Pet's gender."),
  animalType: z.string().describe("Pet's animal type (e.g., 'dog', 'cat')."),
  breed: z.string().optional().describe("Pet's breed, if applicable."),
});

const WalkLogSchema = z.object({
  date: z.string().describe('Date of the walk (YYYY-MM-DD).'),
  durationMinutes: z.number().describe('Duration of the walk in minutes.'),
  distanceKm: z.number().optional().describe('Distance of the walk in kilometers.'),
  notes: z.string().optional().describe('Notes about the walk.'),
});

const TrainingLogSchema = z.object({
  date: z.string().describe('Date of the training session (YYYY-MM-DD).'),
  trickName: z.string().describe('Name of the trick practiced.'),
  durationMinutes: z.number().describe('Duration of the training session in minutes.'),
  status: z.string().describe("Training status (e.g., 'In Progress', 'Mastered')."),
  notes: z.string().optional().describe('Notes about the training session.'),
});

const MealLogSchema = z.object({
  date: z.string().describe('Date of the meal (YYYY-MM-DD).'),
  type: z.string().describe('Type of food.'),
  brand: z.string().optional().describe('Brand of food.'),
  quantity: z.string().describe('Quantity of food (e.g., "1 cup", "100g").'),
});

const ExcretionLogSchema = z.object({
  date: z.string().describe('Date of the excretion (YYYY-MM-DD).'),
  type: z.enum(['urine', 'stools']).describe('Type of excretion.'),
  color: z.string().optional().describe('Color of the excretion.'),
  texture: z.string().optional().describe('Texture of the excretion.'),
  notes: z.string().optional().describe('Notes about the excretion.'),
});

const VomitLogSchema = z.object({
  date: z.string().describe('Date of the vomit incident (YYYY-MM-DD).'),
  color: z.string().optional().describe('Color of the vomit.'),
  quantity: z.string().optional().describe('Quantity of vomit (e.g., "small", "large").'),
  notes: z.string().optional().describe('Notes about the vomit incident.'),
});

const SleepLogSchema = z.object({
  date: z.string().describe('Date of the sleep record (YYYY-MM-DD).'),
  durationHours: z.number().describe('Duration of sleep in hours.'),
  quality: z.string().optional().describe("Quality of sleep (e.g., 'good', 'restless')."),
});

const PhysicalObservationSchema = z.object({
  date: z.string().describe('Date of the observation (YYYY-MM-DD).'),
  type: z.enum(['weight', 'grooming', 'inspection']).describe('Type of observation.'),
  value: z.string().optional().describe('Value for weight (e.g., "15 kg") or details for grooming/inspection.'),
  notes: z.string().optional().describe('Notes about the observation.'),
});

const PetActivitySummaryReportInputSchema = z.object({
  petProfile: PetProfileSchema.describe('Details about the pet.'),
  recentWalks: z.array(WalkLogSchema).optional().describe('A list of recent walk logs.'),
  recentTraining: z.array(TrainingLogSchema).optional().describe('A list of recent training session logs.'),
  recentMeals: z.array(MealLogSchema).optional().describe('A list of recent meal logs.'),
  recentExcretions: z.array(ExcretionLogSchema).optional().describe('A list of recent excretion logs.'),
  recentVomitIncidents: z.array(VomitLogSchema).optional().describe('A list of recent vomit incidents.'),
  recentSleep: z.array(SleepLogSchema).optional().describe('A list of recent sleep pattern logs.'),
  recentPhysicalObservations: z.array(PhysicalObservationSchema).optional().describe('A list of recent physical observation records.'),
});
export type PetActivitySummaryReportInput = z.infer<typeof PetActivitySummaryReportInputSchema>;

const PetActivitySummaryReportOutputSchema = z.string().describe('A concise summary report of the pet\'s recent well-being, key trends, and actionable insights.');
export type PetActivitySummaryReportOutput = z.infer<typeof PetActivitySummaryReportOutputSchema>;

export async function petActivitySummaryReport(input: PetActivitySummaryReportInput): Promise<PetActivitySummaryReportOutput> {
  return petActivitySummaryReportFlow(input);
}

const petActivitySummaryReportPrompt = ai.definePrompt({
  name: 'petActivitySummaryReportPrompt',
  input: { schema: PetActivitySummaryReportInputSchema },
  output: { schema: PetActivitySummaryReportOutputSchema },
  prompt: `You are an AI assistant specialized in pet care. Your task is to generate a concise summary report for a pet owner based on the provided recent health, activity, and training data.

Focus on the pet's overall well-being, identify key trends (positive or negative), and offer actionable insights or suggestions for tailored care improvements.

Pet Profile:
Name: {{{petProfile.name}}}
Animal Type: {{{petProfile.animalType}}}{{#if petProfile.breed}} ({{{petProfile.breed}}}){{/if}}{{#if petProfile.birthdate}}
Birthdate: {{{petProfile.birthdate}}}{{/if}}{{#if petProfile.gender}}
Gender: {{{petProfile.gender}}}{{/if}}

Recent Data Analysis:

{{#if recentWalks}}
Walks:
{{#each recentWalks}}
- Date: {{{date}}}, Duration: {{{durationMinutes}}} mins{{#if distanceKm}}, Distance: {{{distanceKm}}} km{{/if}}{{#if notes}}, Notes: "{{{notes}}}"{{/if}}
{{/each}}
{{/if}}

{{#if recentTraining}}
Training Sessions:
{{#each recentTraining}}
- Date: {{{date}}}, Trick: {{{trickName}}}, Duration: {{{durationMinutes}}} mins, Status: {{{status}}}{{#if notes}}, Notes: "{{{notes}}}"{{/if}}
{{/each}}
{{/if}}

{{#if recentMeals}}
Meals:
{{#each recentMeals}}
- Date: {{{date}}}, Type: {{{type}}}{{#if brand}}, Brand: {{{brand}}}{{/if}}, Quantity: {{{quantity}}}
{{/each}}
{{/if}}

{{#if recentExcretions}}
Excretions:
{{#each recentExcretions}}
- Date: {{{date}}}, Type: {{{type}}}{{#if color}}, Color: {{{color}}}{{/if}}{{#if texture}}, Texture: {{{texture}}}{{/if}}{{#if notes}}, Notes: "{{{notes}}}"{{/if}}
{{/each}}
{{/if}}

{{#if recentVomitIncidents}}
Vomit Incidents:
{{#each recentVomitIncidents}}
- Date: {{{date}}}{{#if color}}, Color: {{{color}}}{{/if}}{{#if quantity}}, Quantity: {{{quantity}}}{{/if}}{{#if notes}}, Notes: "{{{notes}}}"{{/if}}
{{/each}}
{{/if}}

{{#if recentSleep}}
Sleep Patterns:
{{#each recentSleep}}
- Date: {{{date}}}, Duration: {{{durationHours}}} hours{{#if quality}}, Quality: {{{quality}}}{{/if}}
{{/each}}
{{/if}}

{{#if recentPhysicalObservations}}
Physical Observations:
{{#each recentPhysicalObservations}}
- Date: {{{date}}}, Type: {{{type}}}{{#if value}}, Value/Details: {{{value}}}{{/if}}{{#if notes}}, Notes: "{{{notes}}}"{{/if}}
{{/each}}
{{/if}}

Generate the summary report now. Be concise and focus on insights.
`,
});

const petActivitySummaryReportFlow = ai.defineFlow(
  {
    name: 'petActivitySummaryReportFlow',
    inputSchema: PetActivitySummaryReportInputSchema,
    outputSchema: PetActivitySummaryReportOutputSchema,
  },
  async (input) => {
    const {output} = await petActivitySummaryReportPrompt(input);
    return output!;
  }
);
