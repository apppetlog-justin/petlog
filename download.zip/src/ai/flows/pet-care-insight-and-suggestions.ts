
'use server';
/**
 * @fileOverview Ce fichier implémente un flux Genkit pour la fonctionnalité d'Assistant IA de l'application PetLog.
 * Il analyse les données de santé et d'activité enregistrées pour un animal afin de générer des rapports de synthèse,
 * proposer des analyses exploitables et suggérer des améliorations de soins personnalisées.
 *
 * - petCareInsightAndSuggestions - Une fonction qui gère le processus d'analyse et de suggestions par IA.
 * - PetCareInsightAndSuggestionsInput - Le type d'entrée pour la fonction petCareInsightAndSuggestions.
 * - PetCareInsightAndSuggestionsOutput - Le type de retour pour la fonction petCareInsightAndSuggestions.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

// Schémas d'entrée
const PetProfileSchema = z.object({
  name: z.string().describe("Le nom de l'animal."),
  animalType: z.string().describe("Le type d'animal (ex: 'chien', 'chat')."),
  breed: z.string().optional().describe("La race de l'animal, si applicable."),
});

const MealEntrySchema = z.object({
  timestamp: z.string().describe("Horodatage ISO du repas."),
  type: z.string().describe("Type de nourriture (ex: 'Croquettes', 'Pâtée')."),
  brand: z.string().describe("Marque de la nourriture."),
  quantity: z.string().describe("Quantité donnée (ex: '1 tasse')."),
});

const ExcretionEntrySchema = z.object({
  timestamp: z.string().describe("Horodatage ISO de l'excrétion."),
  type: z.enum(['urine', 'stools']).describe("Type d'excrétion (urine ou selles)."),
  color: z.string().optional().describe("Couleur de l'excrétion."),
  texture: z.string().optional().describe("Texture de l'excrétion."),
  notes: z.string().optional().describe("Notes additionnelles."),
});

const VomitIncidentSchema = z.object({
  timestamp: z.string().describe("Horodatage ISO du vomissement."),
  color: z.string().optional().describe("Couleur du vomi."),
  quantity: z.string().optional().describe("Quantité."),
  notes: z.string().optional().describe("Notes additionnelles."),
});

const SleepPatternSchema = z.object({
  timestamp: z.string().describe("Horodatage ISO de la période de sommeil."),
  durationHours: z.number().describe("Durée du sommeil en heures."),
  quality: z.enum(['good', 'fair', 'poor']).describe("Qualité du sommeil."),
  notes: z.string().optional().describe("Notes additionnelles."),
});

const WalkEntrySchema = z.object({
  timestamp: z.string().describe("Horodatage ISO de la promenade."),
  durationMinutes: z.number().describe("Durée de la promenade en minutes."),
  distanceKm: z.number().describe("Distance de la promenade en kilomètres."),
  notes: z.string().optional().describe("Notes additionnelles."),
});

const TrainingSessionSchema = z.object({
  timestamp: z.string().describe("Horodatage ISO de la séance d'entraînement."),
  trickName: z.string().describe("Nom du tour ou exercice travaillé."),
  durationMinutes: z.number().describe("Durée de la séance en minutes."),
  status: z.enum(['In Progress', 'Mastered']).describe("Statut de l'apprentissage."),
  notes: z.string().optional().describe("Notes additionnelles."),
});

const WeightRecordSchema = z.object({
  timestamp: z.string().describe("Horodatage ISO de la pesée."),
  weightKg: z.number().describe("Poids de l'animal en kilogrammes."),
});

const GroomingRecordSchema = z.object({
  timestamp: z.string().describe("Horodatage ISO de l'activité de toilettage."),
  activity: z.string().describe("Type de toilettage (ex: 'bain', 'brossage', 'coupe de griffes')."),
  notes: z.string().optional().describe("Notes additionnelles."),
});

const GeneralInspectionRecordSchema = z.object({
  timestamp: z.string().describe("Horodatage ISO de l'inspection."),
  notes: z.string().describe("Notes générales de l'inspection."),
  checklist: z.array(z.string()).describe("Liste des éléments vérifiés (ex: 'yeux clairs', 'oreilles propres')."),
});

const PetCareInsightAndSuggestionsInputSchema = z.object({
  petProfile: PetProfileSchema.describe("Informations générales sur le profil de l'animal."),
  recentMeals: z.array(MealEntrySchema).describe("Liste des repas récents (jusqu'à 5).").optional(),
  recentExcretions: z.array(ExcretionEntrySchema).describe("Liste des excrétions récentes (jusqu'à 5).").optional(),
  recentVomitIncidents: z.array(VomitIncidentSchema).describe("Liste des vomissements récents (jusqu'à 3).").optional(),
  recentSleepPatterns: z.array(SleepPatternSchema).describe("Liste des périodes de sommeil récentes (jusqu'à 5).").optional(),
  recentWalks: z.array(WalkEntrySchema).describe("Liste des promenades récentes (jusqu'à 5).").optional(),
  recentTrainingSessions: z.array(TrainingSessionSchema).describe("Liste des séances d'entraînement récentes (jusqu'à 5).").optional(),
  recentWeights: z.array(WeightRecordSchema).describe("Liste des pesées récentes (jusqu'à 3).").optional(),
  lastGroomingRecord: GroomingRecordSchema.optional().describe("Dernier enregistrement de toilettage."),
  lastGeneralInspection: GeneralInspectionRecordSchema.optional().describe("Dernière inspection physique générale."),
});

export type PetCareInsightAndSuggestionsInput = z.infer<typeof PetCareInsightAndSuggestionsInputSchema>;

const PetCareInsightAndSuggestionsOutputSchema = z.object({
  summaryReport: z.string().describe("Un rapport de synthèse sur la santé et les activités récentes de l'animal."),
  actionableInsights: z.array(z.string()).describe("Une liste d'observations spécifiques ou de zones nécessitant une attention particulière."),
  suggestions: z.array(z.string()).describe("Une liste de recommandations de soins personnalisées."),
});

export type PetCareInsightAndSuggestionsOutput = z.infer<typeof PetCareInsightAndSuggestionsOutputSchema>;

export async function petCareInsightAndSuggestions(input: PetCareInsightAndSuggestionsInput): Promise<PetCareInsightAndSuggestionsOutput> {
  return petCareInsightAndSuggestionsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'petCareInsightAndSuggestionsPrompt',
  input: {schema: PetCareInsightAndSuggestionsInputSchema},
  output: {schema: PetCareInsightAndSuggestionsOutputSchema},
  prompt: `Vous êtes un assistant IA spécialisé dans les soins aux animaux pour l'application PetLog. Votre rôle est d'analyser les données de santé et d'activité enregistrées pour un animal, d'identifier des schémas, des écarts par rapport à la normale et de fournir des conseils et suggestions personnalisés.

**IMPORTANT : Vous devez répondre exclusivement en français.**

Voici les données pour l'animal :

Profil :
Nom : {{{petProfile.name}}}
Type : {{{petProfile.animalType}}}{{#if petProfile.breed}}
Race : {{{petProfile.breed}}}{{/if}}

Repas récents :
{{#if recentMeals}}
  {{#each recentMeals}}
    - {{timestamp}}: {{quantity}} de {{type}} ({{brand}})
  {{/each}}
{{else}}
  Aucune donnée de repas.
{{/if}}

Excrétions récentes :
{{#if recentExcretions}}
  {{#each recentExcretions}}
    - {{timestamp}}: Type: {{type}}{{#if color}}, Couleur: {{color}}{{/if}}{{#if texture}}, Texture: {{texture}}{{/if}}{{#if notes}}, Notes: "{{{notes}}}"{{/if}}
  {{/each}}
{{else}}
  Aucune donnée d'excrétion.
{{/if}}

Vomissements récents :
{{#if recentVomitIncidents}}
  {{#each recentVomitIncidents}}
    - {{timestamp}}: Quantité: {{quantity}}{{#if color}}, Couleur: {{color}}{{/if}}{{#if notes}}, Notes: "{{{notes}}}"{{/if}}
  {{/each}}
{{else}}
  Aucun vomissement signalé.
{{/if}}

Sommeil récent :
{{#if recentSleepPatterns}}
  {{#each recentSleepPatterns}}
    - {{timestamp}}: Durée: {{durationHours}} heures, Qualité: {{quality}}{{#if notes}}, Notes: "{{{notes}}}"{{/if}}
  {{/each}}
{{else}}
  Aucune donnée de sommeil.
{{/if}}

Promenades récentes :
{{#if recentWalks}}
  {{#each recentWalks}}
    - {{timestamp}}: Durée: {{durationMinutes}} min, Distance: {{distanceKm}} km{{#if notes}}, Notes: "{{{notes}}}"{{/if}}
  {{/each}}
{{else}}
  Aucune donnée de promenade.
{{/if}}

Entraînements récents :
{{#if recentTrainingSessions}}
  {{#each recentTrainingSessions}}
    - {{timestamp}}: Tour: {{trickName}}, Durée: {{durationMinutes}} min, Statut: {{status}}{{#if notes}}, Notes: "{{{notes}}}"{{/if}}
  {{/each}}
{{else}}
  Aucune donnée d'entraînement.
{{/if}}

Pesées récentes :
{{#if recentWeights}}
  {{#each recentWeights}}
    - {{timestamp}}: {{weightKg}} kg
  {{/each}}
{{else}}
  Aucune donnée de poids.
{{/if}}

Toilettage :
{{#if lastGroomingRecord}}
  - {{lastGroomingRecord.timestamp}}: Activité: {{lastGroomingRecord.activity}}{{#if lastGroomingRecord.notes}}, Notes: "{{{lastGroomingRecord.notes}}}"{{/if}}
{{else}}
  Aucun enregistrement de toilettage.
{{/if}}

Inspection générale :
{{#if lastGeneralInspection}}
  - {{lastGeneralInspection.timestamp}}: Notes: "{{{lastGeneralInspection.notes}}}", Checklist: {{#each lastGeneralInspection.checklist}} "{{{this}}}" {{/each}}
{{else}}
  Aucune inspection physique récente.
{{/if}}

Analysez ces données pour :
1. Fournir un rapport de synthèse concis sur la santé et les activités de {{{petProfile.name}}}.
2. Identifier tout écart potentiel par rapport aux habitudes normales ou des points d'attention.
3. Proposer des suggestions exploitables pour améliorer les soins de {{{petProfile.name}}}.

Votre réponse doit être un objet JSON valide conforme au schéma PetCareInsightAndSuggestionsOutputSchema. Tous les champs doivent être remplis en français.`,
});

const petCareInsightAndSuggestionsFlow = ai.defineFlow(
  {
    name: 'petCareInsightAndSuggestionsFlow',
    inputSchema: PetCareInsightAndSuggestionsInputSchema,
    outputSchema: PetCareInsightAndSuggestionsOutputSchema,
  },
  async (input) => {
    const {output} = await prompt(input);
    return output!;
  }
);
