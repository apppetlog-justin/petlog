'use server';
/**
 * @fileOverview Un flux Genkit pour générer des rapports de santé et d'activité personnalisés selon le destinataire.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ReportTargetSchema = z.enum(['veterinaire', 'petsitter', 'famille', 'archive']);

const PetReportInputSchema = z.object({
  petProfile: z.object({
    name: z.string(),
    animalType: z.string(),
    breed: z.string().optional(),
    birthdate: z.string().optional(),
    gender: z.string().optional(),
  }),
  target: ReportTargetSchema,
  startDate: z.string(),
  endDate: z.string(),
  data: z.object({
    meals: z.array(z.string()).describe("Liste des descriptions textuelles des repas."),
    walks: z.array(z.string()).describe("Liste des descriptions textuelles des balades."),
    health: z.array(z.string()).describe("Liste des descriptions textuelles des suivis santé."),
    excretions: z.array(z.string()).describe("Liste des descriptions textuelles des excrétions."),
    vomits: z.array(z.string()).describe("Liste des descriptions textuelles des vomissements."),
    sleep: z.array(z.string()).describe("Liste des descriptions textuelles du sommeil."),
    training: z.array(z.string()).describe("Liste des descriptions textuelles du dressage."),
    notes: z.array(z.string()).describe("Liste des descriptions textuelles des notes quotidiennes."),
  }),
});

export type PetReportInput = z.infer<typeof PetReportInputSchema>;

const PetReportOutputSchema = z.object({
  title: z.string(),
  sections: z.array(z.object({
    title: z.string(),
    content: z.string(),
    type: z.enum(['text', 'list', 'table']),
    items: z.array(z.string()).optional(),
  })),
  summary: z.string(),
});

export type PetReportOutput = z.infer<typeof PetReportOutputSchema>;

export async function generatePetReport(input: PetReportInput): Promise<PetReportOutput> {
  return generatePetReportFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generatePetReportPrompt',
  input: {schema: PetReportInputSchema},
  output: {schema: PetReportOutputSchema},
  prompt: `Vous êtes un assistant expert en soins animaliers pour l'application PetLog.
Votre tâche est de générer un document structuré pour {{{petProfile.name}}} sur la période du {{{startDate}}} au {{{endDate}}}.

INSTRUCTIONS CRITIQUES POUR LE MODE "archive" :
- C'est un REGISTRE TECHNIQUE VERBATIM.
- VOUS NE DEVEZ RIEN INVENTER, RIEN CALCULER, ET RIEN RÉSUMER.
- VOUS DEVEZ COPIER LES TEXTES FOURNIS DANS LES TABLEAUX EXACTEMENT COMME ILS SONT ÉCRITS DANS L'INPUT.
- SI VOUS MODIFIEZ UN SEUL CHIFFRE OU UNE SEULE UNITÉ, LE RAPPORT SERA FAUX.
- TOUTES les sections doivent être de type "table".
- Chaque élément de l'array "items" DOIT suivre strictement ce format : "Date et Heure | Type d'événement | Détails techniques".
- Le "summary" doit être : "Export technique verbatim de toutes les entrées du journal."

INSTRUCTIONS POUR LES AUTRES MODES ("veterinaire", "petsitter", "famille") :
- RAPPORT RÉDIGÉ. Analysez les données pour faire des phrases complètes.
- veterinaire : Ton médical, focus sur les constantes et la santé.
- petsitter : Instructions pratiques pour la garde.
- famille : Résumé chaleureux du bien-être général.

DONNÉES DISPONIBLES (DÉJÀ FORMATÉES) :
Repas : {{{data.meals}}}
Balades : {{{data.walks}}}
Santé/Physique : {{{data.health}}}
Excrétions : {{{data.excretions}}}
Vomis : {{{data.vomits}}}
Sommeil : {{{data.sleep}}}
Dressage : {{{data.training}}}
Notes : {{{data.notes}}}

Répondez exclusivement en français au format JSON conforme au schéma.`,
});

const generatePetReportFlow = ai.defineFlow(
  {
    name: 'generatePetReportFlow',
    inputSchema: PetReportInputSchema,
    outputSchema: PetReportOutputSchema,
  },
  async (input) => {
    const {output} = await prompt(input);
    return output!;
  }
);
