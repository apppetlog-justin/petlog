import { config } from 'dotenv';
config();

import '@/ai/flows/pet-activity-summary-report.ts';
import '@/ai/flows/pet-care-insight-and-suggestions.ts';
import '@/ai/flows/pet-report-generator.ts';
