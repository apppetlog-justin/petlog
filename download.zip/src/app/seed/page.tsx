
"use client"

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'

/**
 * @fileOverview Page de test désactivée pour la production.
 * Redirige automatiquement vers le tableau de bord.
 */
export default function SeedPage() {
  const router = useRouter()
  
  useEffect(() => {
    router.replace('/')
  }, [router])

  return null
}
