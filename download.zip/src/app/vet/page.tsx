
"use client"

import React, { useState, useEffect, useRef, Suspense } from 'react'
import { Header } from '@/components/layout/Header'
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { 
  Hospital, 
  Stethoscope, 
  Calendar, 
  Plus, 
  Save, 
  Loader2, 
  Camera, 
  Image as ImageIcon, 
  X, 
  Check, 
  ArrowLeft, 
  Bell, 
  Search,
  Trash2,
  AlertCircle,
  FileText,
  Clock,
  ChevronRight,
  Maximize2
} from 'lucide-react'
import { useUser, useFirestore, useCollection, useMemoFirebase, errorEmitter, FirestorePermissionError } from '@/firebase'
import { collection, addDoc, query, orderBy, limit, deleteDoc, doc } from 'firebase/firestore'
import { useToast } from '@/hooks/use-toast'
import { useRouter } from 'next/navigation'
import Image from 'next/image'
import { resizeImage } from '@/lib/image-utils'
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog'

const VISIT_TYPES = [
  "Consultation Générale",
  "Vaccination",
  "Urgence",
  "Chirurgie / Opération",
  "Suivi Maladie",
  "Analyse / Prise de sang",
  "Imagerie (Radio/Echo)",
  "Autre"
]

function VetContent() {
  const { user } = useUser()
  const db = useFirestore()
  const { toast } = useToast()
  const router = useRouter()

  const [selectedPetId, setSelectedPetId] = useState<string>('')
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showCamera, setShowCamera] = useState(false)
  const [capturedPhotos, setCapturedPhotos] = useState<string[]>([])
  const [fullScreenImage, setFullScreenImage] = useState<string | null>(null)
  
  const videoRef = useRef<HTMLVideoElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [formData, setFormData] = useState({
    date: new Date().toISOString().split('T')[0],
    visitType: 'Consultation Générale',
    customVisitType: '',
    description: '',
    hasFollowUp: false,
    nextAppointmentDate: '',
    nextAppointmentLabel: 'Rappel de vaccin'
  })

  // Load selection from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('globalSelectedPetId')
    if (saved) setSelectedPetId(saved)
  }, [])

  const petsRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return collection(db, 'users', user.uid, 'pets')
  }, [db, user])
  const { data: pets, isLoading: isPetsLoading } = useCollection(petsRef)

  useEffect(() => {
    if (pets && pets.length > 0 && !selectedPetId) {
      setSelectedPetId(pets[0].id)
    }
  }, [pets, selectedPetId])

  const visitsRef = useMemoFirebase(() => {
    if (!db || !user || !selectedPetId) return null
    return query(collection(db, 'users', user.uid, 'pets', selectedPetId, 'vetVisits'), orderBy('visitDate', 'desc'), limit(10))
  }, [db, user, selectedPetId])
  const { data: visits, isLoading: isVisitsLoading } = useCollection(visitsRef)

  const selectedPet = pets?.find(p => p.id === selectedPetId)

  const handleSave = async () => {
    if (!user || !selectedPetId) return
    setIsSubmitting(true)

    const finalVisitType = formData.visitType === 'Autre' ? (formData.customVisitType || 'Autre') : formData.visitType
    
    const visitData = {
      petId: selectedPetId,
      ownerUserId: user.uid,
      visitDate: new Date(formData.date).toISOString(),
      visitType: finalVisitType,
      description: formData.description,
      hasFollowUp: formData.hasFollowUp,
      nextAppointmentDate: formData.hasFollowUp ? new Date(formData.nextAppointmentDate).toISOString() : null,
      nextAppointmentLabel: formData.nextAppointmentLabel,
      mediaUrls: capturedPhotos,
      createdAt: new Date().toISOString()
    }

    const colRef = collection(db, 'users', user.uid, 'pets', selectedPetId, 'vetVisits')
    
    addDoc(colRef, visitData)
      .then(() => {
        toast({ title: "Visite enregistrée" })
        setFormData({
          date: new Date().toISOString().split('T')[0],
          visitType: 'Consultation Générale',
          customVisitType: '',
          description: '',
          hasFollowUp: false,
          nextAppointmentDate: '',
          nextAppointmentLabel: 'Rappel de vaccin'
        })
        setCapturedPhotos([])
        setIsSubmitting(false)
      })
      .catch(async (error) => {
        setIsSubmitting(false)
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: colRef.path,
          operation: 'create',
          requestResourceData: visitData
        }))
      })
  }

  const handleDeleteVisit = async (id: string) => {
    if (!confirm("Supprimer cette visite de l'historique ?")) return
    const docRef = doc(db, 'users', user!.uid, 'pets', selectedPetId, 'vetVisits', id)
    deleteDoc(docRef).catch(async (error) => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: docRef.path,
        operation: 'delete'
      }))
    })
  }

  useEffect(() => {
    if (showCamera) {
      const startCam = async () => {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } })
          if (videoRef.current) videoRef.current.srcObject = stream
        } catch (e) {
          setShowCamera(false)
          toast({ variant: 'destructive', title: "Caméra indisponible" })
        }
      }
      startCam()
    } else {
      if (videoRef.current?.srcObject) {
        (videoRef.current.srcObject as MediaStream).getTracks().forEach(t => t.stop())
      }
    }
  }, [showCamera])

  const capturePhoto = async () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas')
      canvas.width = videoRef.current.videoWidth
      canvas.height = videoRef.current.videoHeight
      canvas.getContext('2d')?.drawImage(videoRef.current, 0, 0)
      const dataUrl = canvas.toDataURL('image/jpeg', 0.8)
      const resized = await resizeImage(dataUrl)
      setCapturedPhotos([...capturedPhotos, resized])
      setShowCamera(false)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onloadend = async () => {
        const resized = await resizeImage(reader.result as string)
        setCapturedPhotos([...capturedPhotos, resized])
      }
      reader.readAsDataURL(file)
    }
  }

  return (
    <div className="min-h-screen flex flex-col pt-16 pb-24">
      <Header />
      <main className="flex-1 container mx-auto py-8 px-4">
        <div className="max-w-4xl mx-auto space-y-8">
          
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-red-500/20 rounded-2xl border border-red-500/20">
                <Hospital className="h-8 w-8 text-red-500" />
              </div>
              <h1 className="text-3xl font-black uppercase tracking-tighter">Espace Vétérinaire</h1>
            </div>
            <Select value={selectedPetId} onValueChange={setSelectedPetId}>
              <SelectTrigger className="w-full sm:w-64 bg-secondary/50 border-none h-12 rounded-xl">
                <SelectValue placeholder="Choisir un animal" />
              </SelectTrigger>
              <SelectContent>
                {pets?.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
            {/* Formulaire de saisie */}
            <div className="lg:col-span-3 space-y-6">
              <Card className="glass-card border-none shadow-xl overflow-hidden rounded-[2rem]">
                <CardHeader className="bg-red-500/5 pb-8 border-b border-white/5">
                  <CardTitle className="flex items-center gap-2 text-red-500">
                    <Plus className="h-5 w-5" /> Nouveau compte-rendu
                  </CardTitle>
                  <CardDescription>Enregistrez une visite, un vaccin ou un acte médical.</CardDescription>
                </CardHeader>
                <CardContent className="p-8 space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label>Date de la visite</Label>
                      <Input type="date" value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} className="bg-background h-12" />
                    </div>
                    <div className="space-y-2">
                      <Label>Type d'acte</Label>
                      <Select value={formData.visitType} onValueChange={val => setFormData({...formData, visitType: val})}>
                        <SelectTrigger className="bg-background h-12"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {VISIT_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>

                    {formData.visitType === 'Autre' && (
                      <div className="space-y-2 col-span-full animate-in slide-in-from-top-2">
                        <Label>Précisez le type de visite</Label>
                        <Input placeholder="Ex: Ostéopathie, Physiothérapie..." value={formData.customVisitType} onChange={e => setFormData({...formData, customVisitType: e.target.value})} className="bg-background h-12" />
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label>Détails / Diagnostic / Traitement</Label>
                    <Textarea 
                      placeholder="Décrivez la visite, les conseils du vétérinaire, les médicaments prescrits..." 
                      className="bg-background min-h-[120px] p-4"
                      value={formData.description}
                      onChange={e => setFormData({...formData, description: e.target.value})}
                    />
                  </div>

                  <div className="p-6 rounded-3xl bg-secondary/20 border border-white/5 space-y-6">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-base font-bold flex items-center gap-2">
                          <Bell className="h-4 w-4 text-accent" /> Prochain RDV ou Vaccin ?
                        </Label>
                        <p className="text-[10px] text-muted-foreground uppercase font-black">Planifier un rappel automatique</p>
                      </div>
                      <Switch 
                        checked={formData.hasFollowUp} 
                        onCheckedChange={val => setFormData({...formData, hasFollowUp: val})} 
                      />
                    </div>

                    {formData.hasFollowUp && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-in fade-in zoom-in-95">
                        <div className="space-y-2">
                          <Label className="text-xs">Libellé du rappel</Label>
                          <Select value={formData.nextAppointmentLabel} onValueChange={val => setFormData({...formData, nextAppointmentLabel: val})}>
                            <SelectTrigger className="bg-background h-10"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Rappel de vaccin">Rappel de vaccin</SelectItem>
                              <SelectItem value="Contrôle annuel">Contrôle annuel</SelectItem>
                              <SelectItem value="Visite de suivi">Visite de suivi</SelectItem>
                              <SelectItem value="Retrait des points">Retrait des points</SelectItem>
                              <SelectItem value="Autre rendez-vous">Autre rendez-vous</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div className="space-y-2">
                          <Label className="text-xs">Date prévue</Label>
                          <Input type="date" value={formData.nextAppointmentDate} onChange={e => setFormData({...formData, nextAppointmentDate: e.target.value})} className="bg-background h-10" />
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="space-y-4">
                    <Label className="flex items-center gap-2"><ImageIcon className="h-4 w-4 text-muted-foreground" /> Photos, Ordonnances ou Factures</Label>
                    <div className="flex flex-wrap gap-3">
                      {capturedPhotos.map((p, i) => (
                        <div key={i} className="relative h-20 w-20 rounded-xl overflow-hidden border border-white/10 group cursor-pointer" onClick={() => setFullScreenImage(p)}>
                          <Image src={p} alt="Doc" fill className="object-cover" />
                          <button onClick={(e) => { e.stopPropagation(); setCapturedPhotos(capturedPhotos.filter((_, idx) => idx !== i)) }} className="absolute top-1 right-1 bg-black/50 p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
                            <X className="h-3 w-3 text-white" />
                          </button>
                        </div>
                      ))}
                      <div className="flex gap-2">
                        <Button variant="outline" size="icon" className="h-20 w-20 border-dashed rounded-xl" onClick={() => setShowCamera(true)}>
                          <Camera className="h-6 w-6 text-muted-foreground" />
                        </Button>
                        <Button variant="outline" size="icon" className="h-20 w-20 border-dashed rounded-xl" onClick={() => fileInputRef.current?.click()}>
                          <ImageIcon className="h-6 w-6 text-muted-foreground" />
                        </Button>
                      </div>
                      <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
                    </div>
                  </div>

                  <Button className="w-full bg-red-500 hover:bg-red-600 h-14 text-white font-black uppercase tracking-widest shadow-lg shadow-red-500/20 rounded-2xl" onClick={handleSave} disabled={isSubmitting || !selectedPetId}>
                    {isSubmitting ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <Save className="mr-2 h-5 w-5" />}
                    Enregistrer la visite
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Historique latéral */}
            <div className="lg:col-span-2 space-y-6">
              <h2 className="text-xs font-black uppercase text-muted-foreground tracking-widest ml-2 flex items-center gap-2">
                <Clock className="h-4 w-4" /> Historique Récent
              </h2>
              
              {isVisitsLoading ? (
                <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-red-500" /></div>
              ) : visits && visits.length > 0 ? (
                <div className="space-y-4">
                  {visits.map(visit => (
                    <Card key={visit.id} className="glass-card border-none overflow-hidden group">
                      <CardContent className="p-5 space-y-3">
                        <div className="flex justify-between items-start">
                          <div className="space-y-1">
                            <Badge className="bg-red-500/10 text-red-500 text-[8px] font-black uppercase border-red-500/20">{visit.visitType}</Badge>
                            <p className="text-[10px] font-bold text-muted-foreground uppercase">{new Date(visit.visitDate).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                          </div>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive opacity-0 group-hover:opacity-100" onClick={() => handleDeleteVisit(visit.id)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                        <p className="text-xs font-medium leading-relaxed line-clamp-3 italic">"{visit.description}"</p>
                        
                        {visit.hasFollowUp && visit.nextAppointmentDate && (
                          <div className="p-3 rounded-xl bg-accent/10 border border-accent/20 flex items-center gap-3">
                            <Bell className="h-4 w-4 text-accent" />
                            <div className="flex flex-col">
                              <span className="text-[8px] font-black uppercase text-accent">{visit.nextAppointmentLabel}</span>
                              <span className="text-[10px] font-bold">{new Date(visit.nextAppointmentDate).toLocaleDateString('fr-FR')}</span>
                            </div>
                          </div>
                        )}

                        {visit.mediaUrls?.length > 0 && (
                          <div className="flex gap-2 pt-2 overflow-x-auto no-scrollbar">
                            {visit.mediaUrls.map((url: string, i: number) => (
                              <div key={i} className="relative h-12 w-12 shrink-0 rounded-lg overflow-hidden border border-white/5 cursor-pointer" onClick={() => setFullScreenImage(url)}>
                                <Image src={url} alt="Visit doc" fill className="object-cover" />
                              </div>
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-20 glass-card rounded-[2rem] border-dashed border-2 border-white/5 opacity-40">
                  <Hospital className="h-12 w-12 mx-auto mb-2" />
                  <p className="text-[10px] font-black uppercase">Aucune visite enregistrée</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      {/* Camera Overlay */}
      {showCamera && (
        <div className="fixed inset-0 z-[200] bg-black flex flex-col items-center justify-center p-4">
          <video ref={videoRef} className="w-full max-w-md aspect-square rounded-[2rem] object-cover bg-neutral-900 shadow-2xl" autoPlay muted playsInline />
          <div className="flex gap-6 mt-12">
            <Button variant="outline" size="lg" className="rounded-full h-16 w-16 bg-white/10 border-white/20" onClick={() => setShowCamera(false)}>
              <X className="h-8 w-8 text-white" />
            </Button>
            <Button className="bg-red-500 rounded-full h-20 w-20 shadow-xl shadow-red-500/40" onClick={capturePhoto}>
              <Check className="h-10 w-10 text-white" />
            </Button>
          </div>
        </div>
      )}

      {/* Image Viewer */}
      <Dialog open={!!fullScreenImage} onOpenChange={(open) => !open && setFullScreenImage(null)}>
        <DialogContent className="max-w-[100vw] h-full p-0 bg-black/95 border-none flex items-center justify-center z-[300]">
          <div className="relative w-full h-full flex items-center justify-center">
             {fullScreenImage && <Image src={fullScreenImage} alt="Plein écran" fill className="object-contain" priority sizes="100vw" />}
             <Button variant="ghost" size="icon" className="absolute top-6 right-6 h-12 w-12 rounded-full bg-black/50 text-white hover:bg-black/70 z-[310]" onClick={() => setFullScreenImage(null)}>
               <X className="h-8 w-8" />
             </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default function VetPage() {
  return <Suspense fallback={<div className="min-h-screen flex items-center justify-center pt-16"><Loader2 className="animate-spin" /></div>}><VetContent /></Suspense>
}
