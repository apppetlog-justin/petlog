
"use client"

import React, { useState, useRef, useEffect, Suspense } from 'react'
import { Header } from '@/components/layout/Header'
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Save, Search, X, Loader2, BicepsFlexed, Gamepad2, Sparkles } from 'lucide-react'
import { useUser, useFirestore, useCollection, useMemoFirebase, errorEmitter, FirestorePermissionError, useDoc } from '@/firebase'
import { collection, addDoc, doc, updateDoc } from 'firebase/firestore'
import { useToast } from '@/hooks/use-toast'
import { useSearchParams, useRouter } from 'next/navigation'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { cn } from '@/lib/utils'

function TrainingContent() {
  const { user } = useUser();
  const db = useFirestore()
  const { toast } = useToast()
  const searchParams = useSearchParams()
  const router = useRouter()
  const initialPetId = searchParams.get('petId') || ''
  const logIdToEdit = searchParams.get('logId') || ''

  const [selectedPet, setSelectedPet] = useState(initialPetId)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isEditing, setIsEditing] = useState(false)
  const [editingLog, setEditingLog] = useState<any>(null)

  const [formData, setFormData] = useState<any>({
    date: new Date().toLocaleDateString('en-CA'),
    type: 'training', // 'training' or 'play'
    trickName: '',
    duration: '15',
    status: 'In Progress',
    notes: ''
  })

  const petsRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return collection(db, 'users', user.uid, 'pets')
  }, [db, user])
  const { data: pets } = useCollection(petsRef)

  const editLogRef = useMemoFirebase(() => {
    if (!db || !user || !selectedPet || !logIdToEdit) return null;
    return doc(db, 'users', user.uid, 'pets', selectedPet, 'trainingSessions', logIdToEdit);
  }, [db, user, selectedPet, logIdToEdit]);
  const { data: logToEdit } = useDoc(editLogRef);

  useEffect(() => {
    if (logToEdit) {
      setEditingLog({
        ...logToEdit,
        type: logToEdit.type || 'training',
        date: logToEdit.sessionDate ? new Date(logToEdit.sessionDate).toLocaleDateString('en-CA') : new Date().toLocaleDateString('en-CA')
      });
      setIsEditing(true);
    }
  }, [logToEdit]);

  const handleSave = () => {
    if (!selectedPet || !user) return
    if (!formData.trickName?.trim()) {
      toast({ variant: 'destructive', title: 'Erreur', description: 'Veuillez saisir le nom de l\'activité.' })
      return
    }

    setIsSubmitting(true)
    const sessionData = {
      ...formData,
      petId: selectedPet,
      ownerUserId: user.uid,
      sessionDate: new Date(formData.date).toISOString(),
      createdAt: new Date().toISOString()
    }

    const colRef = collection(db, 'users', user.uid, 'pets', selectedPet, 'trainingSessions');
    addDoc(colRef, sessionData)
      .then(() => {
        toast({ title: 'Enregistré' })
        setFormData({ ...formData, date: new Date().toLocaleDateString('en-CA'), trickName: '', notes: '' })
        setIsSubmitting(false)
      })
      .catch(async (error) => {
        setIsSubmitting(false)
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: colRef.path,
          operation: 'create',
          requestResourceData: sessionData
        }));
      });
  }

  const handleUpdate = () => {
    if (!user || !selectedPet || !editingLog) return
    setIsSubmitting(true)
    
    const docRef = doc(db, 'users', user.uid, 'pets', selectedPet, 'trainingSessions', editingLog.id);
    const updateData = { 
      type: editingLog.type || 'training',
      trickName: editingLog.trickName || '',
      duration: editingLog.duration || '15',
      status: editingLog.status || 'In Progress',
      notes: editingLog.notes || '',
      sessionDate: new Date(editingLog.date).toISOString(),
      updatedAt: new Date().toISOString() 
    };

    updateDoc(docRef, updateData)
      .then(() => {
        setIsEditing(false)
        setIsSubmitting(false)
        setEditingLog(null)
        const returnTo = searchParams.get('returnTo');
        if (returnTo) router.push(returnTo);
      })
      .catch(async (error) => {
        setIsSubmitting(false)
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: docRef.path,
          operation: 'update',
          requestResourceData: updateData
        }));
      });
  }

  const handleOpenJournal = () => {
    window.dispatchEvent(new CustomEvent('open-journal'));
  }

  return (
    <div className="min-h-screen flex flex-col pt-16 pb-24">
      <Header />
      <main className="flex-1 container mx-auto py-8 px-4">
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <h1 className="text-3xl font-bold">Dressage & Jeux</h1>
            <div className="flex gap-2 w-full sm:w-auto">
              <Button variant="outline" className="flex-1 sm:flex-none gap-2" onClick={handleOpenJournal}>
                <Search className="h-4 w-4" /> Journal
              </Button>
              <Select value={selectedPet} onValueChange={setSelectedPet}>
                <SelectTrigger className="flex-1 sm:w-64 bg-secondary/50 border-none">
                  <SelectValue placeholder="Animal" />
                </SelectTrigger>
                <SelectContent>
                  {pets?.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          <Card className="glass-card border-none shadow-xl">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5 text-primary" />
                Nouvelle Session
              </CardTitle>
              <CardDescription>Enregistrez les progrès d'apprentissage ou les moments de jeux.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2 col-span-full">
                  <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Type d'activité</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <button 
                      onClick={() => setFormData({...formData, type: 'training'})}
                      className={cn(
                        "flex items-center justify-center gap-2 h-14 rounded-2xl border-2 transition-all font-bold uppercase text-[10px] tracking-widest",
                        formData.type === 'training' ? "bg-primary/20 border-primary text-primary" : "bg-secondary/20 border-white/5 opacity-60"
                      )}
                    >
                      <BicepsFlexed className="h-4 w-4" /> Dressage
                    </button>
                    <button 
                      onClick={() => setFormData({...formData, type: 'play'})}
                      className={cn(
                        "flex items-center justify-center gap-2 h-14 rounded-2xl border-2 transition-all font-bold uppercase text-[10px] tracking-widest",
                        formData.type === 'play' ? "bg-orange-500/20 border-orange-500 text-orange-500" : "bg-secondary/20 border-white/5 opacity-60"
                      )}
                    >
                      <Gamepad2 className="h-4 w-4" /> Jeu / Détente
                    </button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Date de la session</Label>
                  <Input type="date" value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} className="h-12 bg-background/50 border-white/5" />
                </div>
                <div className="space-y-2">
                  <Label>{formData.type === 'training' ? "Nom de l'exercice (Trick)" : "Nom du jeu / Activité"}</Label>
                  <Input 
                    value={formData.trickName} 
                    onChange={e => setFormData({...formData, trickName: e.target.value})} 
                    placeholder={formData.type === 'training' ? "ex: Assis, Rappel..." : "ex: Cache-cache, Balle..."} 
                    className="h-12 bg-background/50 border-white/5"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Durée (minutes)</Label>
                  <Input type="number" value={formData.duration} onChange={e => setFormData({...formData, duration: e.target.value})} className="h-12 bg-background/50 border-white/5" />
                </div>
                <div className="space-y-2">
                  <Label>{formData.type === 'training' ? "Progression" : "Statut / Intérêt"}</Label>
                  <Select value={formData.status} onValueChange={val => setFormData({...formData, status: val})}>
                    <SelectTrigger className="h-12 bg-background/50 border-white/5">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {formData.type === 'training' ? (
                        <>
                          <SelectItem value="New">Nouveau</SelectItem>
                          <SelectItem value="In Progress">En apprentissage</SelectItem>
                          <SelectItem value="Mastered">Maîtrisé</SelectItem>
                          <SelectItem value="Abandoned">Abandonné</SelectItem>
                        </>
                      ) : (
                        <>
                          <SelectItem value="Discovery">Découverte</SelectItem>
                          <SelectItem value="Favorite">Activité favorite</SelectItem>
                          <SelectItem value="Moderate">Intérêt moyen</SelectItem>
                          <SelectItem value="No Interest">Peu d'intérêt</SelectItem>
                        </>
                      )}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Notes sur la session</Label>
                <Textarea 
                  value={formData.notes} 
                  onChange={e => setFormData({...formData, notes: e.target.value})} 
                  placeholder={formData.type === 'training' ? "Points forts, difficultés..." : "Comportement pendant le jeu, niveau d'excitation..."} 
                  className="min-h-[100px] bg-background/50 border-white/5 p-4"
                />
              </div>

              <Button className="w-full bg-primary h-14 font-black uppercase tracking-widest rounded-2xl shadow-lg shadow-primary/20 gap-2" onClick={handleSave} disabled={isSubmitting || !selectedPet}>
                {isSubmitting ? <Loader2 className="h-5 w-5 animate-spin" /> : <Save className="h-5 w-5" />}
                Enregistrer la session
              </Button>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Editing Dialog */}
      <Dialog open={isEditing} onOpenChange={(open) => {
        setIsEditing(open);
        if (!open) {
          const returnTo = searchParams.get('returnTo');
          if (returnTo) router.push(returnTo);
        }
      }}>
        <DialogContent className="glass-card max-w-2xl overflow-hidden h-[90vh] flex flex-col p-0 border-none shadow-2xl">
          <DialogHeader className="p-6 shrink-0 bg-secondary/20">
            <DialogTitle className="text-xl font-bold">Modification de la session</DialogTitle>
          </DialogHeader>
          <div className="flex-1 overflow-y-auto p-6 space-y-8 no-scrollbar overscroll-contain">
            {editingLog && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2 col-span-full">
                  <Label className="text-[10px] font-black uppercase tracking-widest text-muted-foreground ml-1">Type d'activité</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <button 
                      onClick={() => setEditingLog({...editingLog, type: 'training'})}
                      className={cn(
                        "flex items-center justify-center gap-2 h-12 rounded-xl border-2 transition-all font-bold uppercase text-[10px]",
                        editingLog.type === 'training' ? "bg-primary/20 border-primary text-primary" : "bg-secondary/20 border-white/5 opacity-60"
                      )}
                    >
                      <BicepsFlexed className="h-4 w-4" /> Dressage
                    </button>
                    <button 
                      onClick={() => setEditingLog({...editingLog, type: 'play'})}
                      className={cn(
                        "flex items-center justify-center gap-2 h-12 rounded-xl border-2 transition-all font-bold uppercase text-[10px]",
                        editingLog.type === 'play' ? "bg-orange-500/20 border-orange-500 text-orange-500" : "bg-secondary/20 border-white/5 opacity-60"
                      )}
                    >
                      <Gamepad2 className="h-4 w-4" /> Jeu
                    </button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Date de la session</Label>
                  <Input type="date" value={editingLog.date} onChange={e => setEditingLog({...editingLog, date: e.target.value})} className="bg-background/50 border-white/5" />
                </div>
                <div className="space-y-2">
                  <Label>{editingLog.type === 'training' ? "Nom de l'exercice" : "Nom du jeu"}</Label>
                  <Input value={editingLog.trickName} onChange={e => setEditingLog({...editingLog, trickName: e.target.value})} className="bg-background/50 border-white/5" />
                </div>
                <div className="space-y-2">
                  <Label>Durée (minutes)</Label>
                  <Input type="number" value={editingLog.duration} onChange={e => setEditingLog({...editingLog, duration: e.target.value})} className="bg-background/50 border-white/5" />
                </div>
                <div className="space-y-2">
                  <Label>{editingLog.type === 'training' ? "Progression" : "Statut"}</Label>
                  <Select value={editingLog.status} onValueChange={val => setEditingLog({...editingLog, status: val})}>
                    <SelectTrigger className="bg-background/50 border-white/5">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {editingLog.type === 'training' ? (
                        <>
                          <SelectItem value="New">Nouveau</SelectItem>
                          <SelectItem value="In Progress">En apprentissage</SelectItem>
                          <SelectItem value="Mastered">Maîtrisé</SelectItem>
                          <SelectItem value="Abandoned">Abandonné</SelectItem>
                        </>
                      ) : (
                        <>
                          <SelectItem value="Discovery">Découverte</SelectItem>
                          <SelectItem value="Favorite">Activité favorite</SelectItem>
                          <SelectItem value="Moderate">Intérêt moyen</SelectItem>
                          <SelectItem value="No Interest">Peu d'intérêt</SelectItem>
                        </>
                      )}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>Notes & Observations</Label>
                  <Textarea value={editingLog.notes} onChange={e => setEditingLog({...editingLog, notes: e.target.value})} className="min-h-[120px] bg-background/50 border-white/5 p-4" />
                </div>
              </div>
            )}
          </div>
          <DialogFooter className="p-6 shrink-0 border-t bg-muted/10">
            <Button variant="outline" onClick={() => {
              setIsEditing(false);
              const returnTo = searchParams.get('returnTo');
              if (returnTo) router.push(returnTo);
            }}>Annuler</Button>
            <Button onClick={handleUpdate} className="bg-primary px-8 font-bold rounded-xl" disabled={isSubmitting}>
              {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
              Enregistrer les modifications
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default function TrainingPage() {
  return <Suspense fallback={<div className="min-h-screen flex items-center justify-center pt-16"><Loader2 className="animate-spin text-primary" /></div>}><TrainingContent /></Suspense>
}
