"use client"

import React, { useState, useEffect, useMemo } from 'react'
import { Header } from '@/components/layout/Header'
import { Sparkles, BrainCircuit, RefreshCw, AlertCircle, CheckCircle2, Wand2, Loader2, Dog } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { petCareInsightAndSuggestions } from '@/ai/flows/pet-care-insight-and-suggestions'
import type { PetCareInsightAndSuggestionsOutput, PetCareInsightAndSuggestionsInput } from '@/ai/flows/pet-care-insight-and-suggestions'
import { ScrollArea } from '@/components/ui/scroll-area'
import { useUser, useFirestore, useCollection, useMemoFirebase } from '@/firebase'
import { collection, query, orderBy, limit, getDocs } from 'firebase/firestore'
import { useToast } from '@/hooks/use-toast'

export default function AIAssistantPage() {
  const { user } = useUser()
  const db = useFirestore()
  const { toast } = useToast()
  
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [result, setResult] = useState<PetCareInsightAndSuggestionsOutput | null>(null)
  const [selectedPetId, setSelectedPetId] = useState<string>('')

  // Get user's pets
  const petsRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return collection(db, 'users', user.uid, 'pets')
  }, [db, user])
  const { data: pets, isLoading: isPetsLoading } = useCollection(petsRef)

  // Initialize selected pet
  useEffect(() => {
    if (pets && pets.length > 0 && !selectedPetId) {
      setSelectedPetId(pets[0].id)
    }
  }, [pets, selectedPetId])

  const selectedPet = useMemo(() => pets?.find(p => p.id === selectedPetId), [pets, selectedPetId])

  const handleAnalyze = async () => {
    if (!user || !db || !selectedPet) {
      toast({ variant: 'destructive', title: "Erreur", description: "Veuillez sélectionner un animal." })
      return
    }

    setIsAnalyzing(true)
    setResult(null)

    try {
      // Gather real data from Firestore subcollections
      const petPath = `users/${user.uid}/pets/${selectedPet.id}`
      
      const fetchRecent = async (sub: string, dateField: string, count: number) => {
        const q = query(collection(db, `${petPath}/${sub}`), orderBy(dateField, 'desc'), limit(count))
        const snap = await getDocs(q)
        return snap.docs.map(doc => ({ ...doc.data(), id: doc.id }))
      }

      const [meals, walks, training, weight, inspections] = await Promise.all([
        fetchRecent('meals', 'mealDate', 5),
        fetchRecent('walks', 'walkDate', 5),
        fetchRecent('trainingSessions', 'sessionDate', 5),
        fetchRecent('weightRecords', 'recordDate', 3),
        fetchRecent('generalInspections', 'inspectionDate', 1)
      ])

      const input: PetCareInsightAndSuggestionsInput = {
        petProfile: {
          name: selectedPet.name,
          animalType: selectedPet.animalType || 'animal',
          breed: selectedPet.breed || ''
        },
        recentMeals: meals.map((m: any) => ({
          timestamp: m.mealDate,
          type: m.mealType || 'Repas',
          brand: m.brand || 'Inconnue',
          quantity: m.quantityGiven || 'Non spécifiée'
        })),
        recentWalks: walks.map((w: any) => ({
          timestamp: w.walkDate,
          durationMinutes: w.durationMinutes || 0,
          distanceKm: w.distanceKm || 0,
          notes: w.notes || ''
        })),
        recentTrainingSessions: training.map((t: any) => ({
          timestamp: t.sessionDate,
          trickName: t.trickName || 'Exercice',
          durationMinutes: t.durationMinutes || 0,
          status: t.status === 'Mastered' ? 'Mastered' : 'In Progress',
          notes: t.notes || ''
        })),
        recentWeights: weight.map((w: any) => ({
          timestamp: w.recordDate,
          weightKg: w.weightValue || 0
        })),
        lastGeneralInspection: inspections[0] ? {
          timestamp: (inspections[0] as any).inspectionDate,
          notes: (inspections[0] as any).notes || '',
          checklist: (inspections[0] as any).checks || []
        } : undefined
      }

      const output = await petCareInsightAndSuggestions(input)
      setResult(output)
    } catch (error) {
      console.error("L'analyse IA a échoué :", error)
      toast({ 
        variant: 'destructive', 
        title: "Analyse échouée", 
        description: "L'assistant n'a pas pu traiter les données. Vérifiez votre connexion." 
      })
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col pt-16 pb-20">
      <Header />
      <main className="flex-1 container mx-auto py-8 px-4">
        <div className="max-w-4xl mx-auto space-y-8">
          
          <div className="flex flex-col md:flex-row items-center gap-6 p-8 glass-card rounded-2xl bg-gradient-to-br from-primary/10 via-background to-accent/5">
            <div className="p-4 bg-primary/20 rounded-full border border-primary/20">
              <BrainCircuit className="h-12 w-12 text-primary" />
            </div>
            <div className="flex-1 text-center md:text-left">
              <h1 className="text-4xl font-bold tracking-tight amber-glow">Assistant IA PetLog</h1>
              <p className="text-lg text-muted-foreground mt-2">
                Analyses basées sur les données réelles de vos compagnons pour des conseils sur mesure.
              </p>
            </div>
            <Button 
              size="lg" 
              onClick={handleAnalyze} 
              disabled={isAnalyzing || !selectedPetId}
              className="bg-primary hover:bg-primary/90 text-white font-bold px-8 shadow-lg shadow-primary/20"
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="mr-2 h-5 w-5 animate-spin" />
                  Analyse en cours...
                </>
              ) : (
                <>
                  <Sparkles className="mr-2 h-5 w-5" />
                  Analyser {selectedPet?.name || 'mon animal'}
                </>
              )}
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <aside className="md:col-span-1 space-y-4">
              <Card className="glass-card">
                <CardHeader className="p-4">
                  <CardTitle className="text-sm font-black uppercase tracking-widest text-muted-foreground">Animal</CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  {isPetsLoading ? (
                    <div className="flex items-center justify-center py-4"><Loader2 className="h-4 w-4 animate-spin" /></div>
                  ) : (
                    <Select value={selectedPetId} onValueChange={setSelectedPetId}>
                      <SelectTrigger className="bg-secondary/30 border-none h-11">
                        <SelectValue placeholder="Choisir un animal" />
                      </SelectTrigger>
                      <SelectContent>
                        {pets?.map(pet => (
                          <SelectItem key={pet.id} value={pet.id}>{pet.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                </CardContent>
              </Card>

              <Card className="glass-card bg-accent/5 border-accent/10">
                <CardHeader className="p-4">
                  <CardTitle className="text-[10px] font-black uppercase tracking-widest text-accent flex items-center gap-2">
                    <Sparkles className="h-3 w-3" /> Info IA
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <p className="text-[11px] leading-relaxed text-muted-foreground italic">
                    L'IA analyse les 30 derniers jours d'activité pour détecter des changements de comportement ou de santé.
                  </p>
                </CardContent>
              </Card>
            </aside>

            <section className="md:col-span-3">
              {!result && !isAnalyzing ? (
                <div className="flex flex-col items-center justify-center h-full min-h-[400px] glass-card rounded-2xl border-dashed border-2 opacity-60 bg-muted/5">
                  <div className="p-6 bg-secondary/50 rounded-full mb-6">
                    <Dog className="h-12 w-12 text-muted-foreground" />
                  </div>
                  <p className="text-lg font-bold uppercase tracking-tighter">Prêt pour l'analyse</p>
                  <p className="text-sm text-muted-foreground mt-2 max-w-xs text-center">
                    Cliquez sur le bouton ci-dessus pour que l'IA examine les journaux de {selectedPet?.name || 'votre animal'}.
                  </p>
                </div>
              ) : isAnalyzing ? (
                <div className="space-y-4">
                   <Card className="glass-card animate-pulse border-primary/20">
                     <div className="h-8 bg-muted w-1/3 m-6 rounded" />
                     <div className="h-32 bg-muted m-6 rounded" />
                   </Card>
                   <Card className="glass-card animate-pulse">
                     <div className="h-8 bg-muted w-1/4 m-6 rounded" />
                     <div className="h-24 bg-muted m-6 rounded" />
                   </Card>
                </div>
              ) : (
                <Tabs defaultValue="summary" className="w-full">
                  <TabsList className="grid w-full grid-cols-3 bg-secondary/50 h-12 p-1 rounded-xl">
                    <TabsTrigger value="summary" className="font-bold">Synthèse</TabsTrigger>
                    <TabsTrigger value="insights" className="font-bold">Analyses</TabsTrigger>
                    <TabsTrigger value="suggestions" className="font-bold">Suggestions</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="summary" className="mt-6">
                    <Card className="glass-card border-none shadow-xl">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-lg">
                          <CheckCircle2 className="h-5 w-5 text-green-500" />
                          État de santé de {selectedPet?.name}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ScrollArea className="h-[400px] pr-4">
                          <p className="text-base leading-relaxed whitespace-pre-wrap text-foreground/90 font-medium">
                            {result?.summaryReport}
                          </p>
                        </ScrollArea>
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="insights" className="mt-6">
                    <div className="space-y-4">
                      {result?.actionableInsights.length ? result.actionableInsights.map((insight, idx) => (
                        <Card key={idx} className="glass-card border-l-4 border-l-primary bg-primary/5 transition-transform hover:translate-x-1">
                          <CardContent className="p-4 flex gap-4">
                            <AlertCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                            <p className="text-sm font-bold leading-snug">{insight}</p>
                          </CardContent>
                        </Card>
                      )) : (
                        <p className="text-center py-12 text-muted-foreground italic">Aucune observation particulière.</p>
                      )}
                    </div>
                  </TabsContent>

                  <TabsContent value="suggestions" className="mt-6">
                    <div className="space-y-4">
                      {result?.suggestions.length ? result.suggestions.map((suggestion, idx) => (
                        <Card key={idx} className="glass-card border-l-4 border-l-accent bg-accent/5 transition-transform hover:translate-x-1">
                          <CardContent className="p-4 flex gap-4">
                            <Sparkles className="h-5 w-5 text-accent shrink-0 mt-0.5" />
                            <p className="text-sm font-bold leading-snug">{suggestion}</p>
                          </CardContent>
                        </Card>
                      )) : (
                        <p className="text-center py-12 text-muted-foreground italic">Aucune suggestion pour le moment.</p>
                      )}
                    </div>
                  </TabsContent>
                </Tabs>
              )}
            </section>
          </div>
        </div>
      </main>
    </div>
  )
}
