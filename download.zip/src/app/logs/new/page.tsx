
"use client"

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'

/**
 * @fileOverview Ancien prototype de log remplacé par les pages spécifiques.
 * Redirige vers l'accueil.
 */
export default function NewLogPage() {
  const router = useRouter()
  
  useEffect(() => {
    router.replace('/')
  }, [router])

  return null
}
