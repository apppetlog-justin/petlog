"use client"

import React, { useState, useEffect, useRef, Suspense } from 'react'
import { Header } from '@/components/layout/Header'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { 
  Footprints, 
  Clock, 
  Cloud, 
  Camera, 
  StopCircle, 
  PlayCircle,
  X,
  Loader2,
  Save,
  Image as ImageIcon,
  Check,
  Search,
  Zap,
  TrendingUp,
  Timer,
  ArrowUpRight,
  Maximize2
} from 'lucide-react'
import { useUser, useFirestore, useCollection, useMemoFirebase, errorEmitter, FirestorePermissionError, useDoc } from '@/firebase'
import { collection, addDoc, doc, updateDoc } from 'firebase/firestore'
import { useToast } from '@/hooks/use-toast'
import Image from 'next/image'
import { resizeImage } from '@/lib/image-utils'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { useSearchParams, useRouter } from 'next/navigation'

const getLocalDatetimeString = (date?: Date) => {
  const now = date || new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  return `${year}-${month}-${day}T${hours}:${minutes}`;
};

const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
  if (lat1 === 0 || lon1 === 0 || lat2 === 0 || lon2 === 0) return 0;
  
  const R = 6371; // Rayon de la terre en km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
    
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  const dist = R * c;
  
  if (dist > 5) return 0; 
  
  return dist;
};

const formatPace = (totalSeconds: number, km: number) => {
  if (km <= 0.01 || isNaN(km)) return "--:--";
  const totalMinutesPerKm = (totalSeconds / 60) / km;
  const minutes = Math.floor(totalMinutesPerKm);
  const seconds = Math.floor((totalMinutesPerKm - minutes) * 60);
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
}

function WalksContent() {
  const { user } = useUser();
  const db = useFirestore()
  const { toast } = useToast()
  const searchParams = useSearchParams()
  const router = useRouter()
  const initialPetId = searchParams.get('petId') || ''
  const logIdToEdit = searchParams.get('logId') || ''
  
  const [isTracking, setIsTracking] = useState(false)
  const [duration, setDuration] = useState(0)
  const [selectedPet, setSelectedPet] = useState(initialPetId)
  const [totalDistance, setTotalDistance] = useState(0)
  const [currentAltitude, setCurrentAltitude] = useState<number | null>(null)
  const [elevationGain, setElevationGain] = useState(0)
  const [weather, setWeather] = useState<{temp: number, desc: string} | null>(null)
  const [walkPhotos, setWalkPhotos] = useState<string[]>([])
  
  const [showCamera, setShowCamera] = useState(false)
  const [isEditing, setIsEditing] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [editingWalk, setEditingWalk] = useState<any>(null)
  const [fullScreenImage, setFullScreenImage] = useState<string | null>(null)
  
  const videoRef = useRef<HTMLVideoElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const watchId = useRef<number | null>(null)
  const lastCoordRef = useRef<{lat: number, lon: number} | null>(null)
  const lastAltRef = useRef<number | null>(null)

  const averageSpeed = duration > 0 ? (totalDistance / (duration / 3600)) : 0;
  const currentPace = formatPace(duration, totalDistance);

  // Fetch real weather based on coordinates
  useEffect(() => {
    const fetchWeather = async (lat: number, lon: number) => {
      try {
        const response = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true`);
        const data = await response.json();
        if (data.current_weather) {
          setWeather({
            temp: Math.round(data.current_weather.temperature),
            desc: getWeatherDesc(data.current_weather.weathercode)
          });
        }
      } catch (error) {
        console.error("Weather fetch failed:", error);
      }
    };

    const getWeatherDesc = (code: number) => {
      if (code === 0) return 'Dégagé';
      if (code <= 3) return 'Partiellement nuageux';
      if (code <= 48) return 'Brouillard';
      if (code <= 67) return 'Pluie';
      if (code <= 77) return 'Neige';
      if (code <= 82) return 'Averses';
      if (code <= 99) return 'Orage';
      return 'Variable';
    };

    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          fetchWeather(pos.coords.latitude, pos.coords.longitude);
        },
        (err) => {
          console.error("Initial Geo Error:", err);
          setWeather({ temp: 0, desc: 'Inconnu' });
        }
      );
    }
  }, []);

  useEffect(() => {
    let timerInterval: any
    if (isTracking) {
      timerInterval = setInterval(() => setDuration(d => d + 1), 1000)
      
      if (navigator.geolocation) {
        watchId.current = navigator.geolocation.watchPosition(
          (pos) => {
            const newLat = pos.coords.latitude;
            const newLon = pos.coords.longitude;
            const newAlt = pos.coords.altitude;
            
            if (newLat === 0 && newLon === 0) return;

            if (newAlt !== null) {
              const currentAlt = Math.round(newAlt);
              setCurrentAltitude(currentAlt);
              
              if (lastAltRef.current !== null) {
                const diff = newAlt - lastAltRef.current;
                if (diff > 0.5) {
                  setElevationGain(prev => Math.round(prev + diff));
                }
              }
              lastAltRef.current = newAlt;
            }

            if (lastCoordRef.current) {
              const dist = calculateDistance(lastCoordRef.current.lat, lastCoordRef.current.lon, newLat, newLon);
              if (dist > 0.002) {
                setTotalDistance(prev => prev + dist);
                lastCoordRef.current = { lat: newLat, lon: newLon };
              }
            } else {
              lastCoordRef.current = { lat: newLat, lon: newLon };
            }
          },
          (err) => console.error("GPS Error:", err),
          { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
        );
      }
    } else {
      clearInterval(timerInterval)
      if (watchId.current !== null) {
        navigator.geolocation.clearWatch(watchId.current);
        watchId.current = null;
      }
      lastCoordRef.current = null;
      lastAltRef.current = null;
    }
    return () => {
      clearInterval(timerInterval)
      if (watchId.current !== null) navigator.geolocation.clearWatch(watchId.current);
    }
  }, [isTracking])

  useEffect(() => {
    if (showCamera) {
      const getCameraPermission = async () => {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ 
            video: { facingMode: 'environment' } 
          });
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            videoRef.current.play();
          }
        } catch (error) {
          setShowCamera(false);
          toast({ variant: 'destructive', title: 'Accès Caméra Refusé' });
        }
      };
      getCameraPermission();
    } else {
      if (videoRef.current?.srcObject) {
        (videoRef.current.srcObject as MediaStream).getTracks().forEach(track => track.stop());
      }
    }
  }, [showCamera, toast]);

  const petsRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return collection(db, 'users', user.uid, 'pets')
  }, [db, user])
  const { data: pets } = useCollection(petsRef)

  const editWalkRef = useMemoFirebase(() => {
    if (!db || !user || !selectedPet || !logIdToEdit) return null;
    return doc(db, 'users', user.uid, 'pets', selectedPet, 'walks', logIdToEdit);
  }, [db, user, selectedPet, logIdToEdit]);
  const { data: walkToEdit } = useDoc(editWalkRef);

  useEffect(() => {
    if (walkToEdit) {
      setEditingWalk({
        ...walkToEdit,
        date: getLocalDatetimeString(new Date(walkToEdit.walkDate))
      });
      setIsEditing(true);
    }
  }, [walkToEdit]);

  const handleStopWalk = () => {
    setIsTracking(false)
    if (!user || !selectedPet) return
    
    const walkData = {
      petId: selectedPet,
      ownerUserId: user.uid,
      walkDate: new Date().toISOString(),
      durationMinutes: Math.floor(duration / 60),
      distanceKm: Number(totalDistance.toFixed(2)),
      averageSpeed: Number(averageSpeed.toFixed(1)),
      pace: currentPace,
      altitude: currentAltitude,
      elevationGain: elevationGain,
      mediaUrls: walkPhotos || [],
      weatherTemp: weather?.temp || 0,
      createdAt: new Date().toISOString(),
      notes: ''
    }
    
    const colRef = collection(db, 'users', user.uid, 'pets', selectedPet, 'walks');
    addDoc(colRef, walkData)
      .then(() => {
        toast({ title: 'Balade enregistrée' })
        setWalkPhotos([])
        setDuration(0)
        setTotalDistance(0)
        setCurrentAltitude(null)
        setElevationGain(0)
      })
      .catch(async (error) => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: colRef.path,
          operation: 'create',
          requestResourceData: walkData
        }));
      });
  }

  const handleUpdateWalk = () => {
    if (!editingWalk || !user || !selectedPet) return
    setIsSubmitting(true)
    
    const walkRef = doc(db, 'users', user.uid, 'pets', selectedPet, 'walks', editingWalk.id);
    const updateData = {
      notes: editingWalk.notes || '',
      durationMinutes: Number(editingWalk.durationMinutes) || 0,
      distanceKm: Number(editingWalk.distanceKm) || 0,
      walkDate: new Date(editingWalk.date).toISOString(),
      mediaUrls: editingWalk.mediaUrls || [],
      updatedAt: new Date().toISOString()
    };

    updateDoc(walkRef, updateData)
      .then(() => {
        setIsEditing(false);
        setIsSubmitting(false)
        const returnTo = searchParams.get('returnTo');
        if (returnTo) router.push(returnTo);
      })
      .catch(async (error) => {
        setIsSubmitting(false)
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: walkRef.path,
          operation: 'update',
          requestResourceData: updateData
        }));
      });
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, isEditingForm = false) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const resized = await resizeImage(reader.result as string);
        if (isEditingForm) {
          setEditingWalk({ ...editingWalk, mediaUrls: [...(editingWalk.mediaUrls || []), resized] });
        } else {
          setWalkPhotos([...walkPhotos, resized]);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const capturePhoto = async () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
        const resized = await resizeImage(dataUrl);
        setWalkPhotos([...walkPhotos, resized]);
        setShowCamera(false);
      }
    }
  };

  const handleOpenJournal = () => {
    window.dispatchEvent(new CustomEvent('open-journal'));
  }

  return (
    <div className="min-h-screen flex flex-col pt-16">
      <Header />
      <main className="flex-1 container mx-auto py-6 px-4 pb-24">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <h1 className="text-3xl font-bold">Balades</h1>
            <div className="flex gap-2 w-full sm:w-auto">
              {!isTracking && (
                <Button variant="outline" className="flex-1 sm:flex-none gap-2" onClick={handleOpenJournal}>
                  <Search className="h-4 w-4" /> Journal
                </Button>
              )}
              {!isTracking && (
                <select 
                  className="flex-1 sm:w-64 bg-secondary/50 border border-white/10 rounded-lg p-2 text-sm focus:ring-2 focus:ring-primary outline-none"
                  value={selectedPet}
                  onChange={e => setSelectedPet(e.target.value)}
                >
                  <option value="">Choisir l'animal...</option>
                  {pets?.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              )}
            </div>
          </div>

          {!isTracking && selectedPet && (
            <Button className="w-full bg-primary h-16 text-xl gap-3 rounded-2xl shadow-lg shadow-primary/20" onClick={() => { setIsTracking(true); setDuration(0); setTotalDistance(0); setElevationGain(0); }}>
              <PlayCircle className="h-8 w-8" /> Démarrer la balade
            </Button>
          )}

          {isTracking && (
            <Card className="glass-card border-primary/50 border shadow-2xl overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex justify-between items-center">
                  <Badge className="bg-primary/20 text-primary gap-1 px-3 py-1.5 border-primary/30">
                    <Zap className="h-3 w-3 animate-pulse" /> Suivi GPS Actif
                  </Badge>
                  <Badge variant="secondary" className="gap-1 px-3 py-1.5">
                    <Cloud className="h-3 w-3" /> {weather ? `${weather.temp}°C` : '--°C'}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                  <MetricCard icon={Clock} label="Temps écoulé" value={Math.floor(duration / 60).toString().padStart(2, '0') + ":" + (duration % 60).toString().padStart(2, '0')} color="text-primary" />
                  <MetricCard icon={Footprints} label="Distance" value={totalDistance.toFixed(2) + " km"} color="text-accent" />
                  <MetricCard icon={Timer} label="Allure" value={currentPace + " / km"} color="text-orange-400" />
                  <MetricCard icon={Zap} label="Vitesse Moy." value={averageSpeed.toFixed(1) + " km/h"} color="text-blue-400" />
                  <MetricCard icon={ArrowUpRight} label="Dénivelé +" value={elevationGain + " m"} color="text-green-500" />
                  <MetricCard icon={TrendingUp} label="Altitude" value={(currentAltitude !== null ? currentAltitude : "--") + " m"} color="text-green-400" />
                </div>

                <div className="flex flex-wrap gap-3 justify-center">
                  {walkPhotos.map((p, i) => (
                    <div key={i} className="relative h-20 w-20 rounded-xl overflow-hidden border-2 border-primary/20 shadow-md group cursor-pointer" onClick={() => setFullScreenImage(p)}>
                      <Image src={p} alt="Capture" fill className="object-cover" />
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          setWalkPhotos(walkPhotos.filter((_, idx) => idx !== i));
                        }} 
                        className="absolute top-1 right-1 bg-black/50 p-1 rounded-full z-10"
                      >
                        <X className="h-3 w-3 text-white" />
                      </button>
                      <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <Maximize2 className="h-4 w-4 text-white" />
                      </div>
                    </div>
                  ))}
                  <div className="flex gap-2">
                    <Button variant="outline" size="icon" className="h-20 w-20 rounded-xl border-dashed bg-white/5" onClick={() => setShowCamera(true)}>
                      <Camera className="h-8 w-8 text-muted-foreground" />
                    </Button>
                    <Button variant="outline" size="icon" className="h-20 w-20 rounded-xl border-dashed bg-white/5" onClick={() => fileInputRef.current?.click()}>
                      <ImageIcon className="h-6 w-6 text-muted-foreground" />
                    </Button>
                  </div>
                  <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={(e) => handleFileChange(e)} />
                </div>

                <Button variant="destructive" className="w-full h-16 rounded-2xl text-xl font-bold shadow-lg shadow-destructive/20" onClick={handleStopWalk}>
                  <StopCircle className="h-8 w-8 mr-2" /> Terminer la balade
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </main>

      {/* Visionneuse Plein Écran */}
      <Dialog open={!!fullScreenImage} onOpenChange={(open) => !open && setFullScreenImage(null)}>
        <DialogContent className="max-w-[100vw] h-full p-0 bg-black border-none flex items-center justify-center z-[400] hide-close">
          <DialogHeader className="sr-only">
            <DialogTitle>Visualisation d'image</DialogTitle>
          </DialogHeader>
          <div className="relative w-full h-full flex items-center justify-center">
             {fullScreenImage && <Image src={fullScreenImage} alt="Plein écran" fill className="object-contain" priority sizes="100vw" />}
             <Button 
               variant="ghost" 
               size="icon" 
               className="absolute top-6 right-6 h-12 w-12 rounded-full bg-black/50 text-white hover:bg-black/70 z-[410]"
               onClick={() => setFullScreenImage(null)}
             >
               <X className="h-8 w-8" />
             </Button>
          </div>
        </DialogContent>
      </Dialog>

      {showCamera && (
        <div className="fixed inset-0 z-[200] bg-black flex flex-col items-center justify-center p-4">
          <video ref={videoRef} className="w-full max-w-md aspect-square rounded-3xl object-cover bg-neutral-900 shadow-2xl" autoPlay muted playsInline />
          <div className="flex gap-6 mt-12">
            <Button variant="outline" size="lg" className="rounded-full h-16 w-16 bg-white/10 border-white/20" onClick={() => setShowCamera(false)}>
              <X className="h-8 w-8 text-white" />
            </Button>
            <Button className="bg-primary rounded-full h-20 w-20 shadow-xl shadow-primary/40" onClick={capturePhoto}>
              <Check className="h-10 w-10 text-white" />
            </Button>
          </div>
        </div>
      )}

      <Dialog open={isEditing} onOpenChange={(open) => {
        setIsEditing(open);
        if (!open) {
          const returnTo = searchParams.get('returnTo');
          if (returnTo) router.push(returnTo);
        }
      }}>
        <DialogContent className="glass-card max-w-2xl overflow-hidden h-[90vh] flex flex-col p-0 border-none shadow-2xl">
          <DialogHeader className="p-6 shrink-0 bg-secondary/20">
            <DialogTitle className="text-xl font-bold">Modification de la balade</DialogTitle>
          </DialogHeader>
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {editingWalk && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2 md:col-span-2">
                  <Label>Date et Heure</Label>
                  <Input type="datetime-local" value={editingWalk.date || ''} onChange={e => setEditingWalk({...editingWalk, date: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <Label>Durée (minutes)</Label>
                  <Input type="number" value={editingWalk.durationMinutes || 0} onChange={e => setEditingWalk({...editingWalk, durationMinutes: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <Label>Distance (km)</Label>
                  <Input type="number" step="0.01" value={editingWalk.distanceKm || 0} onChange={e => setEditingWalk({...editingWalk, distanceKm: e.target.value})} />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>Notes & Observations</Label>
                  <Textarea value={editingWalk.notes || ''} onChange={e => setEditingWalk({...editingWalk, notes: e.target.value})} />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>Photos</Label>
                  <div className="flex flex-wrap gap-3">
                    {editingWalk.mediaUrls?.map((p: string, i: number) => (
                      <div key={i} className="relative h-20 w-20 rounded-xl overflow-hidden border border-white/10 group cursor-pointer" onClick={() => setFullScreenImage(p)}>
                        <Image src={p} alt="Capture" fill className="object-cover" />
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            setEditingWalk({...editingWalk, mediaUrls: editingWalk.mediaUrls.filter((_: any, idx: number) => idx !== i)});
                          }} 
                          className="absolute top-1 right-1 bg-black/50 p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="h-3 w-3 text-white" />
                        </button>
                        <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <Maximize2 className="h-4 w-4 text-white" />
                        </div>
                      </div>
                    ))}
                    <div className="flex gap-2">
                      <Button variant="outline" size="icon" className="h-20 w-20 border-dashed rounded-xl bg-white/5" onClick={() => setShowCamera(true)}>
                        <Camera className="h-6 w-6 text-muted-foreground" />
                      </Button>
                      <Button variant="outline" size="icon" className="h-20 w-20 border-dashed rounded-xl bg-white/5" onClick={() => fileInputRef.current?.click()}>
                        <ImageIcon className="h-6 w-6 text-muted-foreground" />
                      </Button>
                    </div>
                    <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={e => handleFileChange(e, true)} />
                  </div>
                </div>
              </div>
            )}
          </div>
          <DialogFooter className="p-6 shrink-0 border-t bg-muted/10">
            <Button variant="outline" onClick={() => {
              setIsEditing(false);
              const returnTo = searchParams.get('returnTo');
              if (returnTo) router.push(returnTo);
            }}>Annuler</Button>
            <Button onClick={handleUpdateWalk} className="bg-primary px-8" disabled={isSubmitting}>
              {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
              Enregistrer les modifications
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

function MetricCard({ icon: Icon, label, value, color }: { icon: any, label: string, value: string, color: string }) {
  return (
    <div className="p-4 rounded-2xl bg-secondary/30 border border-white/5 text-center">
      <div className="flex justify-center mb-1">
        <Icon className={"h-4 w-4 " + color} />
      </div>
      <p className="text-[9px] font-bold text-muted-foreground uppercase tracking-widest mb-1">{label}</p>
      <p className={"text-xl font-black " + color}>{value}</p>
    </div>
  )
}

export default function WalksPage() {
  return <Suspense fallback={<div className="min-h-screen flex items-center justify-center pt-16"><Loader2 className="animate-spin" /></div>}><WalksContent /></Suspense>
}
