
"use client"

import React, { useState, useRef, useEffect, Suspense } from 'react'
import { Header } from '@/components/layout/Header'
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'
import { Textarea } from '@/components/ui/textarea'
import { Stethoscope, Camera, Save, Search, X, Check, Image as ImageIcon, Loader2, Scale, Ruler, Maximize2 } from 'lucide-react'
import { useUser, useFirestore, useCollection, useMemoFirebase, errorEmitter, FirestorePermissionError, useDoc } from '@/firebase'
import { collection, addDoc, doc, updateDoc } from 'firebase/firestore'
import { useToast } from '@/hooks/use-toast'
import { useSearchParams, useRouter } from 'next/navigation'
import Image from 'next/image'
import { resizeImage } from '@/lib/image-utils'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog"
import { cn } from '@/lib/utils'

function PhysicalContent() {
  const { user } = useUser();
  const db = useFirestore()
  const { toast } = useToast()
  const searchParams = useSearchParams()
  const router = useRouter()
  const initialPetId = searchParams.get('petId') || ''
  const logIdToEdit = searchParams.get('logId') || ''

  const [selectedPet, setSelectedPet] = useState(initialPetId)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isEditing, setIsEditing] = useState(false)
  const [editingLog, setEditingLog] = useState<any>(null)
  const [fullScreenImage, setFullScreenImage] = useState<string | null>(null)

  const [showCamera, setShowCamera] = useState(false)
  const [capturedPhotos, setCapturedPhotos] = useState<string[]>([])
  const videoRef = useRef<HTMLVideoElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [formData, setFormData] = useState<any>({
    date: new Date().toLocaleDateString('en-CA'),
    type: 'inspection',
    notes: '',
    checks: [],
    customCheck: '',
    weight: '',
    weightUnit: 'kg',
    height: '',
    heightUnit: 'cm'
  })

  useEffect(() => {
    if (showCamera) {
      const getCameraPermission = async () => {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
          }
        } catch (error) {
          setShowCamera(false);
          toast({ variant: 'destructive', title: 'Erreur Caméra' });
        }
      };
      getCameraPermission();
    } else {
      if (videoRef.current?.srcObject) {
        (videoRef.current.srcObject as MediaStream).getTracks().forEach(track => track.stop());
      }
    }
  }, [showCamera, toast]);

  const petsRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return collection(db, 'users', user.uid, 'pets')
  }, [db, user])
  const { data: pets } = useCollection(petsRef)

  const editLogRef = useMemoFirebase(() => {
    if (!db || !user || !selectedPet || !logIdToEdit) return null;
    return doc(db, 'users', user.uid, 'pets', selectedPet, 'generalInspections', logIdToEdit);
  }, [db, user, selectedPet, logIdToEdit]);
  const { data: logToEdit } = useDoc(editLogRef);

  useEffect(() => {
    if (logToEdit) {
      setEditingLog({
        ...logToEdit,
        date: logToEdit.inspectionDate ? new Date(logToEdit.inspectionDate).toLocaleDateString('en-CA') : new Date().toLocaleDateString('en-CA'),
        checks: logToEdit.checks || [],
        customCheck: logToEdit.customCheck || '',
        weight: logToEdit.weightValue || '',
        weightUnit: logToEdit.weightUnit || 'kg',
        height: logToEdit.heightValue || '',
        heightUnit: logToEdit.heightUnit || 'cm'
      });
      setIsEditing(true);
    }
  }, [logToEdit]);

  const handleSave = async () => {
    if (!selectedPet || !user) return
    
    setIsSubmitting(true)
    const inspectionData: any = {
      ...formData,
      mediaUrls: capturedPhotos || [],
      petId: selectedPet,
      ownerUserId: user.uid,
      inspectionDate: new Date(formData.date).toISOString(),
      createdAt: new Date().toISOString()
    }

    if (formData.type === 'weight') {
      inspectionData.weightValue = Number(formData.weight) || 0
      inspectionData.weightUnit = formData.weightUnit
    } else if (formData.type === 'height') {
      inspectionData.heightValue = Number(formData.height) || 0
      inspectionData.heightUnit = formData.heightUnit
    }

    const colRef = collection(db, 'users', user.uid, 'pets', selectedPet, 'generalInspections');
    
    if (formData.type === 'weight') {
      const weightRef = collection(db, 'users', user.uid, 'pets', selectedPet, 'weightRecords');
      addDoc(weightRef, {
        petId: selectedPet,
        ownerUserId: user.uid,
        recordDate: new Date(formData.date).toISOString(),
        weightValue: Number(formData.weight) || 0,
        weightUnit: formData.weightUnit,
        createdAt: new Date().toISOString()
      });
    }

    addDoc(colRef, inspectionData)
      .then(() => {
        toast({ title: 'Enregistré' })
        setFormData({ 
          ...formData, 
          date: new Date().toLocaleDateString('en-CA'), 
          notes: '', 
          checks: [], 
          customCheck: '',
          weight: '', 
          height: '' 
        })
        setCapturedPhotos([])
        setIsSubmitting(false)
      })
      .catch(async (error) => {
        setIsSubmitting(false)
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: colRef.path,
          operation: 'create',
          requestResourceData: inspectionData
        }));
      });
  }

  const handleUpdate = () => {
    if (!user || !selectedPet || !editingLog) return
    setIsSubmitting(true)
    
    const docRef = doc(db, 'users', user.uid, 'pets', selectedPet, 'generalInspections', editingLog.id);
    const updateData: any = { 
      type: editingLog.type || 'inspection',
      notes: editingLog.notes || '',
      checks: editingLog.checks || [],
      customCheck: editingLog.customCheck || '',
      mediaUrls: editingLog.mediaUrls || [],
      inspectionDate: new Date(editingLog.date).toISOString(),
      updatedAt: new Date().toISOString() 
    };

    if (editingLog.type === 'weight') {
      updateData.weightValue = Number(editingLog.weight) || 0
      updateData.weightUnit = editingLog.weightUnit
    } else if (editingLog.type === 'height') {
      updateData.heightValue = Number(editingLog.height) || 0
      updateData.heightUnit = editingLog.heightUnit
    }

    updateDoc(docRef, updateData)
      .then(() => {
        setIsEditing(false)
        setIsSubmitting(false)
        setEditingLog(null)
        const returnTo = searchParams.get('returnTo');
        if (returnTo) router.push(returnTo);
      })
      .catch(async (error) => {
        setIsSubmitting(false)
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: docRef.path,
          operation: 'update',
          requestResourceData: updateData
        }));
      });
  }

  const toggleCheck = (item: string, isEditingForm = false) => {
    if (isEditingForm) {
      const checks = editingLog.checks.includes(item)
        ? editingLog.checks.filter((i: string) => i !== item)
        : [...editingLog.checks, item]
      setEditingLog({ ...editingLog, checks })
    } else {
      const checks = formData.checks.includes(item)
        ? formData.checks.filter((i: string) => i !== item)
        : [...formData.checks, item]
      setFormData({ ...formData, checks })
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, isEditingForm = false) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const resized = await resizeImage(reader.result as string);
        if (isEditingForm) {
          setEditingLog({ ...editingLog, mediaUrls: [...(editingLog.mediaUrls || []), resized] });
        } else {
          setCapturedPhotos([...capturedPhotos, resized]);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleOpenJournal = () => {
    window.dispatchEvent(new CustomEvent('open-journal'));
  }

  return (
    <div className="min-h-screen flex flex-col pt-16 pb-24">
      <Header />
      <main className="flex-1 container mx-auto py-8 px-4">
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <Stethoscope className="h-8 w-8 text-primary" />
              Suivi Physique
            </h1>
            <div className="flex gap-2 w-full sm:w-auto">
              <Button variant="outline" className="flex-1 sm:flex-none gap-2" onClick={handleOpenJournal}>
                <Search className="h-4 w-4" /> Journal
              </Button>
              <Select value={selectedPet} onValueChange={setSelectedPet}>
                <SelectTrigger className="flex-1 sm:w-64 bg-secondary/50 border-none">
                  <SelectValue placeholder="Animal" />
                </SelectTrigger>
                <SelectContent>
                  {pets?.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          <Card className="glass-card border-none shadow-xl">
            <CardHeader>
              <CardTitle>Nouvelle Observation</CardTitle>
              <CardDescription>Enregistrez une mesure, une inspection ou une activité d'hygiène.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label>Date de l'observation</Label>
                  <Input type="date" value={formData.date ?? ''} onChange={e => setFormData({...formData, date: e.target.value})} />
                </div>
                <div className="space-y-2">
                  <Label>Type d'activité</Label>
                  <Select value={formData.type} onValueChange={val => setFormData({...formData, type: val})}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="inspection">Inspection Générale</SelectItem>
                      <SelectItem value="weight">Pesée</SelectItem>
                      <SelectItem value="height">Mesure de Taille</SelectItem>
                      <SelectItem value="grooming">Toilettage</SelectItem>
                      <SelectItem value="cleaning">Nettoyage</SelectItem>
                      <SelectItem value="soins">Soins Particuliers</SelectItem>
                      <SelectItem value="deworming">Vermifuge</SelectItem>
                      <SelectItem value="parasite">Anti-puces/tiques</SelectItem>
                      <SelectItem value="vaccine">Vaccination</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {formData.type === 'weight' && (
                  <div className="space-y-2 col-span-full md:col-span-1 animate-in slide-in-from-left-2">
                    <Label className="flex items-center gap-2"><Scale className="h-4 w-4 text-primary" /> Poids actuel</Label>
                    <div className="flex gap-2">
                      <Input type="number" step="0.1" value={formData.weight ?? ''} onChange={e => setFormData({...formData, weight: e.target.value})} placeholder="ex: 12.5" className="flex-1" />
                      <Select value={formData.weightUnit ?? 'kg'} onValueChange={v => setFormData({...formData, weightUnit: v})}>
                        <SelectTrigger className="w-24"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="kg">kg</SelectItem>
                          <SelectItem value="lb">lb</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                {formData.type === 'height' && (
                  <div className="space-y-2 col-span-full md:col-span-1 animate-in slide-in-from-left-2">
                    <Label className="flex items-center gap-2"><Ruler className="h-4 w-4 text-primary" /> Taille / Grandeur</Label>
                    <div className="flex gap-2">
                      <Input type="number" value={formData.height ?? ''} onChange={e => setFormData({...formData, height: e.target.value})} placeholder="ex: 45" className="flex-1" />
                      <Select value={formData.heightUnit ?? 'cm'} onValueChange={v => setFormData({...formData, heightUnit: v})}>
                        <SelectTrigger className="w-24"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="cm">cm</SelectItem>
                          <SelectItem value="in">in</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}
              </div>

              {(formData.type === 'inspection' || formData.type === 'grooming' || formData.type === 'soins' || formData.type === 'cleaning') && (
                <div className="space-y-3 animate-in fade-in duration-500">
                  <Label>Points vérifiés</Label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {['yeux', 'oreilles', 'dents', 'pattes', 'pelage', 'griffes', 'museau', 'autre'].map((item) => (
                      <div 
                        key={item} 
                        onClick={() => toggleCheck(item)}
                        className={cn(
                          "flex items-center gap-2 p-3 rounded-xl border cursor-pointer transition-all",
                          formData.checks.includes(item) ? "bg-primary/20 border-primary" : "bg-secondary/20 border-white/5"
                        )}
                      >
                        <Checkbox checked={formData.checks.includes(item)} onCheckedChange={() => toggleCheck(item)} />
                        <span className="text-xs font-bold uppercase tracking-tight">{item}</span>
                      </div>
                    ))}
                  </div>
                  {formData.checks.includes('autre') && (
                    <div className="mt-2 animate-in slide-in-from-top-2">
                      <Label className="text-[10px] uppercase opacity-70">Précisez le point vérifié</Label>
                      <Input 
                        placeholder="Entrez le détail..." 
                        value={formData.customCheck || ''} 
                        onChange={e => setFormData({...formData, customCheck: e.target.value})} 
                      />
                    </div>
                  )}
                </div>
              )}

              <div className="space-y-2">
                <Label>Notes & Observations</Label>
                <Textarea value={formData.notes ?? ''} onChange={e => setFormData({...formData, notes: e.target.value})} placeholder="Détails supplémentaires..." />
              </div>

              <div className="flex flex-wrap gap-3">
                {capturedPhotos.map((p, i) => (
                  <div key={i} className="relative h-20 w-20 rounded-xl overflow-hidden border border-white/10 group cursor-pointer" onClick={() => setFullScreenImage(p)}>
                    <Image src={p} alt="Capture" fill className="object-cover" />
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        setCapturedPhotos(capturedPhotos.filter((_, idx) => idx !== i));
                      }} 
                      className="absolute top-1 right-1 bg-black/50 p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="h-3 w-3 text-white" />
                    </button>
                    <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <Maximize2 className="h-4 w-4 text-white" />
                    </div>
                  </div>
                ))}
                <div className="flex gap-2">
                  <Button variant="outline" size="icon" className="h-20 w-20 border-dashed rounded-xl" onClick={() => setShowCamera(true)}>
                    <Camera className="h-6 w-6 text-muted-foreground" />
                  </Button>
                  <Button variant="outline" size="icon" className="h-20 w-20 border-dashed rounded-xl" onClick={() => fileInputRef.current?.click()}>
                    <ImageIcon className="h-6 w-6 text-muted-foreground" />
                  </Button>
                </div>
                <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={e => handleFileChange(e)} />
              </div>

              <Button className="w-full bg-primary gap-2 h-12 font-bold" onClick={handleSave} disabled={isSubmitting || !selectedPet}>
                {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                Enregistrer l'observation
              </Button>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Editing Dialog */}
      <Dialog open={isEditing} onOpenChange={(open) => {
        setIsEditing(open);
        if (!open) {
          const returnTo = searchParams.get('returnTo');
          if (returnTo) router.push(returnTo);
        }
      }}>
        <DialogContent className="glass-card max-w-2xl overflow-hidden h-[90vh] flex flex-col p-0 border-none shadow-2xl">
          <DialogHeader className="p-6 shrink-0 bg-secondary/20">
            <DialogTitle>Modification de l'observation</DialogTitle>
          </DialogHeader>
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {editingLog && (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label>Date de l'observation</Label>
                    <Input type="date" value={editingLog.date ?? ''} onChange={e => setEditingLog({...editingLog, date: e.target.value})} />
                  </div>
                  <div className="space-y-2">
                    <Label>Type d'activité</Label>
                    <Select value={editingLog.type} onValueChange={val => setEditingLog({...editingLog, type: val})}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="inspection">Inspection Générale</SelectItem>
                        <SelectItem value="weight">Pesée</SelectItem>
                        <SelectItem value="height">Mesure de Taille</SelectItem>
                        <SelectItem value="grooming">Toilettage</SelectItem>
                        <SelectItem value="cleaning">Nettoyage</SelectItem>
                        <SelectItem value="soins">Soins Particuliers</SelectItem>
                        <SelectItem value="deworming">Vermifuge</SelectItem>
                        <SelectItem value="parasite">Anti-puces/tiques</SelectItem>
                        <SelectItem value="vaccine">Vaccination</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {editingLog.type === 'weight' && (
                    <div className="space-y-2 col-span-full md:col-span-1">
                      <Label>Poids</Label>
                      <div className="flex gap-2">
                        <Input type="number" step="0.1" value={editingLog.weight ?? ''} onChange={e => setEditingLog({...editingLog, weight: e.target.value})} className="flex-1" />
                        <Select value={editingLog.weightUnit ?? 'kg'} onValueChange={v => setEditingLog({...editingLog, weightUnit: v})}>
                          <SelectTrigger className="w-24"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="kg">kg</SelectItem>
                            <SelectItem value="lb">lb</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  )}

                  {editingLog.type === 'height' && (
                    <div className="space-y-2 col-span-full md:col-span-1">
                      <Label>Taille</Label>
                      <div className="flex gap-2">
                        <Input type="number" value={editingLog.height ?? ''} onChange={e => setEditingLog({...editingLog, height: e.target.value})} className="flex-1" />
                        <Select value={editingLog.heightUnit ?? 'cm'} onValueChange={v => setEditingLog({...editingLog, heightUnit: v})}>
                          <SelectTrigger className="w-24"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="cm">cm</SelectItem>
                            <SelectItem value="in">in</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  )}
                </div>

                <div className="space-y-3">
                  <Label>Points vérifiés</Label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {['yeux', 'oreilles', 'dents', 'pattes', 'pelage', 'griffes', 'museau', 'autre'].map((item) => (
                      <div 
                        key={item} 
                        onClick={() => toggleCheck(item, true)}
                        className={cn(
                          "flex items-center gap-2 p-3 rounded-xl border cursor-pointer transition-all",
                          editingLog.checks.includes(item) ? "bg-primary/20 border-primary" : "bg-secondary/20 border-white/5"
                        )}
                      >
                        <Checkbox checked={editingLog.checks.includes(item)} onCheckedChange={() => toggleCheck(item, true)} />
                        <span className="text-xs font-bold uppercase tracking-tight">{item}</span>
                      </div>
                    ))}
                  </div>
                  {editingLog.checks.includes('autre') && (
                    <div className="mt-2 animate-in slide-in-from-top-2">
                      <Label className="text-[10px] uppercase opacity-70">Précisez le point vérifié</Label>
                      <Input 
                        placeholder="Entrez le détail..." 
                        value={editingLog.customCheck || ''} 
                        onChange={e => setEditingLog({...editingLog, customCheck: e.target.value})} 
                      />
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label>Notes & Observations</Label>
                  <Textarea value={editingLog.notes ?? ''} onChange={e => setEditingLog({...editingLog, notes: e.target.value})} />
                </div>

                <div className="space-y-2">
                  <Label>Photos</Label>
                  <div className="flex flex-wrap gap-3">
                    {editingLog.mediaUrls?.map((p: string, i: number) => (
                      <div key={i} className="relative h-20 w-20 rounded-xl overflow-hidden border border-white/10 group cursor-pointer" onClick={() => setFullScreenImage(p)}>
                        <Image src={p} alt="Capture" fill className="object-cover" />
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            setEditingLog({...editingLog, mediaUrls: editingLog.mediaUrls.filter((_: any, idx: number) => idx !== i)});
                          }} 
                          className="absolute top-1 right-1 bg-black/50 p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="h-3 w-3 text-white" />
                        </button>
                        <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <Maximize2 className="h-4 w-4 text-white" />
                        </div>
                      </div>
                    ))}
                    <div className="flex gap-2">
                      <Button variant="outline" size="icon" className="h-20 w-20 border-dashed rounded-xl" onClick={() => setShowCamera(true)}>
                        <Camera className="h-6 w-6 text-muted-foreground" />
                      </Button>
                      <Button variant="outline" size="icon" className="h-20 w-20 border-dashed rounded-xl" onClick={() => fileInputRef.current?.click()}>
                        <ImageIcon className="h-6 w-6 text-muted-foreground" />
                      </Button>
                    </div>
                    <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={e => handleFileChange(e, true)} />
                  </div>
                </div>
              </>
            )}
          </div>
          <DialogFooter className="p-6 shrink-0 border-t bg-muted/10">
            <Button variant="outline" onClick={() => {
              setIsEditing(false);
              const returnTo = searchParams.get('returnTo');
              if (returnTo) router.push(returnTo);
            }}>Annuler</Button>
            <Button onClick={handleUpdate} className="bg-primary px-8" disabled={isSubmitting}>
              {isSubmitting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
              Enregistrer les modifications
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Visionneuse Plein Écran */}
      <Dialog open={!!fullScreenImage} onOpenChange={(open) => !open && setFullScreenImage(null)}>
        <DialogContent className="max-w-[100vw] h-full p-0 bg-black border-none flex items-center justify-center z-[400] hide-close">
          <DialogHeader className="sr-only">
            <DialogTitle>Visualisation d'image</DialogTitle>
          </DialogHeader>
          <div className="relative w-full h-full flex items-center justify-center">
             {fullScreenImage && <Image src={fullScreenImage} alt="Plein écran" fill className="object-contain" priority sizes="100vw" />}
             <Button 
               variant="ghost" 
               size="icon" 
               className="absolute top-6 right-6 h-12 w-12 rounded-full bg-black/50 text-white hover:bg-black/70 z-[410]"
               onClick={() => setFullScreenImage(null)}
             >
               <X className="h-8 w-8" />
             </Button>
          </div>
        </DialogContent>
      </Dialog>

      {showCamera && (
        <div className="fixed inset-0 z-[200] bg-black flex flex-col items-center justify-center p-4">
          <video ref={videoRef} className="w-full max-w-md aspect-square rounded-3xl object-cover bg-black" autoPlay muted playsInline />
          <div className="flex gap-4 mt-8">
            <Button variant="outline" size="lg" className="rounded-full h-16 w-16" onClick={() => setShowCamera(false)}>
              <X className="h-8 w-8 text-white" />
            </Button>
            <Button className="bg-primary rounded-full h-16 w-16" onClick={async () => {
              if (videoRef.current) {
                const canvas = document.createElement('canvas');
                canvas.width = videoRef.current.videoWidth;
                canvas.height = videoRef.current.videoHeight;
                canvas.getContext('2d')?.drawImage(videoRef.current, 0, 0);
                const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
                const resized = await resizeImage(dataUrl);
                setCapturedPhotos([...capturedPhotos, resized]);
                setShowCamera(false);
              }
            }}>
              <Check className="h-8 w-8" />
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}

export default function PhysicalPage() {
  return <Suspense fallback={<div className="min-h-screen flex items-center justify-center pt-16"><Loader2 className="animate-spin" /></div>}><PhysicalContent /></Suspense>
}
