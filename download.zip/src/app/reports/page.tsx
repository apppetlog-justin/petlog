
"use client"

import React, { useState, useEffect, useMemo } from 'react'
import { Header } from '@/components/layout/Header'
import { 
  FileText, 
  Calendar, 
  Printer, 
  Loader2, 
  Sparkles,
  Stethoscope,
  Dog,
  Users,
  Archive,
  CheckCircle2,
  Info,
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useUser, useFirestore, useCollection, useMemoFirebase } from '@/firebase'
import { collection, query, where, getDocs, orderBy } from 'firebase/firestore'
import { generatePetReport, type PetReportOutput } from '@/ai/flows/pet-report-generator'
import { cn } from '@/lib/utils'
import { useToast } from '@/hooks/use-toast'

const TARGETS = [
  { id: 'veterinaire', label: 'Vétérinaire', icon: Stethoscope, color: 'text-blue-500', bg: 'bg-blue-500/10', desc: 'Analyse médicale complète' },
  { id: 'petsitter', label: 'Pet-sitter', icon: Dog, color: 'text-orange-500', bg: 'bg-orange-500/10', desc: 'Guide et instructions' },
  { id: 'famille', label: 'Famille / Ami', icon: Users, color: 'text-green-500', bg: 'bg-green-500/10', desc: 'Bilan de bien-être' },
  { id: 'archive', label: 'Archive', icon: Archive, color: 'text-primary', bg: 'bg-primary/10', desc: 'Registre cartésien (brut)' },
]

const formatDateTime = (iso: string) => {
  return new Date(iso).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

const formatDateShort = (iso: string) => {
  return new Date(iso).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

export default function ReportsPage() {
  const { user } = useUser()
  const db = useFirestore()
  const { toast } = useToast()

  const [selectedPetId, setSelectedPetId] = useState<string>('')
  const [target, setTarget] = useState<string>('veterinaire')
  const [startDate, setStartDate] = useState(new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0])
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0])
  const [isGenerating, setIsGenerating] = useState(false)
  const [report, setReport] = useState<PetReportOutput | null>(null)

  const petsRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return collection(db, 'users', user.uid, 'pets')
  }, [db, user])
  const { data: pets } = useCollection(petsRef)

  useEffect(() => {
    if (pets && pets.length > 0 && !selectedPetId) {
      setSelectedPetId(pets[0].id)
    }
  }, [pets, selectedPetId])

  const selectedPet = useMemo(() => pets?.find(p => p.id === selectedPetId), [pets, selectedPetId])

  const handleGenerate = async () => {
    if (!selectedPet || !user || !db) return
    setIsGenerating(true)
    setReport(null)

    try {
      const petPath = `users/${user.uid}/pets/${selectedPet.id}`
      const start = `${startDate}T00:00:00.000Z`
      const end = `${endDate}T23:59:59.999Z`

      const fetchRange = async (coll: string, dateField: string) => {
        const q = query(collection(db, `${petPath}/${coll}`), where(dateField, '>=', start), where(dateField, '<=', end), orderBy(dateField, 'asc'))
        const snap = await getDocs(q)
        return snap.docs.map(d => ({ ...d.data(), id: d.id } as any))
      }

      const fetchNotes = async () => {
        const q = query(collection(db, `${petPath}/dailyNotes`), where('id', '>=', startDate), where('id', '<=', endDate), orderBy('id', 'asc'))
        const snap = await getDocs(q)
        return snap.docs.map(d => ({ ...d.data(), id: d.id } as any))
      }

      const [meals, walks, health, excretions, vomits, sleep, training, notes] = await Promise.all([
        fetchRange('meals', 'mealDate'),
        fetchRange('walks', 'walkDate'),
        fetchRange('generalInspections', 'inspectionDate'),
        fetchRange('excretions', 'excretionDate'),
        fetchRange('vomitIncidents', 'incidentDate'),
        fetchRange('sleepRecords', 'sleepDate'),
        fetchRange('trainingSessions', 'sessionDate'),
        fetchNotes()
      ])

      // PRE-FORMATTING DATA
      const formattedData = {
        meals: meals.map(m => {
          const eaten = Math.max(0, (parseFloat(m.quantityGivenValue) || 0) - (parseFloat(m.quantityLeftoverValue) || 0));
          const pct = m.quantityGivenValue ? Math.round((eaten / parseFloat(m.quantityGivenValue)) * 100) : 0;
          let medicationStr = m.medication ? `, Médicaments: ${m.medication}` : '';
          let waterStr = m.waterIntake ? `, Eau: ${m.waterIntake}` : '';
          return `${formatDateTime(m.mealDate)} | Repas | Type: ${m.mealType}, Marque: ${m.brand || '--'}, Donné: ${m.quantityGivenValue}${m.quantityGivenUnit}, Reste: ${m.quantityLeftoverValue}${m.quantityGivenUnit}, Mangé: ${eaten}${m.quantityGivenUnit} (${pct}%)${medicationStr}${waterStr}. ${m.notes || ''}`;
        }),
        walks: walks.map(w => {
          return `${formatDateTime(w.walkDate)} | Balade | Durée: ${w.durationMinutes}min, Dist: ${w.distanceKm}km, Vitesse: ${w.averageSpeed}km/h, Allure: ${w.pace || '--'}, Dénivelé: ${w.elevationGain || 0}m. ${w.notes || ''}`;
        }),
        health: health.map(h => {
          let details = `Type: ${h.type}`;
          if (h.weightValue) details += `, Poids: ${h.weightValue}${h.weightUnit}`;
          if (h.heightValue) details += `, Taille: ${h.heightValue}${h.heightUnit}`;
          if (h.checks?.length) {
            const displayChecks = h.checks.map((c: string) => c === 'autre' ? `Autre (${h.customCheck || '?'})` : c);
            details += `, Vérifié: ${displayChecks.join(', ')}`;
          }
          return `${formatDateTime(h.inspectionDate)} | Santé | ${details}. ${h.notes || ''}`;
        }),
        excretions: excretions.map(e => {
          return `${formatDateTime(e.excretionDate)} | Excrétion | Type: ${e.type}, Urine: ${e.urineQty}, Selle: ${e.stoolColor} (${e.stoolTexture}). Sang: ${e.hasBloodUrine || e.hasBloodStool ? 'OUI' : 'Non'}. ${e.notes || ''}`;
        }),
        vomits: vomits.map(v => {
          return `${formatDateTime(v.incidentDate)} | Vomi | Couleur: ${v.color}, Quantité: ${v.quantity}, Sang: ${v.hasBlood ? 'OUI' : 'Non'}. ${v.notes || ''}`;
        }),
        sleep: sleep.map(s => {
          return `${formatDateTime(s.sleepDate)} | Sommeil & Comp. | Jusqu'à: ${formatDateTime(s.sleepEnd)}, Qualité/Comportement: ${s.quality}. ${s.notes || ''}`;
        }),
        training: training.map(t => {
          return `${formatDateTime(t.sessionDate)} | Dressage | Trick: ${t.trickName}, Durée: ${t.duration}min, Statut: ${t.status}. ${t.notes || ''}`;
        }),
        notes: notes.map(n => {
          return `${formatDateShort(n.id)} | Note | ${n.content}`;
        })
      }

      if (target === 'archive') {
        // DIRECT GENERATION FOR ARCHIVE (BYPASS AI)
        const archiveReport: PetReportOutput = {
          title: "Archive du Journal - " + selectedPet.name,
          summary: "Export technique verbatim de toutes les entrées du journal.",
          sections: []
        };

        if (formattedData.meals.length > 0) archiveReport.sections.push({ title: "Tableau des Repas", content: "", type: "table", items: formattedData.meals });
        if (formattedData.walks.length > 0) archiveReport.sections.push({ title: "Tableau des Balades", content: "", type: "table", items: formattedData.walks });
        if (formattedData.health.length > 0) archiveReport.sections.push({ title: "Tableau de Santé & Phys.", content: "", type: "table", items: formattedData.health });
        if (formattedData.excretions.length > 0) archiveReport.sections.push({ title: "Tableau des Excrétions", content: "", type: "table", items: formattedData.excretions });
        if (formattedData.vomits.length > 0) archiveReport.sections.push({ title: "Tableau des Vomissements", content: "", type: "table", items: formattedData.vomits });
        if (formattedData.sleep.length > 0) archiveReport.sections.push({ title: "Tableau du Sommeil & Comportement", content: "", type: "table", items: formattedData.sleep });
        if (formattedData.training.length > 0) archiveReport.sections.push({ title: "Tableau du Dressage", content: "", type: "table", items: formattedData.training });
        if (formattedData.notes.length > 0) archiveReport.sections.push({ title: "Tableau des Notes Quotidiennes", content: "", type: "table", items: formattedData.notes });

        setReport(archiveReport);
      } else {
        // NARRATIVE REPORTS (USE AI)
        const input = {
          petProfile: {
            name: selectedPet.name,
            animalType: selectedPet.animalType,
            breed: selectedPet.breed,
            birthdate: selectedPet.birthdate,
            gender: selectedPet.gender
          },
          target: target as any,
          startDate,
          endDate,
          data: formattedData
        }
        const result = await generatePetReport(input)
        setReport(result)
      }
      toast({ title: "Document généré" })
    } catch (e: any) {
      console.error(e)
      const errorMsg = e.message?.includes('429') ? "Quota IA atteint. Le mode Archive reste disponible." : "Impossible de compiler les données.";
      toast({ variant: 'destructive', title: "Erreur", description: errorMsg })
    } finally {
      setIsGenerating(false)
    }
  }

  const handleOpenPDF = () => {
    if (typeof window !== 'undefined') {
      setTimeout(() => {
        window.print();
      }, 200);
    }
  }

  return (
    <div className="min-h-screen flex flex-col pt-16 pb-24 bg-background">
      <Header />
      <main className="flex-1 container mx-auto py-8 px-4 print:p-0 print:m-0">
        <div className="max-w-4xl mx-auto space-y-8 print:max-w-none print:space-y-0">
          
          <div className="space-y-2 print:hidden">
            <h1 className="text-3xl font-black tracking-tight amber-glow uppercase">Documents IA</h1>
            <p className="text-muted-foreground text-sm">Générez un bilan rédigé ou une archive technique complète.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 print:hidden">
            <Card className="glass-card lg:col-span-1 h-fit border-white/5">
              <CardHeader className="pb-4">
                <CardTitle className="text-xs font-black uppercase tracking-widest text-primary">Configuration</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label className="text-[10px] uppercase font-black opacity-60">Animal</Label>
                  <Select value={selectedPetId} onValueChange={setSelectedPetId}>
                    <SelectTrigger className="bg-secondary/30 border-none h-12 rounded-xl">
                      <SelectValue placeholder="Choisir un animal" />
                    </SelectTrigger>
                    <SelectContent>
                      {pets?.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="text-[10px] uppercase font-black opacity-60">Période</Label>
                  <div className="grid grid-cols-1 gap-2">
                    <Input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} className="bg-secondary/30 border-none h-12 rounded-xl" />
                    <Input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} className="bg-secondary/30 border-none h-12 rounded-xl" />
                  </div>
                </div>

                <div className="space-y-3">
                  <Label className="text-[10px] uppercase font-black opacity-60">Type de document</Label>
                  <div className="grid grid-cols-1 gap-2">
                    {TARGETS.map(t => (
                      <div 
                        key={t.id}
                        onClick={() => setTarget(t.id)}
                        className={cn(
                          "p-3 rounded-xl border-2 cursor-pointer transition-all flex items-center gap-3",
                          target === t.id ? "bg-primary/10 border-primary shadow-lg shadow-primary/10" : "bg-secondary/20 border-transparent opacity-60 hover:opacity-100"
                        )}
                      >
                        <div className={cn("p-2 rounded-lg", t.bg, t.color)}>
                          <t.icon className="h-4 w-4" />
                        </div>
                        <div className="min-w-0">
                          <p className="text-[10px] font-black uppercase tracking-tight">{t.label}</p>
                          <p className="text-[8px] text-muted-foreground truncate uppercase">{t.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <Button 
                  className="w-full bg-primary h-14 font-black uppercase tracking-widest text-[10px] rounded-xl shadow-xl shadow-primary/20 hover:scale-[1.02] transition-transform px-4"
                  onClick={handleGenerate}
                  disabled={isGenerating || !selectedPetId}
                >
                  {isGenerating ? <Loader2 className="h-5 w-5 animate-spin mr-2" /> : <Sparkles className="h-5 w-5 mr-2" />}
                  <span className="truncate">{target === 'archive' ? 'Compiler l\'archive' : 'Générer le rapport'}</span>
                </Button>
              </CardContent>
            </Card>

            <div className="lg:col-span-2">
              {!report && !isGenerating ? (
                <div className="h-full min-h-[400px] flex flex-col items-center justify-center glass-card rounded-2xl border-dashed border-2 border-white/5 opacity-30">
                  <div className="p-6 bg-secondary/50 rounded-full mb-4">
                    <FileText className="h-12 w-12 text-muted-foreground" />
                  </div>
                  <p className="font-black uppercase tracking-widest text-xs">Prêt pour la génération</p>
                </div>
              ) : isGenerating ? (
                <div className="h-full min-h-[400px] flex flex-col items-center justify-center glass-card rounded-2xl border-primary/20 border shadow-2xl bg-primary/5">
                  <Loader2 className="h-16 w-16 animate-spin text-primary mb-6" />
                  <p className="text-xl font-black uppercase tracking-tighter text-primary animate-pulse text-center px-4">
                    {target === 'archive' ? 'Extraction des données...' : 'Rédaction par l\'IA...'}
                  </p>
                  <p className="text-[10px] text-muted-foreground mt-2 uppercase font-bold">Reflet exact de votre journal</p>
                </div>
              ) : (
                <div className="space-y-6 animate-in zoom-in-95 duration-500">
                  <Card className="glass-card border-primary/30 border-2 bg-gradient-to-br from-primary/10 to-transparent shadow-2xl overflow-hidden rounded-2xl">
                    <div className="p-8 flex flex-col items-center text-center gap-6">
                      <div className="p-4 bg-primary/20 rounded-full border border-primary/20">
                        <CheckCircle2 className="h-12 w-12 text-primary" />
                      </div>
                      <div className="space-y-2">
                        <h2 className="text-2xl font-black uppercase tracking-tighter text-foreground">
                          {target === 'archive' ? 'Archive Prête' : 'Rapport Prêt'}
                        </h2>
                        <div className="flex flex-col gap-1 items-center">
                          <p className="text-sm font-bold text-primary uppercase tracking-widest">
                            {TARGETS.find(t => t.id === target)?.label}
                          </p>
                          <p className="text-xs font-medium text-muted-foreground">
                            Du {new Date(startDate).toLocaleDateString('fr-FR')} au {new Date(endDate).toLocaleDateString('fr-FR')}
                          </p>
                        </div>
                      </div>
                      
                      <Button 
                        size="lg" 
                        onClick={handleOpenPDF} 
                        className="w-full h-16 bg-primary text-white font-black uppercase tracking-widest text-[10px] sm:text-xs rounded-xl shadow-2xl shadow-primary/30 gap-2 group hover:scale-[1.02] transition-transform px-4"
                      >
                        <Printer className="h-5 w-5 group-hover:scale-110 transition-transform shrink-0" />
                        <span className="truncate">OUVRIR / SAUVEGARDER (PDF)</span>
                      </Button>
                      
                      <div className="flex items-center gap-2 text-[10px] text-muted-foreground italic max-w-xs leading-relaxed">
                        <div className="p-1 bg-muted/50 rounded-full shrink-0"><Info className="h-3 w-3" /></div>
                        <p>Formaté pour impression A4 avec en-tête PetLog.</p>
                      </div>
                    </div>
                  </Card>
                </div>
              )}
            </div>
          </div>

          {/* PRINTABLE CONTENT */}
          {report && (
            <div id="printable-report" className="hidden print:block bg-white text-black p-0 m-0 w-full min-h-screen">
              <div className={cn(
                "p-8 mx-auto bg-white max-w-[21cm] min-h-screen flex flex-col",
                target === 'archive' ? "space-y-4" : "space-y-8"
              )}>
                {/* Header */}
                <div className="flex justify-between items-end border-b-2 border-black pb-2">
                  <div className="space-y-0">
                    <div className="flex items-center gap-2">
                      <Dog className="h-6 w-6 text-black" fill="currentColor" />
                      <h2 className="text-3xl font-black uppercase tracking-tighter">PetLog</h2>
                    </div>
                    <p className="text-[10px] font-bold uppercase tracking-widest opacity-60">
                      {target === 'archive' ? 'Archive Technique du Journal' : 'Rapport d\'activité & santé généré par IA'}
                    </p>
                  </div>
                  <div className="text-right space-y-0 leading-none">
                    <p className="text-[9px] font-black uppercase">Émis le : {new Date().toLocaleDateString('fr-FR')}</p>
                    <p className="text-[9px] font-black uppercase">Période : {new Date(startDate).toLocaleDateString('fr-FR')} - {new Date(endDate).toLocaleDateString('fr-FR')}</p>
                  </div>
                </div>

                {/* Subject Info */}
                <div className="grid grid-cols-2 gap-4 bg-gray-50 p-3 rounded-lg border border-gray-200">
                  <div className="space-y-0">
                    <p className="text-[8px] font-black uppercase text-gray-400">Sujet</p>
                    <p className="text-xl font-black uppercase tracking-tight leading-none">{selectedPet?.name}</p>
                    <p className="text-[9px] font-bold text-gray-600 uppercase">
                      {selectedPet?.animalType} {selectedPet?.breed && `• ${selectedPet.breed}`}
                    </p>
                  </div>
                  <div className="space-y-0 text-right self-center">
                    <p className="text-[8px] font-black uppercase text-gray-400">Type de document</p>
                    <p className="text-lg font-black uppercase tracking-tight text-primary leading-none">
                      {TARGETS.find(t => t.id === target)?.label}
                    </p>
                  </div>
                </div>

                {/* Synthesis */}
                {target !== 'archive' ? (
                  <div className="space-y-2">
                    <h3 className="text-md font-black uppercase tracking-widest border-b border-black inline-block">Synthèse globale</h3>
                    <p className="text-[11px] leading-relaxed font-medium italic text-gray-800 bg-gray-50 p-4 rounded-lg border-l-4 border-black">
                      "{report.summary}"
                    </p>
                  </div>
                ) : (
                  <div className="pt-1">
                    <p className="text-[9px] font-bold uppercase opacity-40 italic">Note technique : {report.summary}</p>
                  </div>
                )}

                {/* Report Sections */}
                <div className={cn("flex-1", target === 'archive' ? "space-y-4" : "space-y-6")}>
                  {report.sections.map((section, idx) => (
                    <div key={idx} className="space-y-2 break-inside-avoid">
                      <h3 className={cn(
                        "font-black uppercase tracking-widest border-b border-black inline-block",
                        target === 'archive' ? "text-sm" : "text-md"
                      )}>
                        {section.title}
                      </h3>
                      
                      {section.type === 'list' && (
                        <ul className="space-y-1.5 ml-2">
                          {section.items?.map((item, i) => (
                            <li key={i} className="flex gap-2 text-[11px] font-medium leading-tight">
                              <span className="h-1 w-1 rounded-full bg-black mt-1.5 shrink-0" />
                              {item}
                            </li>
                          ))}
                        </ul>
                      )}

                      {section.type === 'text' && (
                        <p className="text-[11px] leading-relaxed text-gray-700 whitespace-pre-wrap font-medium">
                          {section.content}
                        </p>
                      )}

                      {section.type === 'table' && (
                        <div className="overflow-hidden border border-black rounded-md shadow-[2px_2px_0px_rgba(0,0,0,0.05)]">
                          <table className="w-full text-left text-[10px] border-collapse">
                            <thead className="bg-gray-100 font-black uppercase text-[8px]">
                              <tr>
                                <th className="p-1.5 border-b border-black w-24">Date / Heure</th>
                                <th className="p-1.5 border-b border-black">Événement</th>
                                <th className="p-1.5 border-b border-black">Détails Techniques</th>
                              </tr>
                            </thead>
                            <tbody>
                              {section.items?.map((row, i) => {
                                const parts = row.split('|').map(p => p.trim());
                                return (
                                  <tr key={i} className="border-b border-gray-100 last:border-0 hover:bg-gray-50">
                                    <td className="p-1.5 font-bold whitespace-nowrap align-top">{parts[0] || '--'}</td>
                                    <td className="p-1.5 text-gray-900 font-bold align-top">{parts[1] || '--'}</td>
                                    <td className="p-1.5 text-gray-700 font-medium align-top leading-tight">{parts[2] || '--'}</td>
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                {/* Footer */}
                <div className="pt-4 border-t border-gray-100 text-center opacity-20 italic">
                  <p className="text-[8px] uppercase font-black tracking-widest">Document certifié conforme aux registres PetLog • Page 1</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      <style jsx global>{`
        @media print {
          html, body {
            background: white !important;
            color: black !important;
            padding: 0 !important;
            margin: 0 !important;
            width: 100%;
            height: 100%;
            overflow: visible !important;
          }
          header, nav, .print\\:hidden, button, footer {
            display: none !important;
            height: 0 !important;
            padding: 0 !important;
            margin: 0 !important;
          }
          #printable-report {
            display: block !important;
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            z-index: 99999;
            background: white !important;
          }
          @page {
            margin: 0.5cm;
            size: A4;
          }
          .break-inside-avoid {
            page-break-inside: avoid;
          }
          table {
            page-break-inside: auto;
          }
          tr {
            page-break-inside: avoid;
            page-break-after: auto;
          }
        }
      `}</style>
    </div>
  )
}
