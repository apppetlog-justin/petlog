
"use client"

import React, { useState, useEffect, useMemo } from 'react'
import { Header } from '@/components/layout/Header'
import { 
  Footprints, 
  TrendingUp,
  Dog,
  Sparkles,
  StickyNote,
  ChevronRight,
  Utensils,
  BicepsFlexed,
  Scissors,
  FileText,
  Plus,
  Search
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import Link from 'next/link'
import { useUser, useFirestore, useDoc, useCollection, useMemoFirebase } from '@/firebase'
import { doc, updateDoc, collection, query, where } from 'firebase/firestore'
import { useRouter } from 'next/navigation'
import { cn } from '@/lib/utils'
import { getLifeGuide } from '@/lib/dog-life-guide-data'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { InteractiveTutorial } from '@/components/InteractiveTutorial'

export default function Dashboard() {
  const { user } = useUser()
  const db = useFirestore()
  const router = useRouter()
  const [selectedPetId, setSelectedPetId] = useState<string>('')
  const [showTutorial, setShowTutorial] = useState(false)

  useEffect(() => {
    const saved = typeof window !== 'undefined' ? localStorage.getItem('globalSelectedPetId') : null;
    if (saved) setSelectedPetId(saved);

    const handlePetChanged = (e: any) => setSelectedPetId(e.detail.petId);
    window.addEventListener('pet-changed', handlePetChanged);
    return () => {
      window.removeEventListener('pet-changed', handlePetChanged);
    }
  }, []);

  const userDocRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return doc(db, 'users', user.uid)
  }, [db, user])
  const { data: userData } = useDoc(userDocRef)

  const petsRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return collection(db, 'users', user.uid, 'pets')
  }, [db, user])
  const { data: pets } = useCollection(petsRef)

  useEffect(() => {
    if (pets && pets.length > 0 && !selectedPetId) {
      const firstId = pets[0].id;
      setSelectedPetId(firstId);
      localStorage.setItem('globalSelectedPetId', firstId);
    }
  }, [pets, selectedPetId])

  useEffect(() => {
    if (userData?.isNewUser) {
      setShowTutorial(true)
    }
  }, [userData])

  const currentPet = pets?.find(p => p.id === selectedPetId) || (pets?.[0] || null)
  const todayStr = new Date().toISOString().split('T')[0]

  const startOfDay = `${todayStr}T00:00:00.000Z`
  const endOfDay = `${todayStr}T23:59:59.999Z`

  const mealsTodayRef = useMemoFirebase(() => {
    if (!db || !user || !currentPet?.id) return null
    return query(collection(db, 'users', user.uid, 'pets', currentPet.id, 'meals'), where('mealDate', '>=', startOfDay), where('mealDate', '<=', endOfDay))
  }, [db, user, currentPet?.id, todayStr])
  const { data: mealsToday } = useCollection(mealsTodayRef)

  const walksTodayRef = useMemoFirebase(() => {
    if (!db || !user || !currentPet?.id) return null
    return query(collection(db, 'users', user.uid, 'pets', currentPet.id, 'walks'), where('walkDate', '>=', startOfDay), where('walkDate', '<=', endOfDay))
  }, [db, user, currentPet?.id, todayStr])
  const { data: walksToday } = useCollection(walksTodayRef)

  const trainingTodayRef = useMemoFirebase(() => {
    if (!db || !user || !currentPet?.id) return null
    return query(collection(db, 'users', user.uid, 'pets', currentPet.id, 'trainingSessions'), where('sessionDate', '>=', startOfDay), where('sessionDate', '<=', endOfDay))
  }, [db, user, currentPet?.id, todayStr])
  const { data: trainingToday } = useCollection(trainingTodayRef)

  const inspectionsWeekRef = useMemoFirebase(() => {
    if (!db || !user || !currentPet?.id) return null
    const weekAgo = new Date()
    weekAgo.setDate(weekAgo.getDate() - 7)
    return query(collection(db, 'users', user.uid, 'pets', currentPet.id, 'generalInspections'), where('inspectionDate', '>=', weekAgo.toISOString()))
  }, [db, user, currentPet?.id])
  const { data: inspectionsWeek } = useCollection(inspectionsWeekRef)

  const dailyNoteRef = useMemoFirebase(() => {
    if (!db || !user || !currentPet?.id) return null
    return doc(db, 'users', user.uid, 'pets', currentPet.id, 'dailyNotes', todayStr)
  }, [db, user, currentPet?.id, todayStr])
  const { data: todayNote } = useDoc(dailyNoteRef)

  const { ageDetail, currentStage } = useMemo(() => {
    if (!currentPet) return { ageDisplay: '', ageDetail: '', currentStage: null }
    const birth = new Date(currentPet.birthdate)
    const now = new Date()
    
    let years = now.getFullYear() - birth.getFullYear();
    let months = now.getMonth() - birth.getMonth();
    let days = now.getDate() - birth.getDate();
    
    if (days < 0) {
      months--;
      const lastMonth = new Date(now.getFullYear(), now.getMonth(), 0);
      days += lastMonth.getDate();
    }
    if (months < 0) {
      years--;
      months += 12;
    }

    const ageDetail = years === 0 
      ? `${months} mois et ${days} j` 
      : `${years} an${years > 1 ? 's' : ''}, ${months} mois et ${days} j`;

    const diffTime = Math.abs(now.getTime() - birth.getTime())
    const ageInWeeks = Math.floor(diffTime / (1000 * 60 * 60 * 24 * 7))
    const ageInMonths = Math.floor(diffTime / (1000 * 60 * 60 * 24 * 30.44))
    const ageInYears = Number((diffTime / (1000 * 60 * 60 * 24 * 365.25)).toFixed(1))
    
    const guide = getLifeGuide(currentPet.breed || currentPet.animalType)
    const stage = guide.find(stage => {
      if (stage.startYear !== undefined) return ageInYears >= stage.startYear && ageInYears < (stage.endYear || 100)
      if (stage.startMonth !== undefined) return ageInMonths >= stage.startMonth && ageInMonths < (stage.endMonth || 100)
      return ageInWeeks >= (stage.startWeek || 0) && ageInWeeks < (stage.endWeek || 1000)
    }) || guide[guide.length - 1]

    return { ageDisplay: '', ageDetail, currentStage: stage }
  }, [currentPet])

  const routineItems = useMemo(() => {
    if (!currentStage) return []
    return [
      { id: 'meals', label: 'Repas', icon: Utensils, target: currentStage.mealsPerDay, current: mealsToday?.length || 0, page: '/health', tab: 'repas', color: 'text-orange-400', bg: 'bg-orange-400/10' },
      { id: 'walks', label: 'Balades', icon: Footprints, target: currentStage.walksPerDay, current: walksToday?.length || 0, page: '/walks', tab: '', color: 'text-primary', bg: 'bg-primary/10' },
      { id: 'training', label: 'Dressage / Jeux', icon: BicepsFlexed, target: currentStage.trainingSessionsPerDay, current: trainingToday?.length || 0, page: '/training', tab: '', color: 'text-blue-400', bg: 'bg-blue-400/10' },
      { id: 'grooming', label: 'Soin / Hygiène Hebdo', icon: Scissors, target: 1, current: inspectionsWeek?.filter(i => i.type === 'grooming' || i.type === 'cleaning' || i.type === 'soins').length ? 1 : 0, page: '/physical', tab: 'inspection', color: 'text-accent', bg: 'bg-accent/10' }
    ]
  }, [currentStage, mealsToday, walksToday, trainingToday, inspectionsWeek])

  const handleOpenDailyNote = () => {
    window.dispatchEvent(new CustomEvent('open-daily-note'));
  }

  const handleFinishTutorial = () => {
    if (userDocRef) {
      updateDoc(userDocRef, { isNewUser: false })
    }
    setShowTutorial(false)
    if (pets?.length === 0) {
      router.push('/pets/new')
    }
  }

  return (
    <div className="min-h-screen flex flex-col pt-16 pb-24">
      <Header />
      
      <main className="flex-1 container mx-auto py-8 px-4">
        <div className="max-w-4xl mx-auto space-y-8">
          
          <div className="bg-gradient-to-br from-primary/20 via-background to-accent/5 p-6 sm:p-8 rounded-[2rem] border border-white/5 shadow-xl relative overflow-hidden group">
            <div className="absolute -top-24 -right-24 w-64 h-64 bg-primary/10 rounded-full blur-[80px] group-hover:bg-primary/20 transition-colors duration-1000" />
            
            <div className="relative space-y-4">
              <div className="flex flex-col gap-1.5">
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="h-5 bg-primary/10 border-primary/20 text-primary font-black text-[9px] uppercase px-2.5 rounded-full">
                    Tableau de bord
                  </Badge>
                  {currentPet && (
                    <Badge variant="outline" className="h-5 bg-accent/10 border-accent/20 text-accent font-black text-[9px] uppercase px-2.5 rounded-full">
                      {currentPet.breed || currentPet.animalType}
                    </Badge>
                  )}
                </div>
                
                <div className="flex flex-col sm:flex-row sm:items-baseline gap-2 sm:gap-4">
                  <h1 className="text-4xl sm:text-5xl font-black tracking-tighter leading-none amber-glow uppercase">
                    {currentPet ? currentPet.name : 'PetLog'}
                  </h1>
                  {currentPet && (
                    <span className="text-lg sm:text-xl font-black text-muted-foreground/40 tracking-tighter uppercase">
                      • {ageDetail}
                    </span>
                  )}
                </div>
              </div>
              
              {currentPet && (
                <div className="flex items-center gap-3 bg-white/5 backdrop-blur-xl p-3 rounded-xl border border-white/10 w-fit">
                  <div className="p-2 bg-primary/20 rounded-lg">
                    <Sparkles className="h-4 w-4 text-primary" />
                  </div>
                  <div className="flex flex-col">
                    <p className="text-[9px] font-black uppercase text-muted-foreground tracking-widest leading-none">Étape actuelle</p>
                    <p className="text-sm font-black text-primary uppercase tracking-tight">{currentStage?.title}</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {!user ? (
            <Card className="glass-card bg-primary/10 border-primary/20 p-12 text-center space-y-6">
              <div className="p-4 bg-primary/20 w-fit mx-auto rounded-full">
                <Dog className="h-12 w-12 text-primary" />
              </div>
              <h2 className="text-2xl font-bold">Commencez votre carnet de santé</h2>
              <p className="text-muted-foreground max-w-md mx-auto">PetLog centralise les balades, repas et soins de vos animaux.</p>
              <div className="flex justify-center gap-4">
                <Button asChild className="bg-primary px-8"><Link href="/signup">Créer un compte</Link></Button>
              </div>
            </Card>
          ) : (
            <div className="space-y-10">
              <section className="space-y-4" data-tut="daily-note">
                <div className="px-1">
                  <h2 className="text-xs font-black flex items-center gap-2 text-muted-foreground uppercase tracking-widest">
                    <StickyNote className="h-4 w-4 text-accent" />
                    Note du jour
                  </h2>
                </div>
                <Card 
                  className="glass-card border-none shadow-lg cursor-pointer hover:bg-accent/5 transition-all group overflow-hidden bg-gradient-to-br from-accent/5 to-transparent rounded-3xl"
                  onClick={handleOpenDailyNote}
                >
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start gap-4">
                      <div className="space-y-2 flex-1">
                        <p className="text-[10px] font-black uppercase text-accent/60 tracking-tighter">{new Date().toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' })}</p>
                        <p className={cn("text-sm italic leading-relaxed line-clamp-2", todayNote ? "text-foreground font-medium" : "text-muted-foreground opacity-50")}>
                          {todayNote?.content || "Comment se sent votre animal aujourd'hui ? Humeur, appétit, énergie..."}
                        </p>
                      </div>
                      <div className="p-3 bg-accent/10 rounded-2xl group-hover:scale-110 transition-transform"><Plus className="h-6 w-6 text-accent" /></div>
                    </div>
                  </CardContent>
                </Card>
              </section>

              <section className="space-y-4" data-tut="routine">
                <div className="flex justify-between items-center px-1">
                  <h2 className="text-xs font-black flex items-center gap-2 text-muted-foreground uppercase tracking-widest">
                    <TrendingUp className="h-4 w-4 text-primary" />
                    Routine de Vie Interactive
                  </h2>
                  {currentStage && (
                    <Link href="/life-guide" className="text-[10px] font-black text-primary uppercase flex items-center gap-1 hover:underline">
                      Guide complet <ChevronRight className="h-3 w-3" />
                    </Link>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {routineItems.map((item) => {
                    const isDone = item.current >= item.target;
                    const remaining = Math.max(0, item.target - item.current);
                    return (
                      <Card 
                        key={item.id} 
                        className={cn(
                          "glass-card border-none transition-all cursor-pointer hover:scale-[1.02] active:scale-95 group relative overflow-hidden",
                          isDone ? "bg-primary/5 opacity-80" : "bg-secondary/20"
                        )}
                        onClick={() => router.push(`${item.page}?petId=${currentPet?.id}&tab=${item.tab}`)}
                      >
                        <CardContent className="p-5 flex items-center gap-4">
                          <div className={cn("p-3 rounded-2xl shrink-0 transition-transform group-hover:rotate-12", item.bg, item.color)}>
                            <item.icon className="h-6 w-6" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex justify-between items-center mb-1">
                              <p className="text-[10px] font-black uppercase text-muted-foreground tracking-tighter">{item.label}</p>
                              {isDone ? (
                                <Badge className="bg-primary/20 text-primary text-[8px] font-black h-4 px-1.5 uppercase">Terminé</Badge>
                              ) : (
                                <span className="text-[10px] font-black text-foreground">{item.current} / {item.target}</span>
                              )}
                            </div>
                            <Progress value={(item.current / item.target) * 100} className="h-1.5 bg-background/50" />
                            <p className="text-[10px] font-bold text-muted-foreground mt-2 uppercase">
                              {isDone ? 'Objectif atteint !' : `${remaining} restant${remaining > 1 ? 's' : ''}`}
                            </p>
                          </div>
                        </CardContent>
                      </Card>
                    )
                  })}
                </div>
              </section>

              <section className="space-y-4">
                <h2 className="text-xs font-black flex items-center gap-2 text-muted-foreground uppercase tracking-widest px-1">
                  <Sparkles className="h-4 w-4 text-primary" />
                  Conseils Experts
                </h2>
                <div className="grid grid-cols-1 gap-3">
                  {(currentStage?.behavioralTips || []).slice(0, 2).map((tip, i) => (
                    <Card key={i} className="glass-card border-none bg-primary/5 rounded-2xl">
                      <CardContent className="p-4 flex gap-4 items-start">
                        <div className="p-2.5 bg-primary/20 rounded-xl shrink-0"><Dog className="h-4 w-4 text-primary" /></div>
                        <p className="text-xs font-medium italic text-foreground/90">"{tip}"</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </section>
            </div>
          )}
        </div>
      </main>

      {showTutorial && <InteractiveTutorial onFinish={handleFinishTutorial} />}
    </div>
  )
}
