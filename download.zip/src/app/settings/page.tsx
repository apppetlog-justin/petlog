
"use client"

import React, { useState, useEffect } from 'react'
import { Header } from '@/components/layout/Header'
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { useUser, useFirestore, useDoc, useMemoFirebase } from '@/firebase'
import { doc, updateDoc, deleteDoc } from 'firebase/firestore'
import { updateProfile, updateEmail, updatePassword, deleteUser } from 'firebase/auth'
import { useToast } from '@/hooks/use-toast'
import { User, Mail, Lock, Calendar, Save, Loader2, ArrowLeft, Trash2, AlertTriangle } from 'lucide-react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

export default function SettingsPage() {
  const { user } = useUser()
  const db = useFirestore()
  const { toast } = useToast()
  const router = useRouter()

  const userDocRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return doc(db, 'users', user.uid)
  }, [db, user])
  const { data: userData, isLoading: isUserDataLoading } = useDoc(userDocRef)

  const [displayName, setDisplayName] = useState('')
  const [birthdate, setBirthdate] = useState('')
  const [email, setEmail] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [isSavingProfile, setIsSavingProfile] = useState(false)
  const [isSavingSecurity, setIsSavingSecurity] = useState(false)
  const [isDeletingAccount, setIsDeletingAccount] = useState(false)

  useEffect(() => {
    if (userData) {
      setDisplayName(userData.displayName || '')
      setBirthdate(userData.birthdate || '')
      setEmail(userData.email || '')
    }
  }, [userData])

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !userDocRef) return

    setIsSavingProfile(true)
    try {
      await updateProfile(user, { displayName })
      await updateDoc(userDocRef, {
        displayName,
        birthdate,
        updatedAt: new Date().toISOString()
      })
      toast({ title: "Profil mis à jour", description: "Vos informations ont été enregistrées." })
    } catch (error: any) {
      toast({ variant: "destructive", title: "Erreur", description: "Impossible de mettre à jour le profil." })
    } finally {
      setIsSavingProfile(false)
    }
  }

  const handleUpdateSecurity = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !userDocRef) return

    setIsSavingSecurity(true)
    try {
      if (email !== user.email) {
        await updateEmail(user, email)
        await updateDoc(userDocRef, { email })
      }
      if (newPassword) {
        await updatePassword(user, newPassword)
        setNewPassword('')
      }
      toast({ title: "Sécurité mise à jour", description: "Vos identifiants ont été modifiés." })
    } catch (error: any) {
      if (error.code === 'auth/requires-recent-login') {
        toast({ 
          variant: "destructive", 
          title: "Action sensible", 
          description: "Veuillez vous déconnecter et vous reconnecter pour modifier ces informations." 
        })
      } else {
        toast({ variant: "destructive", title: "Erreur", description: error.message || "Une erreur est survenue." })
      }
    } finally {
      setIsSavingSecurity(false)
    }
  }

  const handleDeleteAccount = async () => {
    if (!user || !userDocRef) return
    setIsDeletingAccount(true)
    try {
      // 1. Delete Firestore User Document (and all subcollections should be handled manually or by cloud functions, 
      // but here we at least delete the main user entry)
      await deleteDoc(userDocRef)
      // 2. Delete Firebase Auth User
      await deleteUser(user)
      toast({ title: "Compte supprimé", description: "Toutes vos données personnelles ont été effacées." })
      router.push('/signup')
    } catch (error: any) {
      if (error.code === 'auth/requires-recent-login') {
        toast({ 
          variant: "destructive", 
          title: "Action sensible", 
          description: "Veuillez vous reconnecter avant de pouvoir supprimer votre compte." 
        })
      } else {
        toast({ variant: "destructive", title: "Erreur", description: "La suppression a échoué. Veuillez contacter le support." })
      }
    } finally {
      setIsDeletingAccount(false)
    }
  }

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col pt-16">
        <Header />
        <main className="flex-1 flex items-center justify-center p-4">
          <Card className="glass-card p-8 text-center max-w-sm">
            <p className="text-muted-foreground">Veuillez vous connecter pour accéder aux paramètres.</p>
            <Button asChild className="mt-4 bg-primary"><Link href="/login">Connexion</Link></Button>
          </Card>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col pt-16 pb-20">
      <Header />
      <main className="flex-1 container mx-auto py-8 px-4">
        <div className="max-w-2xl mx-auto space-y-8">
          <div className="flex items-center justify-between">
            <h1 className="text-3xl font-black tracking-tight amber-glow uppercase">Paramètres</h1>
            <Button variant="ghost" asChild className="gap-2">
              <Link href="/"><ArrowLeft className="h-4 w-4" /> Retour</Link>
            </Button>
          </div>

          <Card className="glass-card border-white/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-primary uppercase text-sm font-black tracking-widest">
                <User className="h-4 w-4" /> Informations personnelles
              </CardTitle>
              <CardDescription>Gérez votre identité sur PetLog.</CardDescription>
            </CardHeader>
            <form onSubmit={handleUpdateProfile}>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="displayName">Nom complet</Label>
                  <Input 
                    id="displayName" 
                    value={displayName} 
                    onChange={e => setDisplayName(e.target.value)} 
                    placeholder="Jean Dupont"
                    className="bg-secondary/30 border-none h-12"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="birthdate">Date de naissance</Label>
                  <div className="relative">
                    <Input 
                      id="birthdate" 
                      type="date" 
                      value={birthdate} 
                      onChange={e => setBirthdate(e.target.value)}
                      className="bg-secondary/30 border-none h-12"
                    />
                    <Calendar className="absolute right-4 top-3.5 h-5 w-5 text-muted-foreground pointer-events-none" />
                  </div>
                </div>
              </CardContent>
              <CardFooter className="border-t border-white/5 pt-6 bg-secondary/10">
                <Button type="submit" className="bg-primary gap-2 w-full sm:w-auto" disabled={isSavingProfile}>
                  {isSavingProfile ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                  Enregistrer le profil
                </Button>
              </CardFooter>
            </form>
          </Card>

          <Card className="glass-card border-white/5">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-accent uppercase text-sm font-black tracking-widest">
                <Lock className="h-4 w-4" /> Sécurité & Identifiants
              </CardTitle>
              <CardDescription>Modifiez votre accès au compte.</CardDescription>
            </CardHeader>
            <form onSubmit={handleUpdateSecurity}>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Adresse Email</Label>
                  <div className="relative">
                    <Input 
                      id="email" 
                      type="email" 
                      value={email} 
                      onChange={e => setEmail(e.target.value)}
                      className="bg-secondary/30 border-none h-12 pl-12"
                    />
                    <Mail className="absolute left-4 top-3.5 h-5 w-5 text-muted-foreground" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Nouveau mot de passe (optionnel)</Label>
                  <div className="relative">
                    <Input 
                      id="password" 
                      type="password" 
                      value={newPassword} 
                      onChange={e => setNewPassword(e.target.value)}
                      placeholder="Laissez vide pour ne pas changer"
                      className="bg-secondary/30 border-none h-12 pl-12"
                    />
                    <Lock className="absolute left-4 top-3.5 h-5 w-5 text-muted-foreground" />
                  </div>
                </div>
              </CardContent>
              <CardFooter className="border-t border-white/5 pt-6 bg-secondary/10">
                <Button type="submit" variant="outline" className="gap-2 w-full sm:w-auto border-accent/20 text-accent hover:bg-accent/10" disabled={isSavingSecurity}>
                  {isSavingSecurity ? <Loader2 className="h-4 w-4 animate-spin" /> : <Lock className="h-4 w-4" />}
                  Mettre à jour les identifiants
                </Button>
              </CardFooter>
            </form>
          </Card>

          <Card className="border-destructive/20 bg-destructive/5 overflow-hidden">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-destructive uppercase text-sm font-black tracking-widest">
                <AlertTriangle className="h-4 w-4" /> Zone de danger
              </CardTitle>
              <CardDescription className="text-destructive/70">Ces actions sont irréversibles.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                La suppression de votre compte effacera définitivement toutes vos données utilisateur ainsi que l'historique de tous vos animaux de nos bases de données actives.
              </p>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" className="gap-2 w-full sm:w-auto font-black uppercase text-xs">
                    <Trash2 className="h-4 w-4" /> Supprimer mon compte PetLog
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent className="glass-card border-none shadow-2xl">
                  <AlertDialogHeader>
                    <AlertDialogTitle className="text-xl font-bold flex items-center gap-2">
                      <AlertTriangle className="text-destructive h-6 w-6" />
                      Êtes-vous absolument sûr ?
                    </AlertDialogTitle>
                    <AlertDialogDescription>
                      Cette action ne peut pas être annulée. Cela supprimera définitivement votre profil utilisateur et bloquera votre accès actuel.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter className="gap-3">
                    <AlertDialogCancel className="border-white/10">Annuler</AlertDialogCancel>
                    <AlertDialogAction 
                      onClick={handleDeleteAccount} 
                      className="bg-destructive hover:bg-destructive/90 text-white font-bold"
                      disabled={isDeletingAccount}
                    >
                      {isDeletingAccount ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Trash2 className="mr-2 h-4 w-4" />}
                      Confirmer la suppression
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
