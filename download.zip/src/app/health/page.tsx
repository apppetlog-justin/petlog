
"use client"

import React, { useState, useEffect, useRef, Suspense } from 'react'
import { Header } from '@/components/layout/Header'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'
import { Textarea } from '@/components/ui/textarea'
import { 
  Utensils, 
  Droplets, 
  AlertTriangle, 
  Moon, 
  Save, 
  X, 
  Loader2, 
  Camera,
  Image as ImageIcon,
  HelpCircle,
  Search,
  Maximize2,
  Check,
  Pill,
  GlassWater,
  Brain,
  Clock,
  Zap,
  Info,
  Calendar,
  ToggleLeft,
  Settings2
} from 'lucide-react'
import { useUser, useFirestore, useCollection, useMemoFirebase, errorEmitter, FirestorePermissionError, useDoc } from '@/firebase'
import { collection, addDoc, doc, updateDoc } from 'firebase/firestore'
import { useToast } from '@/hooks/use-toast'
import { useSearchParams, useRouter } from 'next/navigation'
import Image from 'next/image'
import { resizeImage } from '@/lib/image-utils'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog"
import { Badge } from '@/components/ui/badge'
import { cn } from '@/lib/utils'

const BRISTOL_SCALE_DETAILS = [
  { 
    type: "Type 1", 
    desc: "Boulettes dures (noix), difficiles à expulser", 
    color: "text-blue-400", 
    bg: "bg-blue-500/10", 
    border: "border-blue-500/20", 
    status: "Constipation",
    drawing: (
      <svg width="40" height="40" viewBox="0 0 40 40" className="fill-orange-900/40">
        <circle cx="10" cy="15" r="4" />
        <circle cx="22" cy="10" r="5" />
        <circle cx="30" cy="25" r="4" />
        <circle cx="15" cy="30" r="5" />
      </svg>
    )
  },
  { 
    type: "Type 2", 
    desc: "En forme de saucisse mais grumeleuse", 
    color: "text-blue-300", 
    bg: "bg-blue-500/10", 
    border: "border-blue-500/20", 
    status: "Constipation",
    drawing: (
      <svg width="40" height="40" viewBox="0 0 40 40" className="fill-orange-900/40">
        <path d="M5,20 Q10,10 15,20 T25,20 T35,20" stroke="currentColor" strokeWidth="8" fill="none" strokeLinecap="round" className="text-orange-900/40" />
        <circle cx="10" cy="18" r="4" />
        <circle cx="20" cy="22" r="4" />
        <circle cx="30" cy="18" r="4" />
      </svg>
    )
  },
  { 
    type: "Type 3", 
    desc: "Saucisse avec des craquelures sur la surface", 
    color: "text-green-400", 
    bg: "bg-green-500/10", 
    border: "border-green-500/20", 
    status: "Idéal",
    drawing: (
      <svg width="40" height="40" viewBox="0 0 40 40" className="fill-orange-900/40">
        <rect x="5" y="15" width="30" height="10" rx="5" />
        <line x1="12" y1="15" x2="12" y2="25" stroke="black" strokeWidth="1" opacity="0.3" />
        <line x1="20" y1="15" x2="20" y2="25" stroke="black" strokeWidth="1" opacity="0.3" />
        <line x1="28" y1="15" x2="28" y2="25" stroke="black" strokeWidth="1" opacity="0.3" />
      </svg>
    )
  },
  { 
    type: "Type 4", 
    desc: "Saucisse ou serpent, lisse et doux", 
    color: "text-green-500", 
    bg: "bg-green-500/10", 
    border: "border-green-500/20", 
    status: "Idéal",
    drawing: (
      <svg width="40" height="40" viewBox="0 0 40 40" className="fill-orange-900/40">
        <path d="M5,20 C10,10 30,30 35,20" stroke="currentColor" strokeWidth="8" fill="none" strokeLinecap="round" className="text-orange-900/40" />
      </svg>
    )
  },
  { 
    type: "Type 5", 
    desc: "Morceaux mous aux contours nets", 
    color: "text-orange-400", 
    bg: "bg-orange-500/10", 
    border: "border-orange-500/20", 
    status: "Léger",
    drawing: (
      <svg width="40" height="40" viewBox="0 0 40 40" className="fill-orange-900/40">
        <circle cx="12" cy="15" r="6" />
        <circle cx="28" cy="25" r="6" />
        <circle cx="20" cy="15" r="5" />
      </svg>
    )
  },
  { 
    type: "Type 6", 
    desc: "Morceaux duveteux, déchiquetés, selles molles", 
    color: "text-orange-500", 
    bg: "bg-orange-500/10", 
    border: "border-orange-500/20", 
    status: "Diarrhée",
    drawing: (
      <svg width="40" height="40" viewBox="0 0 40 40" className="fill-orange-900/40">
        <path d="M10,20 Q12,15 15,20 T20,20 T25,20 T30,20" stroke="currentColor" strokeWidth="10" strokeDasharray="2,1" fill="none" strokeLinecap="round" className="text-orange-900/40" />
      </svg>
    )
  },
  { 
    type: "Type 7", 
    desc: "Aqueux, aucun morceau solide. Liquide.", 
    color: "text-red-500", 
    bg: "bg-red-500/10", 
    border: "border-red-500/20", 
    status: "Diarrhée",
    drawing: (
      <svg width="40" height="40" viewBox="0 0 40 40" className="fill-orange-900/40">
        <ellipse cx="20" cy="25" rx="15" ry="5" />
        <ellipse cx="15" cy="15" rx="8" ry="3" />
      </svg>
    )
  },
]

const MEAL_UNITS = ["g", "tasse", "ml", "unité", "boîte", "sachet"];
const KNOWN_MEAL_TYPES = ["Croquettes", "Pâtée", "Friandise", "BARF (crue)", "Restant de table"];

const BEHAVIORS = [
  "Normal / Serein",
  "Excité / Foufou",
  "Anxieux / Peureux",
  "Agressif / Grognements",
  "Destructeur",
  "Aboiements excessifs",
  "Obsessionnel (léchage, queue...)",
  "Pot de colle",
  "Indépendant / Distant",
  "Autre"
];

const getLocalDatetimeString = (date?: Date) => {
  const now = date || new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  return `${year}-${month}-${day}T${hours}:${minutes}`;
};

const parseValue = (val: string): number => {
  if (!val) return 0;
  const trimmed = val.trim();
  if (trimmed.includes('/')) {
    const [num, den] = trimmed.split('/').map(s => parseFloat(s.trim()));
    if (!isNaN(num) && !isNaN(den) && den !== 0) return num / den;
  }
  return parseFloat(trimmed) || 0;
};

const formatDuration = (start: string, end: string) => {
  if (!start || !end) return null;
  const s = new Date(start).getTime();
  const e = new Date(end).getTime();
  if (e <= s) return null;
  
  const diffMs = e - s;
  const diffHrs = Math.floor(diffMs / 3600000);
  const diffMins = Math.round((diffMs % 3600000) / 60000);
  
  if (diffHrs > 0) {
    return `${diffHrs}h ${diffMins > 0 ? diffMins + 'min' : ''}`;
  }
  return `${diffMins}min`;
};

function HealthContent() {
  const { user } = useUser();
  const db = useFirestore()
  const { toast } = useToast()
  const searchParams = useSearchParams()
  const router = useRouter()
  
  const initialPetId = searchParams.get('petId') || ''
  const initialTab = searchParams.get('tab') || 'repas'
  const logIdToEdit = searchParams.get('logId') || ''

  const [selectedPet, setSelectedPet] = useState(initialPetId)
  const [activeTab, setActiveTab] = useState(initialTab)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isEditing, setIsEditing] = useState(false)
  const [editingLog, setEditingLog] = useState<any>(null)
  const [showBristolHelp, setShowBristolHelp] = useState(false)
  const [fullScreenImage, setFullScreenImage] = useState<string | null>(null)

  const [showCamera, setShowCamera] = useState(false)
  const [capturedPhotos, setCapturedPhotos] = useState<string[]>([])
  const videoRef = useRef<HTMLVideoElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const defaultFormData = {
    date: getLocalDatetimeString(),
    notes: '',
    mealType: 'Croquettes',
    customMealType: '',
    brand: '',
    quantityGivenValue: '',
    quantityGivenUnit: 'g',
    quantityLeftoverValue: '',
    medication: '',
    waterIntake: 'Moyen',
    type: 'both',
    urineQty: 'Moyen',
    hasBloodUrine: false,
    hasBloodStool: false,
    stoolColor: 'Marron',
    stoolTexture: 'Type 4',
    vomitColor: 'Jaune',
    vomitQty: 'Petite',
    hasBloodVomit: false,
    sleepStart: getLocalDatetimeString(),
    sleepEnd: getLocalDatetimeString(),
    sleepQuality: 'Bonne',
    sleepType: 'Nuit',
    behavior: 'Normal / Serein',
    customBehavior: '',
    recordSleep: true,
    recordBehavior: true
  }

  const [formData, setFormData] = useState<any>(defaultFormData)

  useEffect(() => {
    if (showCamera) {
      const getCameraPermission = async () => {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
          }
        } catch (error) {
          setShowCamera(false);
          toast({ variant: 'destructive', title: 'Accès caméra refusé' });
        }
      };
      getCameraPermission();
    } else {
      if (videoRef.current?.srcObject) {
        (videoRef.current.srcObject as MediaStream).getTracks().forEach(track => track.stop());
      }
    }
  }, [showCamera, toast]);

  const sleepDuration = React.useMemo(() => formatDuration(formData.sleepStart, formData.sleepEnd), [formData.sleepStart, formData.sleepEnd]);
  const editingSleepDuration = React.useMemo(() => editingLog ? formatDuration(editingLog.sleepStart, editingLog.sleepEnd) : null, [editingLog?.sleepStart, editingLog?.sleepEnd]);

  const appetitePercent = React.useMemo(() => {
    const given = parseValue(formData.quantityGivenValue);
    const leftover = parseValue(formData.quantityLeftoverValue);
    if (given > 0) {
      const eaten = Math.max(0, given - leftover);
      return Math.min(Math.round((eaten / given) * 100), 100);
    }
    return null;
  }, [formData.quantityGivenValue, formData.quantityLeftoverValue]);

  const editingAppetitePercent = React.useMemo(() => {
    if (!editingLog) return null;
    const given = parseValue(editingLog.quantityGivenValue);
    const leftover = parseValue(editingLog.quantityLeftoverValue);
    if (given > 0) {
      const eaten = Math.max(0, given - leftover);
      return Math.min(Math.round((eaten / given) * 100), 100);
    }
    return null;
  }, [editingLog?.quantityGivenValue, editingLog?.quantityLeftoverValue]);

  const petsRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return collection(db, 'users', user.uid, 'pets')
  }, [db, user])
  const { data: pets } = useCollection(petsRef)

  const getCollectionName = (tab: string) => {
    const map: any = { repas: 'meals', excretions: 'excretions', vomis: 'vomitIncidents', sommeil: 'sleepRecords' }
    return map[tab] || 'meals'
  }

  const editLogRef = useMemoFirebase(() => {
    if (!db || !user || !selectedPet || !logIdToEdit) return null;
    return doc(db, 'users', user.uid, 'pets', selectedPet, getCollectionName(activeTab), logIdToEdit);
  }, [db, user, selectedPet, activeTab, logIdToEdit]);
  const { data: logToEdit } = useDoc(editLogRef);

  useEffect(() => {
    if (logToEdit) {
      const editData = { 
        ...logToEdit,
        brand: logToEdit.brand ?? '',
        notes: logToEdit.notes ?? '',
        quantityGivenValue: logToEdit.quantityGivenValue ?? '',
        quantityGivenUnit: logToEdit.quantityGivenUnit ?? 'g',
        quantityLeftoverValue: logToEdit.quantityLeftoverValue ?? '',
        medication: logToEdit.medication ?? '',
        waterIntake: logToEdit.waterIntake ?? 'Moyen',
        mediaUrls: logToEdit.mediaUrls ?? [],
        customMealType: '',
        customBehavior: '',
        recordSleep: !!logToEdit.sleepDate,
        recordBehavior: !!logToEdit.behavior
      };

      if (editData.mealDate) {
        editData.date = getLocalDatetimeString(new Date(editData.mealDate));
        if (editData.mealType && !KNOWN_MEAL_TYPES.includes(editData.mealType)) {
          editData.customMealType = editData.mealType;
          editData.mealType = 'Autre';
        }
      }
      if (editData.excretionDate) editData.date = getLocalDatetimeString(new Date(editData.excretionDate));
      if (editData.incidentDate) editData.date = getLocalDatetimeString(new Date(editData.incidentDate));
      if (editData.sleepDate) {
        editData.date = getLocalDatetimeString(new Date(editData.sleepDate));
        editData.sleepStart = getLocalDatetimeString(new Date(editData.sleepDate));
        editData.sleepEnd = getLocalDatetimeString(new Date(editData.sleepEnd));
        if (editData.quality && !['Excellente', 'Bonne', 'Moyenne', 'Mauvaise'].includes(editData.quality)) {
          editData.behavior = editData.quality;
          editData.sleepQuality = 'Bonne';
        } else {
          editData.sleepQuality = editData.quality || 'Bonne';
        }
        
        if (editData.behavior && !BEHAVIORS.includes(editData.behavior)) {
          editData.customBehavior = editData.behavior;
          editData.behavior = 'Autre';
        }
      }
      
      setEditingLog(editData);
      setIsEditing(true);
    }
  }, [logToEdit]);

  const handleSave = () => {
    if (!selectedPet || !user) return
    setIsSubmitting(true)
    
    const data: any = {
      petId: selectedPet,
      ownerUserId: user.uid,
      notes: formData.notes || '',
      mediaUrls: capturedPhotos || [],
      createdAt: new Date().toISOString()
    }

    if (activeTab === 'repas') {
      const given = parseValue(formData.quantityGivenValue);
      const leftover = parseValue(formData.quantityLeftoverValue);
      const eaten = Math.max(0, given - leftover);
      const finalMealType = formData.mealType === 'Autre' ? (formData.customMealType || 'Autre') : formData.mealType;
      
      Object.assign(data, { 
        mealDate: new Date(formData.date).toISOString(), 
        mealType: finalMealType, 
        brand: formData.brand || '', 
        quantityGivenValue: formData.quantityGivenValue || '0',
        quantityGivenUnit: formData.quantityGivenUnit || 'g',
        quantityLeftoverValue: formData.quantityLeftoverValue || '0',
        quantityEatenValue: eaten.toString(),
        quantityGiven: `${formData.quantityGivenValue}${formData.quantityGivenUnit}`,
        quantityEaten: appetitePercent !== null ? `${appetitePercent}%` : '--',
        medication: formData.medication || '',
        waterIntake: formData.waterIntake || 'Moyen'
      })
    } else if (activeTab === 'excretions') {
      Object.assign(data, { 
        excretionDate: new Date(formData.date).toISOString(), 
        type: formData.type, 
        hasBloodUrine: !!formData.hasBloodUrine, 
        hasBloodStool: !!formData.hasBloodStool,
        urineQty: formData.urineQty || 'Moyen', 
        stoolColor: formData.stoolColor || 'Marron', 
        stoolTexture: formData.stoolTexture || 'Type 4' 
      })
    } else if (activeTab === 'vomis') {
      Object.assign(data, { incidentDate: new Date(formData.date).toISOString(), color: formData.vomitColor || 'Jaune', quantity: formData.vomitQty || 'Petite', hasBlood: !!formData.hasBloodVomit })
    } else if (activeTab === 'sommeil') {
      const finalBehavior = formData.behavior === 'Autre' ? (formData.customBehavior || 'Autre') : formData.behavior;
      
      if (formData.recordSleep) {
        Object.assign(data, { 
          sleepDate: new Date(formData.date).toISOString(), 
          sleepEnd: new Date(formData.sleepEnd).toISOString(), 
          quality: formData.sleepQuality || 'Bonne',
          type: formData.sleepType || 'Nuit',
          duration: sleepDuration
        });
      }
      
      if (formData.recordBehavior) {
        Object.assign(data, { 
          behavior: finalBehavior
        });
      }

      // If nothing checked, use the date anyway
      if (!data.sleepDate) {
        data.sleepDate = new Date(formData.date).toISOString();
      }
    }

    const colRef = collection(db, 'users', user.uid, 'pets', selectedPet, getCollectionName(activeTab));
    addDoc(colRef, data)
      .then(() => {
        setFormData({ ...defaultFormData, date: getLocalDatetimeString() })
        setCapturedPhotos([])
        setIsSubmitting(false)
        toast({ title: "Enregistré" })
      })
      .catch(async (error) => {
        setIsSubmitting(false)
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: colRef.path,
          operation: 'create',
          requestResourceData: data
        }));
      });
  }

  const handleUpdate = () => {
    if (!user || !selectedPet || !editingLog) return
    setIsSubmitting(true)
    
    const updateData: any = {
      notes: editingLog.notes || '',
      mediaUrls: editingLog.mediaUrls || [],
      updatedAt: new Date().toISOString()
    }

    if (editingLog.mealDate) {
      const given = parseValue(editingLog.quantityGivenValue);
      const leftover = parseValue(editingLog.quantityLeftoverValue);
      const eaten = Math.max(0, given - leftover);
      const finalMealType = editingLog.mealType === 'Autre' ? (editingLog.customMealType || 'Autre') : editingLog.mealType;

      Object.assign(updateData, { 
        mealDate: new Date(editingLog.date).toISOString(), 
        mealType: finalMealType, 
        brand: editingLog.brand || '', 
        quantityGivenValue: editingLog.quantityGivenValue || '0',
        quantityGivenUnit: editingLog.quantityGivenUnit || 'g',
        quantityLeftoverValue: editingLog.quantityLeftoverValue || '0',
        quantityEatenValue: eaten.toString(),
        quantityGiven: `${editingLog.quantityGivenValue}${editingLog.quantityGivenUnit}`,
        quantityEaten: editingAppetitePercent !== null ? `${editingAppetitePercent}%` : '--',
        medication: editingLog.medication || '',
        waterIntake: editingLog.waterIntake || 'Moyen'
      })
    } else if (editingLog.excretionDate) {
      Object.assign(updateData, { excretionDate: new Date(editingLog.date).toISOString(), type: editingLog.type || 'both', hasBloodUrine: !!editingLog.hasBloodUrine, hasBloodStool: !!editingLog.hasBloodStool, urineQty: editingLog.urineQty || 'Moyen', stoolColor: editingLog.stoolColor || 'Marron', stoolTexture: editingLog.stoolTexture || 'Type 4' })
    } else if (editingLog.incidentDate) {
      Object.assign(updateData, { incidentDate: new Date(editingLog.date).toISOString(), color: editingLog.color || 'Jaune', quantity: editingLog.quantity || 'Petite', hasBlood: !!editingLog.hasBlood })
    } else if (editingLog.sleepDate) {
      const finalBehavior = editingLog.behavior === 'Autre' ? (editingLog.customBehavior || 'Autre') : editingLog.behavior;
      
      if (editingLog.recordSleep) {
        Object.assign(updateData, { 
          sleepDate: new Date(editingLog.date).toISOString(), 
          sleepEnd: new Date(editingLog.sleepEnd).toISOString(), 
          quality: editingLog.sleepQuality || 'Bonne',
          type: editingLog.sleepType || 'Nuit',
          duration: editingSleepDuration
        });
      } else {
        // Clear sleep fields if unchecked
        Object.assign(updateData, { sleepDate: new Date(editingLog.date).toISOString(), sleepEnd: null, quality: null, type: null, duration: null });
      }
      
      if (editingLog.recordBehavior) {
        Object.assign(updateData, { behavior: finalBehavior });
      } else {
        Object.assign(updateData, { behavior: null });
      }
    }

    const docRef = doc(db, 'users', user.uid, 'pets', selectedPet, getCollectionName(activeTab), editingLog.id);
    updateDoc(docRef, updateData)
      .then(() => {
        setIsEditing(false);
        setIsSubmitting(false);
        const returnTo = searchParams.get('returnTo');
        if (returnTo) router.replace(returnTo);
      })
      .catch(async (error) => {
        setIsSubmitting(false)
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: docRef.path,
          operation: 'update',
          requestResourceData: updateData
        }));
      });
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, isEditingForm = false) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const resized = await resizeImage(reader.result as string);
        if (isEditingForm) setEditingLog({ ...editingLog, mediaUrls: [...(editingLog.mediaUrls || []), resized] });
        else setCapturedPhotos([...capturedPhotos, resized]);
      };
      reader.readAsDataURL(file);
    }
  };

  const capturePhoto = async () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
        const resized = await resizeImage(dataUrl);
        setCapturedPhotos([...capturedPhotos, resized]);
        setShowCamera(false);
      }
    }
  };

  const handleOpenJournal = () => {
    window.dispatchEvent(new CustomEvent('open-journal'));
  }

  return (
    <div className="min-h-screen flex flex-col pt-16 pb-24">
      <Header />
      <main className="flex-1 container mx-auto py-8 px-4">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <h1 className="text-3xl font-bold">Suivi Santé</h1>
            <div className="flex gap-2 w-full sm:w-auto">
              <Button variant="outline" className="flex-1 sm:flex-none gap-2" onClick={handleOpenJournal}>
                <Search className="h-4 w-4" /> Journal
              </Button>
              <Select value={selectedPet} onValueChange={setSelectedPet}>
                <SelectTrigger className="flex-1 sm:w-64 bg-secondary/50 border-none"><SelectValue placeholder="Animal" /></SelectTrigger>
                <SelectContent>{pets?.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-4 bg-muted/50 h-14 p-1 rounded-xl">
              <TabsTrigger value="repas" className="gap-2 px-2"><Utensils className="h-4 w-4 shrink-0" /> <span className="truncate">Repas</span></TabsTrigger>
              <TabsTrigger value="excretions" className="gap-2 px-2"><Droplets className="h-4 w-4 shrink-0" /> <span className="truncate">Selle/Urine</span></TabsTrigger>
              <TabsTrigger value="vomis" className="gap-2 px-2"><AlertTriangle className="h-4 w-4 shrink-0" /> <span className="truncate">Vomis</span></TabsTrigger>
              <TabsTrigger value="sommeil" className="gap-2 px-1 sm:px-4"><Moon className="h-4 w-4 shrink-0" /> <span className="truncate">Sommeil & Comp.</span></TabsTrigger>
            </TabsList>

            <div className="mt-8">
              <Card className="glass-card border-none shadow-xl">
                <CardHeader><CardTitle>Nouvelle Entrée</CardTitle></CardHeader>
                <CardContent className="space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Date partagée par tous les logs en haut */}
                    <div className="space-y-2 col-span-full">
                      <Label className="flex items-center gap-2"><Calendar className="h-4 w-4 text-primary" /> Date de l'enregistrement</Label>
                      <Input type="datetime-local" value={formData.date ?? ''} onChange={e => setFormData({...formData, date: e.target.value})} />
                    </div>
                    
                    {activeTab === 'repas' && (
                      <>
                        <div className="space-y-2">
                          <Label>Type</Label>
                          <Select value={formData.mealType ?? 'Croquettes'} onValueChange={val => setFormData({...formData, mealType: val})}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Croquettes">Croquettes</SelectItem>
                              <SelectItem value="Pâtée">Pâtée</SelectItem>
                              <SelectItem value="Friandise">Friandise</SelectItem>
                              <SelectItem value="BARF (crue)">BARF (crue)</SelectItem>
                              <SelectItem value="Restant de table">Restant de table</SelectItem>
                              <SelectItem value="Autre">Autre</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        
                        {formData.mealType === 'Autre' && (
                          <div className="space-y-2 animate-in slide-in-from-top-2">
                            <Label>Précisez le type</Label>
                            <Input 
                              placeholder="Entrez le type de repas..." 
                              value={formData.customMealType ?? ''} 
                              onChange={e => setFormData({...formData, customMealType: e.target.value})} 
                            />
                          </div>
                        )}

                        <div className="space-y-2"><Label>Marque (optionnel)</Label><Input value={formData.brand ?? ''} onChange={e => setFormData({...formData, brand: e.target.value})} /></div>
                        
                        <div className="space-y-2">
                          <Label>Quantité Donnée</Label>
                          <div className="flex gap-2">
                            <Input 
                              type="text" 
                              placeholder="ex: 100 ou 2/3" 
                              value={formData.quantityGivenValue ?? ''} 
                              onChange={e => setFormData({...formData, quantityGivenValue: e.target.value})} 
                              className="flex-1"
                            />
                            <Select value={formData.quantityGivenUnit ?? 'g'} onValueChange={val => setFormData({...formData, quantityGivenUnit: val})}>
                              <SelectTrigger className="w-24"><SelectValue /></SelectTrigger>
                              <SelectContent>
                                {MEAL_UNITS.map(u => <SelectItem key={u} value={u}>{u}</SelectItem>)}
                              </SelectContent>
                            </Select>
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label>Quantité Restante (en {formData.quantityGivenUnit})</Label>
                          <div className="flex gap-2 items-center">
                            <Input 
                              type="text" 
                              placeholder="ex: 25 ou 1/4" 
                              value={formData.quantityLeftoverValue ?? ''} 
                              onChange={e => setFormData({...formData, quantityLeftoverValue: e.target.value})} 
                              className="flex-1"
                            />
                            {appetitePercent !== null && (
                              <Badge variant="secondary" className="h-10 px-3 bg-primary/20 text-primary font-black">
                                Consommé: {appetitePercent}%
                              </Badge>
                            )}
                          </div>
                        </div>

                        <div className="space-y-2">
                          <Label className="flex items-center gap-2">
                            <Pill className="h-4 w-4 text-primary" /> Prise de médicaments ?
                          </Label>
                          <Input 
                            placeholder="Nom du médicament ou 'Non'..." 
                            value={formData.medication ?? ''} 
                            onChange={e => setFormData({...formData, medication: e.target.value})} 
                          />
                        </div>

                        <div className="space-y-2">
                          <Label className="flex items-center gap-2">
                            <GlassWater className="h-4 w-4 text-primary" /> Quantité d'eau bue (approx.)
                          </Label>
                          <Select value={formData.waterIntake ?? 'Moyen'} onValueChange={val => setFormData({...formData, waterIntake: val})}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Peu">Peu</SelectItem>
                              <SelectItem value="Moyen">Moyen</SelectItem>
                              <SelectItem value="Beaucoup">Beaucoup</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </>
                    )}

                    {activeTab === 'excretions' && (
                      <>
                        <div className="space-y-2 col-span-full">
                          <Label>Type d'événement</Label>
                          <Select value={formData.type ?? 'both'} onValueChange={val => setFormData({...formData, type: val})}>
                            <SelectTrigger><SelectValue /></SelectTrigger>
                            <SelectContent>
                              <SelectItem value="urine">Urine uniquement</SelectItem>
                              <SelectItem value="stool">Selle uniquement</SelectItem>
                              <SelectItem value="both">Selle et Urine</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        {(formData.type === 'urine' || formData.type === 'both') && (
                          <div className="space-y-4 p-4 rounded-xl border border-blue-500/20 bg-blue-500/5 col-span-full md:col-span-1">
                            <Label className="text-blue-400 font-bold">Urine</Label>
                            <div className="space-y-3">
                              <div className="space-y-1">
                                <Label className="text-[10px] uppercase opacity-70">Quantité</Label>
                                <Select value={formData.urineQty ?? 'Moyen'} onValueChange={val => setFormData({...formData, urineQty: val})}>
                                  <SelectTrigger><SelectValue /></SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="Petit">Petit</SelectItem>
                                    <SelectItem value="Moyen">Moyen</SelectItem>
                                    <SelectItem value="Grand">Grand</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Checkbox id="bloodUrine" checked={!!formData.hasBloodUrine} onCheckedChange={(val) => setFormData({...formData, hasBloodUrine: !!val})} />
                                <Label htmlFor="bloodUrine" className="text-xs">Présence de sang ?</Label>
                              </div>
                            </div>
                          </div>
                        )}

                        {(formData.type === 'stool' || formData.type === 'both') && (
                          <div className="space-y-4 p-4 rounded-xl border border-orange-500/20 bg-orange-500/5 col-span-full md:col-span-1">
                            <div className="flex items-center justify-between">
                              <Label className="text-orange-400 font-bold">Selle</Label>
                              <Button variant="ghost" size="icon" className="h-6 w-6 rounded-full" onClick={() => setShowBristolHelp(true)}>
                                <HelpCircle className="h-4 w-4 text-orange-400" />
                              </Button>
                            </div>
                            <div className="space-y-3">
                              <div className="space-y-1">
                                <Label className="text-[10px] uppercase opacity-70">Couleur</Label>
                                <Select value={formData.stoolColor ?? 'Marron'} onValueChange={val => setFormData({...formData, stoolColor: val})}>
                                  <SelectTrigger><SelectValue /></SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="Marron">Marron (Normal)</SelectItem>
                                    <SelectItem value="Noir">Noir / Goudronneux</SelectItem>
                                    <SelectItem value="Jaune">Jaune / Orangé</SelectItem>
                                    <SelectItem value="Rouge">Rougeâtre</SelectItem>
                                    <SelectItem value="Vert">Verdâtre</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div className="space-y-1">
                                <Label className="text-[10px] uppercase opacity-70">Texture (Échelle de Bristol)</Label>
                                <Select value={formData.stoolTexture ?? 'Type 4'} onValueChange={val => setFormData({...formData, stoolTexture: val})}>
                                  <SelectTrigger><SelectValue /></SelectTrigger>
                                  <SelectContent>
                                    {BRISTOL_SCALE_DETAILS.map(s => (
                                      <SelectItem key={s.type} value={s.type}>{s.type} - {s.status}</SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Checkbox id="bloodStool" checked={!!formData.hasBloodStool} onCheckedChange={(val) => setFormData({...formData, hasBloodStool: !!val})} />
                                <Label htmlFor="bloodStool" className="text-xs">Présence de sang ?</Label>
                              </div>
                            </div>
                          </div>
                        )}
                      </>
                    )}

                    {activeTab === 'vomis' && (
                      <>
                        <div className="space-y-2"><Label>Couleur / Aspect</Label><Select value={formData.vomitColor ?? 'Jaune'} onValueChange={val => setFormData({...formData, vomitColor: val})}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="Jaune">Jaune / Bile</SelectItem><SelectItem value="Blanc">Blanc / Mousseux</SelectItem><SelectItem value="Marron">Marron / Digéré</SelectItem><SelectItem value="Vert">Vert / Herbe</SelectItem><SelectItem value="Clair">Clair / Liquide</SelectItem><SelectItem value="Rose">Rose / Sanglant</SelectItem></SelectContent></Select></div>
                        <div className="space-y-2"><Label>Quantité</Label><Select value={formData.vomitQty ?? 'Petite'} onValueChange={val => setFormData({...formData, vomitQty: val})}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="Trace">Trace / Régurgitation</SelectItem><SelectItem value="Petite">Petite</SelectItem><SelectItem value="Moyenne">Moyenne</SelectItem><SelectItem value="Importante">Importante</SelectItem></SelectContent></Select></div>
                        <div className="flex items-center space-x-2 pt-4"><Checkbox id="bloodVomit" checked={!!formData.hasBloodVomit} onCheckedChange={v => setFormData({...formData, hasBloodVomit: !!v})} /><Label htmlFor="bloodVomit">Sang détecté ?</Label></div>
                      </>
                    )}

                    {activeTab === 'sommeil' && (
                      <div className="col-span-full space-y-8">
                        {/* SELECTEURS DE SECTION */}
                        <div className="flex flex-wrap gap-4 p-4 rounded-2xl bg-secondary/20 border border-white/5">
                          <div className="flex items-center gap-3 bg-background/40 px-4 py-2 rounded-xl border border-white/5 cursor-pointer hover:bg-background/60 transition-colors" onClick={() => setFormData({...formData, recordSleep: !formData.recordSleep})}>
                            <Checkbox id="checkSleep" checked={formData.recordSleep} onCheckedChange={(v) => setFormData({...formData, recordSleep: !!v})} />
                            <Label htmlFor="checkSleep" className="cursor-pointer font-bold text-xs uppercase tracking-tighter">Enregistrer le repos</Label>
                          </div>
                          <div className="flex items-center gap-3 bg-background/40 px-4 py-2 rounded-xl border border-white/5 cursor-pointer hover:bg-background/60 transition-colors" onClick={() => setFormData({...formData, recordBehavior: !formData.recordBehavior})}>
                            <Checkbox id="checkBehavior" checked={formData.recordBehavior} onCheckedChange={(v) => setFormData({...formData, recordBehavior: !!v})} />
                            <Label htmlFor="checkBehavior" className="cursor-pointer font-bold text-xs uppercase tracking-tighter">Enregistrer le comportement</Label>
                          </div>
                        </div>

                        {/* BLOC SOMMEIL */}
                        {formData.recordSleep && (
                          <div className="space-y-6 animate-in fade-in slide-in-from-top-4 duration-500">
                            <h3 className="text-sm font-black uppercase tracking-widest text-primary flex items-center gap-2">
                              <Moon className="h-4 w-4" /> Analyse du repos
                            </h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-secondary/10 p-6 rounded-2xl border border-white/5">
                              <div className="space-y-2">
                                <Label>Début du repos</Label>
                                <Input type="datetime-local" value={formData.sleepStart ?? ''} onChange={e => setFormData({...formData, sleepStart: e.target.value})} />
                              </div>
                              <div className="space-y-2">
                                <Label>Fin du repos</Label>
                                <Input type="datetime-local" value={formData.sleepEnd ?? ''} onChange={e => setFormData({...formData, sleepEnd: e.target.value})} />
                              </div>
                              
                              <div className="col-span-full">
                                {sleepDuration && (
                                  <div className="bg-primary/20 border border-primary/20 rounded-xl p-4 flex items-center justify-between">
                                    <div className="flex items-center gap-3">
                                      <Clock className="h-5 w-5 text-primary" />
                                      <span className="text-sm font-bold text-primary uppercase tracking-tight">Durée totale calculée</span>
                                    </div>
                                    <span className="text-xl font-black text-primary">{sleepDuration}</span>
                                  </div>
                                )}
                              </div>

                              <div className="space-y-2">
                                <Label>Type de repos</Label>
                                <Select value={formData.sleepType ?? 'Nuit'} onValueChange={v => setFormData({...formData, sleepType: v})}>
                                  <SelectTrigger className="bg-background"><SelectValue /></SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="Nuit">Sommeil de Nuit</SelectItem>
                                    <SelectItem value="Sieste">Sieste en journée</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>

                              <div className="space-y-2">
                                <Label>Qualité du sommeil</Label>
                                <Select value={formData.sleepQuality ?? 'Bonne'} onValueChange={v => setFormData({...formData, sleepQuality: v})}>
                                  <SelectTrigger className="bg-background"><SelectValue /></SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="Excellente">Excellente / Récupérateur</SelectItem>
                                    <SelectItem value="Bonne">Bonne / Calme</SelectItem>
                                    <SelectItem value="Moyenne">Moyenne / Quelques réveils</SelectItem>
                                    <SelectItem value="Mauvaise">Mauvaise / Très agité</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* BLOC COMPORTEMENT */}
                        {formData.recordBehavior && (
                          <div className="space-y-6 pt-4 border-t border-white/5 animate-in fade-in slide-in-from-bottom-4 duration-500">
                            <h3 className="text-sm font-black uppercase tracking-widest text-accent flex items-center gap-2">
                              <Brain className="h-4 w-4" /> Comportement observé
                            </h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-accent/5 p-6 rounded-2xl border border-accent/10">
                              <div className="space-y-2 col-span-full">
                                <Label>État général / Attitude</Label>
                                <Select value={formData.behavior ?? 'Normal / Serein'} onValueChange={v => setFormData({...formData, behavior: v})}>
                                  <SelectTrigger className="bg-background"><SelectValue /></SelectTrigger>
                                  <SelectContent>
                                    {BEHAVIORS.map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}
                                  </SelectContent>
                                </Select>
                              </div>

                              {formData.behavior === 'Autre' && (
                                <div className="space-y-2 col-span-full animate-in slide-in-from-top-2">
                                  <Label>Précisez le comportement</Label>
                                  <Input 
                                    placeholder="Décrivez l'attitude observée..." 
                                    value={formData.customBehavior ?? ''} 
                                    onChange={e => setFormData({...formData, customBehavior: e.target.value})} 
                                  />
                                </div>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  <div className="space-y-4 pt-6 border-t border-white/5">
                    <Label className="flex items-center gap-2"><ImageIcon className="h-4 w-4 text-muted-foreground" /> Photos (optionnel)</Label>
                    <div className="flex flex-wrap gap-3">
                      {capturedPhotos.map((p, i) => (
                        <div key={i} className="relative h-20 w-20 rounded-xl overflow-hidden border border-white/10 group cursor-pointer" onClick={() => setFullScreenImage(p)}>
                          <Image src={p} alt="Capture" fill className="object-cover" />
                          <button 
                            onClick={(e) => {
                              e.stopPropagation();
                              setCapturedPhotos(capturedPhotos.filter((_, idx) => idx !== i));
                            }} 
                            className="absolute top-1 right-1 bg-black/50 p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <X className="h-3 w-3 text-white" />
                          </button>
                          <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <Maximize2 className="h-4 w-4 text-white" />
                          </div>
                        </div>
                      ))}
                      <div className="flex gap-2">
                        <Button variant="outline" size="icon" className="h-20 w-20 border-dashed rounded-xl" onClick={() => setShowCamera(true)}>
                          <Camera className="h-6 w-6 text-muted-foreground" />
                        </Button>
                        <Button variant="outline" size="icon" className="h-20 w-20 border-dashed rounded-xl" onClick={() => fileInputRef.current?.click()}>
                          <ImageIcon className="h-6 w-6 text-muted-foreground" />
                        </Button>
                      </div>
                      <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={e => handleFileChange(e)} />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label className="flex items-center gap-2"><Zap className="h-4 w-4 text-muted-foreground" /> Notes & Observations supplémentaires</Label>
                    <Textarea value={formData.notes ?? ''} onChange={e => setFormData({...formData, notes: e.target.value})} placeholder="Détails supplémentaires (humeur, environnement...)" />
                  </div>
                  
                  <Button className="w-full bg-primary h-14 text-base font-black uppercase tracking-widest shadow-lg shadow-primary/20 rounded-xl" onClick={handleSave} disabled={isSubmitting}><Save className="h-5 w-5 mr-2" /> Enregistrer l'entrée</Button>
                </CardContent>
              </Card>
            </div>
          </Tabs>
        </div>
      </main>

      {/* Camera UI Overlay */}
      {showCamera && (
        <div className="fixed inset-0 z-[200] bg-black flex flex-col items-center justify-center p-4">
          <video ref={videoRef} className="w-full max-w-md aspect-square rounded-3xl object-cover bg-neutral-900 shadow-2xl" autoPlay muted playsInline />
          <div className="flex gap-6 mt-12">
            <Button variant="outline" size="lg" className="rounded-full h-16 w-16 bg-white/10 border-white/20" onClick={() => setShowCamera(false)}>
              <X className="h-8 w-8 text-white" />
            </Button>
            <Button className="bg-primary rounded-full h-20 w-20 shadow-xl shadow-primary/40" onClick={capturePhoto}>
              <Check className="h-10 w-10 text-white" />
            </Button>
          </div>
        </div>
      )}

      {/* Bristol Scale Help Dialog */}
      <Dialog open={showBristolHelp} onOpenChange={setShowBristolHelp}>
        <DialogContent className="glass-card max-w-md p-0 overflow-hidden border-none shadow-2xl">
          <DialogHeader className="p-6 bg-secondary/20 shrink-0">
            <DialogTitle className="text-xl font-bold">Échelle de Bristol</DialogTitle>
            <DialogDescription>Aide visuelle pour identifier la texture des selles.</DialogDescription>
          </DialogHeader>
          
          <div className="flex-1 overflow-y-auto max-h-[70vh] overscroll-contain">
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-1 gap-3">
                {BRISTOL_SCALE_DETAILS.map((item) => (
                  <div key={item.type} className={cn("p-4 rounded-xl border flex gap-4 items-center transition-all", item.bg, item.border)}>
                    <div className="shrink-0 bg-white/5 p-2 rounded-lg border border-white/5">
                      {item.drawing}
                    </div>
                    <div className="flex-1 space-y-1">
                      <div className="flex justify-between items-center">
                        <span className={cn("text-xs font-black uppercase tracking-widest", item.color)}>{item.type}</span>
                        <Badge variant="outline" className="text-[8px] font-black uppercase px-1 h-4 border-white/10">{item.status}</Badge>
                      </div>
                      <p className="text-[11px] text-foreground font-medium leading-tight">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <DialogFooter className="p-6 border-t border-white/5 bg-secondary/10 shrink-0">
            <Button onClick={() => setShowBristolHelp(false)} className="w-full bg-primary font-bold h-12 rounded-xl">J'ai compris</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isEditing} onOpenChange={(open) => {
        setIsEditing(open);
        if (!open) {
          const returnTo = searchParams.get('returnTo');
          if (returnTo) router.replace(returnTo);
        }
      }}>
        <DialogContent className="glass-card max-w-2xl h-[95vh] flex flex-col p-0 overflow-hidden border-none shadow-2xl">
          <DialogHeader className="p-6 shrink-0 bg-secondary/20">
            <DialogTitle className="text-xl font-bold">Modifier l'enregistrement</DialogTitle>
          </DialogHeader>
          <div className="flex-1 overflow-y-auto p-6 space-y-8 no-scrollbar">
            {editingLog && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2 col-span-full"><Label>Date de l'enregistrement</Label><Input type="datetime-local" value={editingLog.date ?? ''} onChange={e => setEditingLog({...editingLog, date: e.target.value})} /></div>
                
                {editingLog.mealDate && (
                  <>
                    <div className="space-y-2">
                      <Label>Type</Label>
                      <Select value={editingLog.mealType ?? 'Croquettes'} onValueChange={val => setEditingLog({...editingLog, mealType: val})}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Croquettes">Croquettes</SelectItem>
                          <SelectItem value="Pâtée">Pâtée</SelectItem>
                          <SelectItem value="Friandise">Friandise</SelectItem>
                          <SelectItem value="BARF (crue)">BARF (crue)</SelectItem>
                          <SelectItem value="Restant de table">Restant de table</SelectItem>
                          <SelectItem value="Autre">Autre</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {editingLog.mealType === 'Autre' && (
                      <div className="space-y-2 animate-in slide-in-from-top-2">
                        <Label>Précisez le type</Label>
                        <Input 
                          placeholder="Entrez le type de repas..." 
                          value={editingLog.customMealType ?? ''} 
                          onChange={e => setEditingLog({...editingLog, customMealType: e.target.value})} 
                        />
                      </div>
                    )}

                    <div className="space-y-2"><Label>Marque</Label><Input value={editingLog.brand ?? ''} onChange={e => setEditingLog({...editingLog, brand: e.target.value})} /></div>
                    
                    <div className="space-y-2">
                      <Label>Quantité Donnée</Label>
                      <div className="flex gap-2">
                        <Input 
                          type="text" 
                          placeholder="ex: 100 ou 2/3"
                          value={editingLog.quantityGivenValue ?? ''} 
                          onChange={e => setEditingLog({...editingLog, quantityGivenValue: e.target.value})} 
                          className="flex-1"
                        />
                        <Select value={editingLog.quantityGivenUnit ?? 'g'} onValueChange={val => setEditingLog({...editingLog, quantityGivenUnit: val})}>
                          <SelectTrigger className="w-24"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {MEAL_UNITS.map(u => <SelectItem key={u} value={u}>{u}</SelectItem>)}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label>Quantité Restante</Label>
                      <div className="flex gap-2 items-center">
                        <Input 
                          type="text" 
                          placeholder="ex: 25 ou 1/4"
                          value={editingLog.quantityLeftoverValue ?? ''} 
                          onChange={e => setEditingLog({...editingLog, quantityLeftoverValue: e.target.value})} 
                          className="flex-1"
                        />
                        {editingAppetitePercent !== null && (
                          <Badge variant="secondary" className="h-10 px-3 bg-primary/20 text-primary font-black">
                            Consommé: {editingAppetitePercent}%
                          </Badge>
                        )}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label className="flex items-center gap-2">
                        <Pill className="h-4 w-4 text-primary" /> Médicaments
                      </Label>
                      <Input 
                        value={editingLog.medication ?? ''} 
                        onChange={e => setEditingLog({...editingLog, medication: e.target.value})} 
                      />
                    </div>

                    <div className="space-y-2">
                      <Label className="flex items-center gap-2">
                        <GlassWater className="h-4 w-4 text-primary" /> Eau bue
                      </Label>
                      <Select value={editingLog.waterIntake ?? 'Moyen'} onValueChange={val => setEditingLog({...editingLog, waterIntake: val})}>
                        <SelectTrigger><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Peu">Peu</SelectItem>
                          <SelectItem value="Moyen">Moyen</SelectItem>
                          <SelectItem value="Beaucoup">Beaucoup</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                )}

                {editingLog.excretionDate && (
                  <>
                    <div className="space-y-2 col-span-full"><Label>Type</Label><Select value={editingLog.type ?? 'both'} onValueChange={val => setEditingLog({...editingLog, type: val})}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="urine">Urine</SelectItem><SelectItem value="stool">Selle</SelectItem><SelectItem value="both">Selle et Urine</SelectItem></SelectContent></Select></div>
                    {(editingLog.type === 'urine' || editingLog.type === 'both') && (
                      <div className="space-y-2"><Label>Quantité Urine</Label><Select value={editingLog.urineQty ?? 'Moyen'} onValueChange={v => setEditingLog({...editingLog, urineQty: v})}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent><SelectItem value="Petit">Petit</SelectItem><SelectItem value="Moyen">Moyen</SelectItem><SelectItem value="Grand">Grand</SelectItem></SelectContent></Select></div>
                    )}
                    {(editingLog.type === 'stool' || editingLog.type === 'both') && (
                      <div className="space-y-2"><Label>Texture Selle (Bristol)</Label><Select value={editingLog.stoolTexture ?? 'Type 4'} onValueChange={v => setEditingLog({...editingLog, stoolTexture: v})}><SelectTrigger><SelectValue /></SelectTrigger><SelectContent>{BRISTOL_SCALE_DETAILS.map(s => <SelectItem key={s.type} value={s.type}>{s.type} - {s.status}</SelectItem>)}</SelectContent></Select></div>
                    )}
                  </>
                )}

                {editingLog.sleepDate && (
                  <div className="col-span-full space-y-8">
                    {/* SELECTEURS DE SECTION (EDIT) */}
                    <div className="flex flex-wrap gap-4 p-4 rounded-2xl bg-secondary/20 border border-white/5">
                      <div className="flex items-center gap-3 bg-background/40 px-4 py-2 rounded-xl border border-white/5 cursor-pointer" onClick={() => setEditingLog({...editingLog, recordSleep: !editingLog.recordSleep})}>
                        <Checkbox id="editCheckSleep" checked={editingLog.recordSleep} onCheckedChange={(v) => setEditingLog({...editingLog, recordSleep: !!v})} />
                        <Label htmlFor="editCheckSleep" className="cursor-pointer font-bold text-xs uppercase tracking-tighter">Repos</Label>
                      </div>
                      <div className="flex items-center gap-3 bg-background/40 px-4 py-2 rounded-xl border border-white/5 cursor-pointer" onClick={() => setEditingLog({...editingLog, recordBehavior: !editingLog.recordBehavior})}>
                        <Checkbox id="editCheckBehavior" checked={editingLog.recordBehavior} onCheckedChange={(v) => setEditingLog({...editingLog, recordBehavior: !!v})} />
                        <Label htmlFor="editCheckBehavior" className="cursor-pointer font-bold text-xs uppercase tracking-tighter">Comportement</Label>
                      </div>
                    </div>

                    {editingLog.recordSleep && (
                      <div className="space-y-6 animate-in fade-in slide-in-from-top-4 duration-500">
                        <h3 className="text-sm font-black uppercase tracking-widest text-primary flex items-center gap-2"><Moon className="h-4 w-4" /> Repos</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-secondary/10 p-6 rounded-2xl border border-white/5">
                          <div className="space-y-2"><Label>Début du repos</Label><Input type="datetime-local" value={editingLog.sleepStart ?? ''} onChange={e => setEditingLog({...editingLog, sleepStart: e.target.value})} /></div>
                          <div className="space-y-2"><Label>Fin du repos</Label><Input type="datetime-local" value={editingLog.sleepEnd ?? ''} onChange={e => setEditingLog({...editingLog, sleepEnd: e.target.value})} /></div>
                          <div className="col-span-full">
                            {editingSleepDuration && (
                              <div className="bg-primary/20 border border-primary/20 rounded-xl p-4 flex items-center justify-between">
                                <span className="text-sm font-bold text-primary uppercase">Durée totale</span>
                                <span className="text-xl font-black text-primary">{editingSleepDuration}</span>
                              </div>
                            )}
                          </div>
                          <div className="space-y-2">
                            <Label>Type</Label>
                            <Select value={editingLog.sleepType ?? 'Nuit'} onValueChange={v => setEditingLog({...editingLog, sleepType: v})}>
                              <SelectTrigger className="bg-background"><SelectValue /></SelectTrigger>
                              <SelectContent><SelectItem value="Nuit">Nuit</SelectItem><SelectItem value="Sieste">Sieste</SelectItem></SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label>Qualité</Label>
                            <Select value={editingLog.sleepQuality ?? 'Bonne'} onValueChange={v => setEditingLog({...editingLog, sleepQuality: v})}>
                              <SelectTrigger className="bg-background"><SelectValue /></SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Excellente">Excellente</SelectItem>
                                <SelectItem value="Bonne">Bonne</SelectItem>
                                <SelectItem value="Moyenne">Moyenne</SelectItem>
                                <SelectItem value="Mauvaise">Mauvaise</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                      </div>
                    )}

                    {editingLog.recordBehavior && (
                      <div className="space-y-6 pt-4 border-t border-white/5 animate-in fade-in slide-in-from-bottom-4 duration-500">
                        <h3 className="text-sm font-black uppercase tracking-widest text-accent flex items-center gap-2"><Brain className="h-4 w-4" /> Comportement</h3>
                        <div className="bg-accent/5 p-6 rounded-2xl border border-accent/10 space-y-4">
                          <Label>État / Attitude</Label>
                          <Select value={editingLog.behavior ?? 'Normal / Serein'} onValueChange={v => setEditingLog({...editingLog, behavior: v})}>
                            <SelectTrigger className="bg-background"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              {BEHAVIORS.map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}
                            </SelectContent>
                          </Select>
                          {editingLog.behavior === 'Autre' && (
                            <div className="animate-in slide-in-from-top-2">
                              <Label className="text-xs opacity-70">Précisez</Label>
                              <Input value={editingLog.customBehavior ?? ''} onChange={e => setEditingLog({...editingLog, customBehavior: e.target.value})} />
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                <div className="space-y-2 col-span-full pt-6 border-t border-white/5"><Label>Notes & Observations</Label><Textarea value={editingLog.notes ?? ''} onChange={e => setEditingLog({...editingLog, notes: e.target.value})} /></div>
                <div className="space-y-2 col-span-full">
                  <Label>Photos</Label>
                  <div className="flex flex-wrap gap-3">
                    {editingLog.mediaUrls?.map((url: string, i: number) => (
                      <div key={i} className="relative h-20 w-20 rounded-xl overflow-hidden border border-white/10 group cursor-pointer" onClick={() => setFullScreenImage(url)}>
                        <Image src={url} alt="Photo" fill className="object-cover" />
                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            setEditingLog({...editingLog, mediaUrls: editingLog.mediaUrls.filter((_:any, idx: number) => idx !== i)});
                          }} 
                          className="absolute top-1 right-1 bg-black/50 p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="h-3 w-3" />
                        </button>
                        <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <Maximize2 className="h-4 w-4 text-white" />
                        </div>
                      </div>
                    ))}
                    <div className="flex gap-2">
                      <Button variant="outline" size="icon" className="h-20 w-20 border-dashed rounded-xl" onClick={() => setShowCamera(true)}>
                        <Camera className="h-6 w-6 text-muted-foreground" />
                      </Button>
                      <Button variant="outline" size="icon" className="h-20 w-20 border-dashed rounded-xl" onClick={() => fileInputRef.current?.click()}>
                        <ImageIcon className="h-6 w-6 text-muted-foreground" />
                      </Button>
                    </div>
                    <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={e => handleFileChange(e, true)} />
                  </div>
                </div>
              </div>
            )}
          </div>
          <DialogFooter className="p-6 border-t bg-muted/5 gap-2 shrink-0">
            <Button variant="outline" className="flex-1" onClick={() => {
              setIsEditing(false);
              const returnTo = searchParams.get('returnTo');
              if (returnTo) router.replace(returnTo);
            }}>Annuler</Button>
            <Button className="flex-1 bg-primary font-black uppercase tracking-widest text-[10px]" onClick={handleUpdate} disabled={isSubmitting}>Enregistrer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Visionneuse Plein Écran */}
      <Dialog open={!!fullScreenImage} onOpenChange={(open) => !open && setFullScreenImage(null)}>
        <DialogContent className="max-w-[100vw] h-full p-0 bg-black border-none flex items-center justify-center z-[400] hide-close">
          <DialogHeader className="sr-only">
            <DialogTitle>Visualisation d'image</DialogTitle>
          </DialogHeader>
          <div className="relative w-full h-full flex items-center justify-center">
             {fullScreenImage && <Image src={fullScreenImage} alt="Plein écran" fill className="object-contain" priority sizes="100vw" />}
             <Button 
               variant="ghost" 
               size="icon" 
               className="absolute top-6 right-6 h-12 w-12 rounded-full bg-black/50 text-white hover:bg-black/70 z-[410]"
               onClick={() => setFullScreenImage(null)}
             >
               <X className="h-8 w-8" />
             </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}

export default function HealthPage() {
  return <Suspense fallback={<div className="min-h-screen flex items-center justify-center pt-16"><Loader2 className="animate-spin" /></div>}><HealthContent /></Suspense>
}
