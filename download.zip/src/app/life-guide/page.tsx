"use client"

import React, { useState, useMemo, useEffect, Suspense } from 'react'
import { Header } from '@/components/layout/Header'
import { 
  Calendar, 
  Dog, 
  Utensils, 
  Footprints, 
  Zap, 
  HeartPulse, 
  ChevronRight, 
  Sparkles,
  AlertCircle,
  Clock,
  Info,
  Loader2,
  BrainCircuit,
  ShieldCheck,
  Target,
  Scissors,
  Stethoscope,
  Moon,
  Lightbulb,
  ShieldAlert,
  Puzzle,
  CheckCircle2
} from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useUser, useFirestore, useCollection, useMemoFirebase } from '@/firebase'
import { collection } from 'firebase/firestore'
import { getLifeGuide, BREED_SPECS } from '@/lib/dog-life-guide-data'
import { cn } from '@/lib/utils'
import { ScrollArea } from '@/components/ui/scroll-area'

function LifeGuideContent() {
  const { user } = useUser()
  const db = useFirestore()
  
  const [selectedPetId, setSelectedPetId] = useState<string>('')
  const [activeStageId, setActiveStageId] = useState<string>('')

  const petsRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return collection(db, 'users', user.uid, 'pets')
  }, [db, user])
  const { data: pets, isLoading: isPetsLoading } = useCollection(petsRef)

  useEffect(() => {
    const saved = localStorage.getItem('globalSelectedPetId');
    if (saved) setSelectedPetId(saved);
    else if (pets && pets.length > 0 && !selectedPetId) setSelectedPetId(pets[0].id);

    const handlePetChanged = (e: any) => setSelectedPetId(e.detail.petId);
    window.addEventListener('pet-changed', handlePetChanged);
    return () => window.removeEventListener('pet-changed', handlePetChanged);
  }, [pets]);

  const handlePetChange = (id: string) => {
    setSelectedPetId(id);
    localStorage.setItem('globalSelectedPetId', id);
    window.dispatchEvent(new CustomEvent('pet-changed', { detail: { petId: id } }));
  }

  const selectedPet = useMemo(() => pets?.find(p => p.id === selectedPetId), [pets, selectedPetId])

  const { ageInWeeks, ageInMonths, ageInYears } = useMemo(() => {
    if (!selectedPet?.birthdate) return { ageInWeeks: 0, ageInMonths: 0, ageInYears: 0 }
    const birth = new Date(selectedPet.birthdate)
    const now = new Date()
    const diffTime = Math.abs(now.getTime() - birth.getTime())
    return {
      ageInWeeks: Math.floor(diffTime / (1000 * 60 * 60 * 24 * 7)),
      ageInMonths: Math.floor(diffTime / (1000 * 60 * 60 * 24 * 30.44)),
      ageInYears: Number((diffTime / (1000 * 60 * 60 * 24 * 365.25)).toFixed(1))
    }
  }, [selectedPet])

  const guide = useMemo(() => {
    if (!selectedPet) return []
    return getLifeGuide(selectedPet.breed || selectedPet.animalType)
  }, [selectedPet])

  const currentStage = useMemo(() => {
    if (!guide.length) return null
    return guide.find(stage => {
      if (stage.startYear !== undefined) return ageInYears >= stage.startYear && ageInYears < (stage.endYear || 100)
      if (stage.startMonth !== undefined) return ageInMonths >= stage.startMonth && ageInMonths < (stage.endMonth || 100)
      return ageInWeeks >= (stage.startWeek || 0) && ageInWeeks < (stage.endWeek || 1000)
    }) || guide[guide.length - 1]
  }, [guide, ageInWeeks, ageInMonths, ageInYears])

  useEffect(() => {
    if (currentStage && !activeStageId) setActiveStageId(currentStage.id);
  }, [currentStage]);

  const activeStage = useMemo(() => guide.find(s => s.id === activeStageId) || currentStage, [guide, activeStageId, currentStage])
  const breedData = useMemo(() => BREED_SPECS[selectedPet?.breed || ""] || BREED_SPECS["Autre (Croisé)"], [selectedPet]);

  if (isPetsLoading) return <div className="min-h-screen flex items-center justify-center pt-16"><Loader2 className="animate-spin text-primary" /></div>

  return (
    <div className="min-h-screen flex flex-col pt-16 pb-24">
      <Header />
      <main className="flex-1 container mx-auto py-8 px-4">
        <div className="max-w-7xl mx-auto space-y-8">
          
          <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 glass-card p-8 rounded-[2.5rem] bg-gradient-to-br from-primary/10 via-background to-accent/5 border border-white/5 shadow-2xl">
            <div className="space-y-2">
              <h1 className="text-4xl font-black tracking-tighter amber-glow uppercase leading-none">Guide de Vie Expert</h1>
              <p className="text-muted-foreground text-sm font-bold uppercase tracking-widest opacity-70">
                Protocole de croissance : {selectedPet?.name} ({selectedPet?.breed || 'Race'})
              </p>
            </div>
            <Select value={selectedPetId} onValueChange={handlePetChange}>
              <SelectTrigger className="w-full lg:w-72 bg-secondary/50 border-none h-14 rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-inner">
                <SelectValue placeholder="Choisir un compagnon" />
              </SelectTrigger>
              <SelectContent>
                {pets?.map(p => <SelectItem key={p.id} value={p.id} disabled={p.animalType !== 'dog'}>{p.name} {p.animalType !== 'dog' && '(Chien uniquement)'}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          {!selectedPet ? (
            <div className="text-center py-32 glass-card rounded-[2.5rem] border-dashed border-2 opacity-30">
              <Dog className="h-24 w-24 mx-auto mb-6 text-muted-foreground" />
              <p className="font-black uppercase tracking-widest">Sélectionnez un chien pour débloquer son guide</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              <aside className="lg:col-span-3 space-y-4">
                <div className="px-2 flex justify-between items-end">
                  <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">Timeline Interactive</p>
                  <Badge variant="outline" className="text-[8px] font-black uppercase border-primary/20 text-primary">Scientifique</Badge>
                </div>
                <ScrollArea className="h-[70vh] lg:pr-4">
                  <div className="space-y-3">
                    {guide.map((stage) => {
                      const isCurrent = currentStage?.id === stage.id
                      const isActive = activeStage?.id === stage.id
                      return (
                        <button
                          key={stage.id}
                          onClick={() => setActiveStageId(stage.id)}
                          className={cn(
                            "w-full text-left p-5 rounded-[1.5rem] border transition-all flex items-center justify-between group",
                            isActive ? "bg-primary border-primary shadow-xl shadow-primary/20 scale-[1.02]" : "bg-card border-white/5 hover:border-primary/30",
                            isCurrent && !isActive && "border-accent/50 ring-1 ring-accent/20"
                          )}
                        >
                          <div className="flex flex-col">
                            <div className="flex items-center gap-2">
                              <span className={cn("text-xs font-black uppercase tracking-tighter", isActive ? "text-white" : "text-foreground")}>
                                {stage.title}
                              </span>
                              {isCurrent && <Badge className="text-[8px] bg-accent text-accent-foreground font-black px-1.5 h-4 uppercase">Actuel</Badge>}
                            </div>
                            <span className={cn("text-[9px] font-bold opacity-60 uppercase mt-1", isActive ? "text-white/80" : "text-muted-foreground")}>
                              {stage.startWeek !== undefined ? `Sem. ${stage.startWeek}+` : stage.startMonth !== undefined ? `Mois ${stage.startMonth}+` : `An ${stage.startYear}+`}
                            </span>
                          </div>
                          <ChevronRight className={cn("h-4 w-4 transition-transform group-hover:translate-x-1", isActive ? "text-white" : "text-muted-foreground")} />
                        </button>
                      )
                    })}
                  </div>
                </ScrollArea>
              </aside>

              <div className="lg:col-span-9 space-y-6">
                {activeStage && (
                  <div className="space-y-6 animate-in fade-in slide-in-from-right-8 duration-700">
                    
                    <Card className="glass-card border-none shadow-2xl overflow-hidden rounded-[2.5rem]">
                      <div className="bg-primary/5 p-10 border-b border-white/5 relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-10 opacity-5">
                          <Dog className="h-48 w-48 rotate-12" />
                        </div>
                        <div className="relative z-10 space-y-4">
                          <Badge className="bg-primary text-white font-black uppercase text-[10px] px-4 py-1 rounded-full shadow-lg shadow-primary/20">Phase : {activeStage.id}</Badge>
                          <h2 className="text-5xl font-black uppercase tracking-tighter leading-tight">{activeStage.title}</h2>
                          <p className="text-lg font-medium leading-relaxed text-muted-foreground italic max-w-3xl border-l-4 border-primary/20 pl-6">
                            "{activeStage.description}"
                          </p>
                        </div>
                      </div>

                      <CardContent className="p-10 space-y-12">
                        {/* Metrics Grid */}
                        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
                          <MetricBox icon={Utensils} label="Repas / J" value={`${activeStage.mealsPerDay}x`} color="text-orange-400" bg="bg-orange-400/10" />
                          <MetricBox icon={Moon} label="Sommeil" value={`${activeStage.sleepHours}h`} color="text-blue-400" bg="bg-blue-400/10" />
                          <MetricBox icon={Footprints} label="Balades / J" value={`${activeStage.walksPerDay}x`} color="text-primary" bg="bg-primary/10" />
                          <MetricBox icon={Clock} label="Durée Balade" value={`${activeStage.walkDurationMinutes}m`} color="text-blue-400" bg="bg-blue-400/10" />
                          <MetricBox icon={Target} label="Dressage / J" value={`${activeStage.trainingSessionsPerDay}x`} color="text-accent" bg="bg-accent/10" />
                          <MetricBox icon={Puzzle} label="Stimulation" value="Flair" color="text-pink-400" bg="bg-pink-400/10" />
                        </div>

                        {/* Focus Areas Grid */}
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
                          {/* Behavioral Tips */}
                          <div className="space-y-6">
                            <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-accent flex items-center gap-3">
                              <BrainCircuit className="h-5 w-5" /> Philosophie & Comportement
                            </h3>
                            <div className="space-y-4">
                              {activeStage.behavioralTips.map((tip, i) => (
                                <div key={i} className="flex gap-4 p-6 rounded-[1.5rem] bg-secondary/20 border border-white/5 items-start group hover:bg-secondary/30 transition-colors">
                                  <div className="p-2 bg-background/50 rounded-xl group-hover:scale-110 transition-transform">
                                    <Sparkles className="h-4 w-4 text-accent" />
                                  </div>
                                  <p className="text-xs font-bold text-foreground/90 leading-relaxed italic">"{tip}"</p>
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Key Milestones & Socialization */}
                          <div className="space-y-8">
                            <div className="space-y-6">
                              <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-primary flex items-center gap-3">
                                <ShieldCheck className="h-5 w-5" /> Focus Socialisation
                              </h3>
                              <div className="flex flex-wrap gap-3">
                                {activeStage.socializationFocus.map((item, i) => (
                                  <Badge key={i} variant="outline" className="bg-primary/5 border-primary/20 text-[10px] py-2 px-4 font-black uppercase tracking-tight">{item}</Badge>
                                ))}
                              </div>
                            </div>

                            <div className="space-y-6">
                              <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-400 flex items-center gap-3">
                                <Stethoscope className="h-5 w-5" /> Étapes Santé
                              </h3>
                              <div className="p-6 rounded-[1.5rem] bg-blue-500/5 border border-blue-500/10 space-y-4">
                                {activeStage.healthMilestones.map((action, i) => (
                                  <div key={i} className="flex items-center gap-3">
                                    <CheckCircle2 className="h-4 w-4 text-blue-400" />
                                    <span className="text-[11px] font-bold text-foreground/80 uppercase">{action}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Special Breed Card */}
                        <div className="pt-8 border-t border-white/5 grid grid-cols-1 md:grid-cols-3 gap-6">
                          <div className="p-8 rounded-[2rem] bg-destructive/10 border border-destructive/20 space-y-4 md:col-span-2">
                            <h3 className="text-[10px] font-black uppercase tracking-widest text-destructive flex items-center gap-3">
                              <ShieldAlert className="h-5 w-5" /> Vigilance Santé : {selectedPet?.breed}
                            </h3>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                              {breedData.healthRisks.map((risk, i) => (
                                <div key={i} className="flex items-center gap-3 bg-background/40 p-3 rounded-xl">
                                  <AlertCircle className="h-3 w-3 text-destructive" />
                                  <span className="text-[10px] font-bold uppercase">{risk}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                          
                          <div className="p-8 rounded-[2rem] bg-blue-500/10 border border-blue-500/20 space-y-4">
                            <h3 className="text-[10px] font-black uppercase tracking-widest text-blue-400 flex items-center gap-3">
                              <Scissors className="h-5 w-5" /> Hygiène
                            </h3>
                            <div className="space-y-3">
                              <p className="text-xl font-black uppercase tracking-tighter text-blue-400">{activeStage.groomingFrequency}</p>
                              <p className="text-[10px] font-medium text-muted-foreground leading-relaxed">
                                Adapté aux spécificités de la race ({breedData.groomingNeed === 'high' ? 'Entretien exigeant' : 'Entretien modéré'}).
                              </p>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <div className="p-6 bg-accent/5 rounded-[2rem] border border-accent/10 flex flex-col sm:flex-row gap-6 items-center">
                      <div className="p-4 bg-accent/20 rounded-2xl"><Lightbulb className="h-6 w-6 text-accent" /></div>
                      <p className="text-[11px] font-bold text-muted-foreground uppercase leading-relaxed tracking-tight text-center sm:text-left">
                        Chaque chien est unique. Ce guide est basé sur des données vétérinaires et des méthodes d'éducation positives (Peps & Scott). En cas de doute comportemental ou médical, consultez un professionnel certifié.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}

function MetricBox({ icon: Icon, label, value, color, bg }: { icon: any, label: string, value: string, color: string, bg: string }) {
  return (
    <div className={cn("p-5 rounded-[2rem] border border-white/5 flex flex-col items-center text-center gap-3 transition-all hover:scale-105 hover:bg-secondary/40 bg-secondary/20 shadow-lg")}>
      <div className={cn("p-2.5 rounded-xl", bg, color)}>
        <Icon className="h-5 w-5" />
      </div>
      <div className="space-y-0.5">
        <p className="text-[8px] font-black uppercase text-muted-foreground tracking-widest">{label}</p>
        <p className={cn("text-xl font-black tracking-tighter", color)}>{value}</p>
      </div>
    </div>
  )
}

export default function LifeGuidePage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center pt-16"><Loader2 className="animate-spin" /></div>}>
      <LifeGuideContent />
    </Suspense>
  )
}
