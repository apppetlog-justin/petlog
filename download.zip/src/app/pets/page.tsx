"use client"

import React, { useState, useEffect } from 'react'
import { Header } from '@/components/layout/Header'
import { Plus, Trash2, ExternalLink, Activity, ChevronRight, Loader2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardFooter } from '@/components/ui/card'
import Image from 'next/image'
import Link from 'next/link'
import { Badge } from '@/components/ui/badge'
import { useUser, useFirestore, useCollection, useMemoFirebase } from '@/firebase'
import { collection, deleteDoc, doc } from 'firebase/firestore'
import { useToast } from '@/hooks/use-toast'
import { useRouter } from 'next/navigation'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

export default function PetsPage() {
  const { user } = useUser()
  const db = useFirestore()
  const { toast } = useToast()
  const router = useRouter()

  const [petToDelete, setPetToDelete] = useState<{id: string, name: string} | null>(null)
  const [isDeleting, setIsDeleting] = useState(false)

  // Force unlock the UI on mount to prevent "frozen" app issues
  useEffect(() => {
    const unlock = () => {
      document.body.style.pointerEvents = 'auto';
      document.body.style.overflow = 'auto';
      if (document.documentElement) {
        document.documentElement.style.pointerEvents = 'auto';
        document.documentElement.style.overflow = 'auto';
      }
    };
    unlock();
    const timer = setTimeout(unlock, 300);
    return () => clearTimeout(timer);
  }, []);

  const petsRef = useMemoFirebase(() => {
    if (!db || !user) return null
    return collection(db, 'users', user.uid, 'pets')
  }, [db, user])

  const { data: pets, isLoading } = useCollection(petsRef)

  const confirmDelete = async () => {
    if (!user || !db || !petToDelete) return
    
    setIsDeleting(true)
    try {
      await deleteDoc(doc(db, 'users', user.uid, 'pets', petToDelete.id))
      toast({
        title: "Animal supprimé",
        description: `${petToDelete.name} a été retiré de votre liste.`,
      })
    } catch (error) {
      console.error("Delete failed:", error)
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Impossible de supprimer l'animal.",
      })
    } finally {
      setIsDeleting(false)
      setPetToDelete(null)
      // Force unlock after dialog closure
      setTimeout(() => {
        document.body.style.pointerEvents = 'auto';
        document.body.style.overflow = 'auto';
      }, 300);
    }
  }

  return (
    <div className="min-h-screen flex flex-col pt-16 pb-20">
      <Header />
      <main className="flex-1 container mx-auto py-8 px-4">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Mes Animaux</h1>
            <p className="text-muted-foreground text-sm">Cliquez sur un animal pour ouvrir son dossier complet.</p>
          </div>
          <Button asChild className="bg-primary hover:bg-primary/90 gap-2 shadow-lg shadow-primary/20">
            <Link href="/pets/new">
              <Plus className="h-4 w-4" /> Ajouter un animal
            </Link>
          </Button>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map(i => (
              <Card key={i} className="glass-card h-80 animate-pulse bg-muted/20" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pets?.map((pet) => (
              <Card 
                key={pet.id} 
                className="glass-card overflow-hidden transition-all duration-300 transform hover:-translate-y-1 shadow-md border-white/5 hover:border-primary/50 relative"
              >
                {/* Clickable area for details */}
                <div 
                  onClick={() => router.push(`/pets/${pet.id}`)}
                  className="cursor-pointer group"
                >
                  <div className="relative h-64 overflow-hidden">
                    <Image 
                      src={pet.profileImageUrl || `https://picsum.photos/seed/${pet.id}/400/400`} 
                      alt={pet.name} 
                      fill 
                      className="object-cover transition-transform duration-500 group-hover:scale-110"
                      data-ai-hint="pet portrait"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-transparent flex items-end p-6">
                      <div className="w-full">
                        <div className="flex justify-between items-center">
                          <h2 className="text-3xl font-bold amber-glow">{pet.name}</h2>
                          <ChevronRight className="h-6 w-6 text-white/50 group-hover:text-primary transition-colors" />
                        </div>
                        <div className="flex gap-2 mt-2">
                          <Badge variant="secondary" className="bg-primary/20 text-primary border-primary/20 backdrop-blur-md">
                            {pet.animalType === 'dog' ? 'Chien' : pet.animalType === 'cat' ? 'Chat' : pet.animalType}
                          </Badge>
                          {pet.breed && (
                            <Badge variant="secondary" className="bg-accent/20 text-accent border-accent/20 backdrop-blur-md">
                              {pet.breed}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                  <CardContent className="pt-6 bg-card/50">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="space-y-1">
                        <p className="text-[10px] uppercase font-bold text-muted-foreground tracking-wider">Sexe</p>
                        <p className="font-medium capitalize">{pet.gender === 'male' ? 'Mâle' : pet.gender === 'female' ? 'Femelle' : pet.gender}</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-[10px] uppercase font-bold text-muted-foreground tracking-wider">Naissance</p>
                        <p className="font-medium">{pet.birthdate ? new Date(pet.birthdate).toLocaleDateString('fr-FR') : 'N/A'}</p>
                      </div>
                    </div>
                  </CardContent>
                </div>

                <CardFooter className="flex justify-between border-t border-white/5 pt-4 bg-card/80">
                  <div className="flex gap-2">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-9 w-9 hover:bg-destructive/10 hover:text-destructive rounded-full relative z-20"
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        setPetToDelete({id: pet.id, name: pet.name});
                      }}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <Button 
                    variant="link" 
                    className="text-xs font-bold text-primary flex items-center gap-1 p-0 h-auto z-20"
                    onClick={(e) => {
                      e.preventDefault();
                      e.stopPropagation();
                      router.push(`/pets/${pet.id}`);
                    }}
                  >
                    Ouvrir le dossier <ExternalLink className="h-3 w-3" />
                  </Button>
                </CardFooter>
              </Card>
            ))}

            <Link href="/pets/new" className="group">
              <Card className="glass-card border-dashed border-2 border-white/10 flex flex-col items-center justify-center h-full min-h-[400px] hover:border-primary/50 transition-all bg-muted/5">
                <div className="p-6 rounded-full bg-secondary/50 group-hover:bg-primary/20 transition-all">
                  <Plus className="h-10 w-10 text-muted-foreground group-hover:text-primary transition-all" />
                </div>
                <p className="mt-4 font-bold text-muted-foreground group-hover:text-primary transition-all">
                  Ajouter un nouvel animal
                </p>
              </Card>
            </Link>
          </div>
        )}

        {pets?.length === 0 && !isLoading && (
          <div className="text-center py-20 glass-card rounded-2xl border-dashed border-2 border-white/10 opacity-60">
            <Activity className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-lg font-medium">Vous n'avez pas encore d'animaux.</p>
            <p className="text-sm text-muted-foreground mt-2">Commencez par ajouter votre premier compagnon.</p>
          </div>
        )}
      </main>

      <AlertDialog open={!!petToDelete} onOpenChange={(open) => !open && setPetToDelete(null)}>
        <AlertDialogContent className="glass-card border-none shadow-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-xl font-bold">Supprimer {petToDelete?.name} ?</AlertDialogTitle>
            <AlertDialogDescription className="text-muted-foreground">
              Cette action est irréversible. Tout l'historique (repas, balades, soins) associé à cet animal sera définitivement supprimé de la base de données.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="gap-3">
            <AlertDialogCancel className="border-white/10 bg-secondary/50">Annuler</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete} 
              className="bg-destructive hover:bg-destructive/90 text-white font-bold"
              disabled={isDeleting}
            >
              {isDeleting ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Trash2 className="mr-2 h-4 w-4" />}
              Supprimer définitivement
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
