
"use client"

import React, { useMemo, useState, useRef } from 'react'
import { Header } from '@/components/layout/Header'
import { useUser, useFirestore, useDoc, useMemoFirebase, useCollection } from '@/firebase'
import { doc, collection, query, orderBy, addDoc, deleteDoc } from 'firebase/firestore'
import { useParams, useRouter } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { 
  ArrowLeft, 
  Dog, 
  Settings2, 
  Scale, 
  Ruler, 
  Calendar, 
  Fingerprint, 
  Palette, 
  Loader2, 
  FileText, 
  Plus, 
  Search, 
  Trash2, 
  Eye, 
  X,
  Maximize2,
  FileUp
} from 'lucide-react'
import Link from 'next/link'
import Image from 'next/image'
import { cn } from '@/lib/utils'
import { useToast } from '@/hooks/use-toast'
import { resizeImage } from '@/lib/image-utils'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog"

export default function PetDetailPage() {
  const { petId } = useParams()
  const { user } = useUser()
  const db = useFirestore()
  const router = useRouter()
  const { toast } = useToast()

  const [isAddDocOpen, setIsAddDocOpen] = useState(false)
  const [isSubmittingDoc, setIsSubmittingDoc] = useState(false)
  const [fullScreenImage, setFullScreenImage] = useState<string | null>(null)
  const [docFormData, setDocFormData] = useState({
    title: '',
    date: new Date().toISOString().split('T')[0],
    image: ''
  })
  const fileInputRef = useRef<HTMLInputElement>(null)

  const petRef = useMemoFirebase(() => {
    if (!db || !user || !petId) return null
    return doc(db, 'users', user.uid, 'pets', petId as string)
  }, [db, user, petId])

  const { data: pet, isLoading: isPetLoading } = useDoc(petRef)

  const inspectionsRef = useMemoFirebase(() => {
    if (!db || !user || !petId) return null
    return collection(db, 'users', user.uid, 'pets', petId as string, 'generalInspections')
  }, [db, user, petId])
  const { data: inspections, isLoading: isInspectionsLoading } = useCollection(inspectionsRef)

  const docsRef = useMemoFirebase(() => {
    if (!db || !user || !petId) return null
    return query(
      collection(db, 'users', user.uid, 'pets', petId as string, 'documents'),
      orderBy('documentDate', 'desc')
    )
  }, [db, user, petId])
  const { data: documents } = useCollection(docsRef)

  const lastWeight = useMemo(() => {
    if (!inspections) return null
    return [...inspections]
      .filter(i => i.type === 'weight' && i.weightValue)
      .sort((a, b) => new Date(b.inspectionDate).getTime() - new Date(a.inspectionDate).getTime())[0]
  }, [inspections])

  const lastHeight = useMemo(() => {
    if (!inspections) return null
    return [...inspections]
      .filter(i => i.type === 'height' && i.heightValue)
      .sort((a, b) => new Date(b.inspectionDate).getTime() - new Date(a.inspectionDate).getTime())[0]
  }, [inspections])

  const calculateAge = (birthdate: string) => {
    if (!birthdate) return 'Inconnu';
    const birth = new Date(birthdate);
    const today = new Date();
    let years = today.getFullYear() - birth.getFullYear();
    let months = today.getMonth() - birth.getMonth();
    if (months < 0 || (months === 0 && today.getDate() < birth.getDate())) {
      years--;
      months += 12;
    }
    if (years === 0) return `${months} mois`;
    return `${years} an${years > 1 ? 's' : ''}${months > 0 ? ` et ${months} mois` : ''}`;
  }

  const handleOpenJournal = () => {
    window.dispatchEvent(new CustomEvent('open-journal'));
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const resized = await resizeImage(reader.result as string, 800); 
        setDocFormData({ ...docFormData, image: resized });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddDocument = async () => {
    if (!user || !petId || !docFormData.image || !docFormData.title) {
      toast({ variant: 'destructive', title: "Informations manquantes" });
      return;
    }

    setIsSubmittingDoc(true);
    try {
      await addDoc(collection(db, 'users', user.uid, 'pets', petId as string, 'documents'), {
        title: docFormData.title,
        documentDate: new Date(docFormData.date).toISOString(),
        mediaUrl: docFormData.image,
        createdAt: new Date().toISOString()
      });
      toast({ title: "Document ajouté" });
      setIsAddDocOpen(false);
      setDocFormData({ title: '', date: new Date().toISOString().split('T')[0], image: '' });
    } catch (e) {
      toast({ variant: 'destructive', title: "Erreur" });
    } finally {
      setIsSubmittingDoc(false);
    }
  };

  const handleDeleteDocument = async (id: string) => {
    if (!user || !petId || !confirm("Supprimer ce document ?")) return;
    try {
      await deleteDoc(doc(db, 'users', user.uid, 'pets', petId as string, 'documents', id));
      toast({ title: "Document supprimé" });
    } catch (e) {
      toast({ variant: 'destructive', title: "Erreur" });
    }
  };

  if (isPetLoading || isInspectionsLoading) {
    return (
      <div className="min-h-screen flex flex-col pt-16">
        <Header />
        <div className="flex-1 flex items-center justify-center">
          <div className="flex flex-col items-center gap-4">
            <Loader2 className="h-12 w-12 text-primary animate-spin" />
            <p className="animate-pulse font-medium">Chargement du dossier...</p>
          </div>
        </div>
      </div>
    )
  }

  if (!pet) {
    return (
      <div className="min-h-screen flex flex-col pt-16">
        <Header />
        <div className="flex-1 flex flex-col items-center justify-center gap-4">
          <p>Dossier introuvable.</p>
          <Button asChild variant="outline">
            <Link href="/pets">Retour à la liste</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col pt-16 pb-24">
      <Header />
      <main className="flex-1 container mx-auto py-8 px-4">
        <div className="max-w-4xl mx-auto space-y-8">
          
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <Button variant="ghost" onClick={() => router.push('/pets')} className="gap-2 hover:bg-secondary -ml-2 sm:ml-0">
              <ArrowLeft className="h-4 w-4" /> Retour
            </Button>
            <div className="flex gap-2 w-full sm:w-auto">
              <Button variant="outline" className="flex-1 sm:flex-none gap-2" onClick={handleOpenJournal}>
                <Search className="h-4 w-4" /> Journal
              </Button>
              <Button className="bg-primary gap-2 shadow-lg shadow-primary/20 flex-1 sm:flex-none" asChild>
                <Link href={`/pets/${petId}/edit`}>
                  <Settings2 className="h-4 w-4" /> Modifier le profil
                </Link>
              </Button>
            </div>
          </div>

          <div className="space-y-8">
            <div 
              className="relative aspect-video sm:aspect-[21/9] w-full rounded-3xl overflow-hidden glass-card border-4 border-primary/20 bg-muted flex items-center justify-center shadow-xl cursor-pointer group"
              onClick={() => pet.profileImageUrl && setFullScreenImage(pet.profileImageUrl)}
            >
              {pet.profileImageUrl ? (
                <>
                  <Image src={pet.profileImageUrl} alt={pet.name} fill className="object-cover transition-transform group-hover:scale-105" />
                  <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Maximize2 className="h-10 w-10 text-white" />
                  </div>
                </>
              ) : (
                <Dog className="h-24 w-24 text-muted-foreground/20" />
              )}
            </div>

            <Card className="glass-card border-none shadow-lg overflow-hidden">
              <CardContent className="p-8 space-y-8">
                <div className="text-center space-y-4">
                  <h1 className="text-5xl font-black tracking-tighter amber-glow capitalize">{pet.name}</h1>
                  <div className="flex justify-center gap-2 flex-wrap">
                    <Badge className="bg-primary/20 text-primary border-primary/30 uppercase text-[10px] px-3 py-1">
                      {pet.animalType === 'dog' ? 'Chien' : pet.animalType === 'cat' ? 'Chat' : pet.animalType}
                    </Badge>
                    {pet.breed && (
                      <Badge className="bg-accent/20 text-accent border-accent/30 uppercase text-[10px] px-3 py-1">
                        {pet.breed}
                      </Badge>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 pt-8 border-t border-white/5">
                  <ProfileInfoItem icon={Calendar} label="Âge" value={calculateAge(pet.birthdate)} subValue={pet.birthdate ? `Né le ${new Date(pet.birthdate).toLocaleDateString('fr-FR')}` : ''} />
                  <ProfileInfoItem icon={Fingerprint} label="Sexe" value={pet.gender === 'male' ? 'Mâle' : pet.gender === 'female' ? 'Femelle' : 'Non précisé'} />
                  <ProfileInfoItem icon={Palette} label="Couleur du pelage" value={pet.coatColor || 'Non spécifiée'} color="text-orange-400" />
                  <ProfileInfoItem icon={Scale} label="Dernière Pesée" value={lastWeight ? `${lastWeight.weightValue} ${lastWeight.weightUnit || 'kg'}` : '--'} subValue={lastWeight ? `Le ${new Date(lastWeight.inspectionDate).toLocaleDateString('fr-FR')}` : 'Aucun log'} color="text-blue-400" />
                  <ProfileInfoItem icon={Ruler} label="Dernière Mesure" value={lastHeight ? `${lastHeight.heightValue} ${lastHeight.heightUnit || 'cm'}` : '--'} subValue={lastHeight ? `Le ${new Date(lastHeight.inspectionDate).toLocaleDateString('fr-FR')}` : 'Aucun log'} color="text-green-400" />
                  <ProfileInfoItem icon={Fingerprint} label="Micro-puce" value={pet.microchipNumber || 'Non renseignée'} isMono color="text-primary" />
                  <ProfileInfoItem icon={Fingerprint} label="ID Dossier" value={pet.id} isMono color="text-muted-foreground" />
                </div>
              </CardContent>
            </Card>

            <section className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold flex items-center gap-2 uppercase tracking-widest text-muted-foreground">
                  <FileText className="h-5 w-5 text-primary" />
                  Documents & Certificats
                </h2>
                <Button size="sm" onClick={() => setIsAddDocOpen(true)} className="gap-2 bg-secondary/50 hover:bg-secondary">
                  <Plus className="h-4 w-4" /> Ajouter
                </Button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {documents && documents.length > 0 ? (
                  documents.map((doc) => (
                    <Card key={doc.id} className="glass-card border-none overflow-hidden group">
                      <div 
                        className="relative h-40 bg-muted cursor-pointer overflow-hidden"
                        onClick={() => setFullScreenImage(doc.mediaUrl)}
                      >
                        <Image src={doc.mediaUrl} alt={doc.title} fill className="object-cover transition-transform group-hover:scale-105" />
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <Maximize2 className="h-8 w-8 text-white" />
                        </div>
                      </div>
                      <CardContent className="p-4 flex justify-between items-start gap-2">
                        <div className="space-y-1 min-w-0">
                          <p className="font-bold text-sm truncate">{doc.title}</p>
                          <p className="text-[10px] text-muted-foreground uppercase">{new Date(doc.documentDate).toLocaleDateString('fr-FR')}</p>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="h-8 w-8 text-destructive/50 hover:text-destructive hover:bg-destructive/10 rounded-full"
                          onClick={() => handleDeleteDocument(doc.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  <div className="col-span-full py-12 glass-card rounded-2xl border-dashed border-2 border-white/5 flex flex-col items-center justify-center opacity-40">
                    <FileText className="h-12 w-12 mb-2" />
                    <p className="text-sm font-medium">Aucun document joint</p>
                    <p className="text-[10px] uppercase">Factures, certificats, ordonnances...</p>
                  </div>
                )}
              </div>
            </section>
          </div>
        </div>
      </main>

      {/* Visionneuse Plein Écran Universelle */}
      <Dialog open={!!fullScreenImage} onOpenChange={(open) => !open && setFullScreenImage(null)}>
        <DialogContent className="max-w-[100vw] h-full p-0 bg-black border-none flex items-center justify-center z-[400]">
          <DialogHeader className="sr-only">
            <DialogTitle>Visualisation d'image</DialogTitle>
          </DialogHeader>
          <div className="relative w-full h-full flex items-center justify-center">
             {fullScreenImage && <Image src={fullScreenImage} alt="Plein écran" fill className="object-contain" priority sizes="100vw" />}
          </div>
        </DialogContent>
      </Dialog>

      {/* Dialog Ajouter Document */}
      <Dialog open={isAddDocOpen} onOpenChange={setIsAddDocOpen}>
        <DialogContent className="glass-card border-none shadow-2xl max-w-md">
          <DialogHeader>
            <DialogTitle>Joindre un document</DialogTitle>
            <DialogDescription>Importez une photo d'un document officiel.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Titre du document</Label>
              <Input 
                placeholder="Ex: Certificat de naissance, Facture veto..." 
                value={docFormData.title}
                onChange={e => setDocFormData({...docFormData, title: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label>Date du document</Label>
              <Input 
                type="date" 
                value={docFormData.date}
                onChange={e => setDocFormData({...docFormData, date: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label>Photo du document</Label>
              <div 
                className="h-48 rounded-xl border-2 border-dashed border-white/10 bg-muted/50 flex flex-col items-center justify-center cursor-pointer overflow-hidden relative group"
                onClick={() => docFormData.image ? setFullScreenImage(docFormData.image) : fileInputRef.current?.click()}
              >
                {docFormData.image ? (
                  <>
                    <Image src={docFormData.image} alt="Preview" fill className="object-cover" />
                    <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <Maximize2 className="h-8 w-8 text-white" />
                    </div>
                    <Button 
                      variant="destructive" 
                      size="icon" 
                      className="absolute top-2 right-2 h-8 w-8 rounded-full opacity-0 group-hover:opacity-100"
                      onClick={(e) => { e.stopPropagation(); setDocFormData({...docFormData, image: ''}); }}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </>
                ) : (
                  <>
                    <FileUp className="h-10 w-10 text-muted-foreground mb-2" />
                    <span className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Choisir une photo</span>
                  </>
                )}
              </div>
              <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDocOpen(false)}>Annuler</Button>
            <Button className="bg-primary" onClick={handleAddDocument} disabled={isSubmittingDoc}>
              {isSubmittingDoc ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Plus className="h-4 w-4 mr-2" />}
              Ajouter au dossier
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

function ProfileInfoItem({ 
  icon: Icon, 
  label, 
  value, 
  subValue, 
  isMono = false,
  color = "text-primary"
}: { 
  icon: any, 
  label: string, 
  value: string, 
  subValue?: string,
  isMono?: boolean,
  color?: string
}) {
  return (
    <div className="flex gap-4 items-start p-4 rounded-2xl bg-white/5 border border-white/5">
      <div className={cn("p-2.5 rounded-xl bg-muted/50 border border-white/5", color)}>
        <Icon className="h-5 w-5" />
      </div>
      <div className="space-y-0.5 min-w-0">
        <p className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">{label}</p>
        <p className={cn(
          "text-lg font-bold leading-tight truncate",
          isMono ? "font-mono text-[10px] opacity-50" : "text-foreground"
        )}>
          {value}
        </p>
        {subValue && <p className="text-[10px] text-muted-foreground font-medium">{subValue}</p>}
      </div>
    </div>
  )
}
