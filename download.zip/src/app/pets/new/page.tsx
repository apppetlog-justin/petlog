"use client"

import React, { useState, useRef, useEffect } from 'react'
import { Header } from '@/components/layout/Header'
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { useUser, useFirestore } from '@/firebase'
import { collection, doc } from 'firebase/firestore'
import { setDocumentNonBlocking } from '@/firebase/non-blocking-updates'
import { useRouter } from 'next/navigation'
import { useToast } from '@/hooks/use-toast'
import { ArrowLeft, Save, Dog, Camera, Image as ImageIcon, X, Check, Loader2, Fingerprint } from 'lucide-react'
import Link from 'next/link'
import Image from 'next/image'
import { resizeImage } from '@/lib/image-utils'

const DOG_BREEDS = [
  "Golden Retriever", "Labrador", "Berger Allemand", "Bouledogue Français", 
  "Beagle", "Poodle (Caniche)", "Rottweiler", "Yorkshire Terrier", 
  "Boxer", "Teckel", "Chihuahua", "Border Collie", "Malinois", "Autre (Croisé)"
]

export default function NewPetPage() {
  const { user } = useUser()
  const db = useFirestore()
  const router = useRouter()
  const { toast } = useToast()

  const [name, setName] = useState('')
  const [animalType, setAnimalType] = useState('')
  const [breed, setBreed] = useState('')
  const [gender, setGender] = useState('')
  const [birthdate, setBirthdate] = useState('')
  const [coatColor, setCoatColor] = useState('')
  const [microchipNumber, setMicrochipNumber] = useState('')
  const [profileImageUrl, setProfileImageUrl] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)

  const [showCamera, setShowCamera] = useState(false)
  const videoRef = useRef<HTMLVideoElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (showCamera) {
      const getCameraPermission = async () => {
        try {
          // Utilisation de facingMode: 'environment' pour la caméra arrière
          const stream = await navigator.mediaDevices.getUserMedia({ 
            video: { facingMode: 'environment' } 
          });
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
          }
        } catch (error) {
          toast({
            variant: 'destructive',
            title: 'Accès caméra refusé',
            description: 'Veuillez autoriser la caméra dans les réglages.',
          });
          setShowCamera(false);
        }
      };
      getCameraPermission();
    } else {
      if (videoRef.current?.srcObject) {
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(track => track.stop());
      }
    }
  }, [showCamera, toast]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const resized = await resizeImage(reader.result as string);
        setProfileImageUrl(resized);
      };
      reader.readAsDataURL(file);
    }
  };

  const capturePhoto = async () => {
    if (videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext('2d');
      ctx?.drawImage(videoRef.current, 0, 0);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
      const resized = await resizeImage(dataUrl);
      setProfileImageUrl(resized);
      setShowCamera(false);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !db) return

    setIsSubmitting(true)
    const newPetId = doc(collection(db, 'placeholder')).id
    const petRef = doc(db, 'users', user.uid, 'pets', newPetId)

    const petData = {
      id: newPetId,
      userId: user.uid,
      name,
      animalType,
      breed: animalType === 'dog' ? breed : '',
      gender,
      birthdate,
      coatColor,
      microchipNumber,
      profileImageUrl,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }

    setDocumentNonBlocking(petRef, petData, { merge: false })
    
    toast({
      title: "Succès",
      description: `${name} a été ajouté !`,
    })
    
    router.push('/pets')
  }

  return (
    <div className="min-h-screen flex flex-col pt-16 pb-24">
      <Header />
      <main className="flex-1 container mx-auto py-8 px-4">
        <div className="max-w-2xl mx-auto space-y-6">
          <Button variant="ghost" asChild className="gap-2">
            <Link href="/pets">
              <ArrowLeft className="h-4 w-4" /> Retour
            </Link>
          </Button>

          <Card className="glass-card border-none shadow-xl">
            <CardHeader className="text-center">
              <div className="p-3 bg-primary/10 w-fit mx-auto rounded-full mb-2">
                <Dog className="h-8 w-8 text-primary" />
              </div>
              <CardTitle>Ajouter un animal</CardTitle>
              <CardDescription>Configurez le profil de votre nouveau compagnon.</CardDescription>
            </CardHeader>
            <form onSubmit={handleSave}>
              <CardContent className="space-y-6">
                <div className="flex flex-col items-center gap-6 py-4">
                  <div className="relative h-40 w-40 rounded-full overflow-hidden border-4 border-primary/20 bg-muted flex items-center justify-center">
                    {profileImageUrl ? (
                      <Image src={profileImageUrl} alt="Preview" fill className="object-cover" />
                    ) : (
                      <Dog className="h-12 w-12 text-muted-foreground/40" />
                    )}
                  </div>
                  <div className="flex gap-3">
                    <Button type="button" variant="outline" size="icon" className="h-20 w-20 border-dashed rounded-xl" onClick={() => setShowCamera(true)}>
                      <Camera className="h-8 w-8 text-muted-foreground" />
                    </Button>
                    <Button type="button" variant="outline" size="icon" className="h-20 w-20 border-dashed rounded-xl" onClick={() => fileInputRef.current?.click()}>
                      <ImageIcon className="h-8 w-8 text-muted-foreground" />
                    </Button>
                    <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleFileChange} />
                  </div>
                </div>

                {showCamera && (
                  <div className="fixed inset-0 z-[100] bg-black/90 flex flex-col items-center justify-center p-4">
                    <video ref={videoRef} className="w-full max-w-md aspect-square rounded-2xl object-cover bg-black" autoPlay muted playsInline />
                    <div className="flex gap-4 mt-8">
                      <Button variant="outline" size="lg" className="rounded-full h-16 w-16" onClick={() => setShowCamera(false)}>
                        <X className="h-8 w-8 text-white" />
                      </Button>
                      <Button className="bg-primary rounded-full h-16 w-16" onClick={capturePhoto}>
                        <Check className="h-8 w-8" />
                      </Button>
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nom de l'animal</Label>
                    <Input id="name" value={name} onChange={e => setName(e.target.value)} required placeholder="Ex: Max" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="type">Type d'animal</Label>
                    <Select onValueChange={setAnimalType} required>
                      <SelectTrigger><SelectValue placeholder="Choisir..." /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="dog">Chien</SelectItem>
                        <SelectItem value="cat">Chat</SelectItem>
                        <SelectItem value="other">Autre</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  {animalType === 'dog' && (
                    <div className="space-y-2 md:col-span-2">
                      <Label htmlFor="breed">Race du chien</Label>
                      <Select onValueChange={setBreed} required>
                        <SelectTrigger><SelectValue placeholder="Choisir la race..." /></SelectTrigger>
                        <SelectContent>
                          {DOG_BREEDS.map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                  <div className="space-y-2">
                    <Label htmlFor="gender">Sexe</Label>
                    <Select onValueChange={setGender} required>
                      <SelectTrigger><SelectValue placeholder="Choisir..." /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Mâle</SelectItem>
                        <SelectItem value="female">Femelle</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="birthdate">Date de naissance</Label>
                    <Input id="birthdate" type="date" value={birthdate} onChange={e => setBirthdate(e.target.value)} required />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="coatColor">Couleur du pelage</Label>
                    <Input id="coatColor" value={coatColor} onChange={e => setCoatColor(e.target.value)} placeholder="Ex: Noir et blanc, Roux, Sable..." />
                  </div>
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="microchip" className="flex items-center gap-2">
                      <Fingerprint className="h-4 w-4 text-primary" /> Numéro de micro-puce
                    </Label>
                    <Input id="microchip" value={microchipNumber} onChange={e => setMicrochipNumber(e.target.value)} placeholder="Ex: 250260000000000" />
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-end gap-2 border-t pt-6">
                <Button variant="outline" asChild><Link href="/pets">Annuler</Link></Button>
                <Button type="submit" className="bg-primary gap-2" disabled={isSubmitting}>
                  {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                  {isSubmitting ? "Enregistrement..." : "Ajouter l'animal"}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </div>
      </main>
    </div>
  )
}
